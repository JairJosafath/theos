# CEL language server

`cel-language-server` finds CEL in Kubernetes YAML and checks, completes and
explains it with Kubernetes' own CEL libraries, the ones the API server runs. It
serves editors over LSP (`serve --stdio`) and CI as a command (`check`). It works
offline: the Kubernetes schemas are built into the binary, and it never contacts
a cluster or the network.

## What it does, and what it does not

It needs no markers, file names or settings: a document's `apiVersion` and
`kind` say which fields hold CEL.

| Kind | Fields with CEL | What is typed there |
| --- | --- | --- |
| `ValidatingAdmissionPolicy` (`admissionregistration.k8s.io/v1`, `v1beta1`) | `spec.matchConditions[].expression`, `spec.variables[].expression`, `spec.validations[].expression` and `messageExpression`, `spec.auditAnnotations[].valueExpression` | `object` and `oldObject` have the schema of the kinds in `spec.matchConstraints.resourceRules` (up to ten; wildcards and subresources are skipped; `dyn` when no kind is known); `params` has the schema of `spec.paramKind`, and is absent without one; `variables`, `request`, `namespaceObject` and `authorizer` as in the API server |
| `ValidatingWebhookConfiguration`, `MutatingWebhookConfiguration` (`admissionregistration.k8s.io/v1`) | `webhooks[].matchConditions[].expression` | `object` and `oldObject` are `dyn`; `request`, `namespaceObject` and `authorizer` are typed |
| `CustomResourceDefinition` (`apiextensions.k8s.io/v1`) | `x-kubernetes-validations[].rule` and `messageExpression` anywhere in each version's `openAPIV3Schema` | `self`, and `oldSelf` where the API server allows it, have the schema node the rule is on |

It reports what the API server would report, at the line and column of the
mistake: syntax errors, undefined names and fields, type errors, a wrong result
type, and the cost and other limits the API server enforces on CRD rules.

It does not understand other kinds, such as Kyverno policies, and does not
evaluate expressions or contact a cluster. Kinds that are not built in, such as
custom resources a policy matches, give `dyn` for `object`. Inside CEL it
answers only for YAML documents, so other YAML tooling, such as schema
validation, keeps working beside it.

## Install

From a release: download the file from the
[releases](http://gitea.gitea.svc.cluster.local:3000/cel-lens/cel-language-server/releases)
on Gitea. A release has the linux/amd64 binary only, as what `make dist` builds
into `dist/`: `cel-language-server_linux_amd64` and `SHA256SUMS`. For another
platform, build it with `make dist PLATFORMS="darwin/arm64"` (any of `linux`,
`darwin` and `windows` on `amd64` and `arm64`) or from source, below.

```sh
sha256sum --check --ignore-missing SHA256SUMS
chmod +x cel-language-server_linux_amd64
mkdir -p ~/.local/bin
mv cel-language-server_linux_amd64 ~/.local/bin/cel-language-server
cel-language-server --version
```

From source, with Go 1.26 or later: clone the repository and install from it. The
module path is private to the platform, so `go install path@version` does not
resolve it.

```sh
git clone http://gitea.gitea.svc.cluster.local:3000/cel-lens/cel-language-server.git
cd cel-language-server
go install .
```

`go install` puts `cel-language-server` in `$(go env GOBIN)`, else
`$(go env GOPATH)/bin`; put that directory on your `PATH`. It reports its version as `dev`;
`make build` stamps the version from git.

## Editors

### VS Code

Install the CEL Lens extension, which starts `cel-language-server serve --stdio`
for YAML files. The extension does not download the server: install it as above
and put it on `PATH`, or set `celLens.server.path`. Its
[README](http://gitea.gitea.svc.cluster.local:3000/cel-lens/vscode-extension)
has the install steps and the settings.

### Neovim

With Neovim 0.11 or later, in `init.lua`:

```lua
vim.lsp.config('cel', {
  cmd = { 'cel-language-server', 'serve', '--stdio' },
  filetypes = { 'yaml' },
  root_markers = { '.git' },
})
vim.lsp.enable('cel')
```

Open a YAML file with a policy in it. Completion is on `omnifunc` (`<C-x><C-o>`)
or your completion plugin, and hover is `K`. Other editors: start
`cel-language-server serve --stdio` for YAML files and speak LSP 3.17 on its
stdin and stdout.

## CI

```text
cel-language-server check [--format text|json] PATH...
```

An unreadable path is reported on stderr and the other files are still checked;
the exit status is then 1.

For example, on a policy with a misspelt field:

```sh exit=1
cel-language-server check policies/replica.yaml
```

```text
policies/replica.yaml:13:31: error: undefined field 'replica'
policies/replica.yaml:14:32: error: undefined field 'replica'
policies/replica.yaml:15:32: error: undefined field 'replica'
policies/replica.yaml:18:23: error: undefined field 'replica'
policies/replica.yaml:21:24: error: undefined field 'replica'
policies/replica.yaml:22:73: error: undefined field 'replica'
```

A file without errors prints nothing and exits 0.

A `PATH` is a file, or a directory searched recursively for `*.yaml` and
`*.yml`, without entering `.git`, `.hg`, `.svn` or `node_modules`. A file over
10 MiB is not read and is reported as an error. Results go to stdout, sorted by path and position. Exit status: `0`
without errors (warnings alone are fine), `1` with at least one error or a path
that cannot be read, `2` for a wrong command line (unknown flag or format,
missing path).

Text output is one line per diagnostic, `path:line:column: severity: message`, with 1-based line and column.

`--format json` prints an array, `[]` when there is nothing to report. Lines and
columns are 1-based, columns count UTF-16 code units as editors do, and `end` is
exclusive. `severity` is `error`, `warning`, `information` or `hint`.

```sh exit=1
cel-language-server check --format json policies/typo.yaml
```

```json
[
  {
    "path": "policies/typo.yaml",
    "range": {
      "start": {
        "line": 13,
        "column": 31
      },
      "end": {
        "line": 13,
        "column": 38
      }
    },
    "severity": "error",
    "message": "undefined field 'replica'"
  }
]
```

In a Gitea or GitHub Actions step:

```yaml
jobs:
  cel:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install the server
        run: |
          curl -fsSL -o /usr/local/bin/cel-language-server \
            http://gitea.gitea.svc.cluster.local:3000/cel-lens/cel-language-server/releases/download/v1.0.0/cel-language-server_linux_amd64
          chmod +x /usr/local/bin/cel-language-server
      - name: Check CEL in policies
        run: cel-language-server check policies/ crds/
```

The step downloads a release file from Gitea: replace `v1.0.0` with a tag that
has a release (see Install), and the host with yours. The binary must be on the
runner's `PATH`.

## Complete in the editor

`cel-language-server serve --stdio` answers `textDocument/completion` inside CEL
expressions of YAML documents, and nowhere else, so other YAML extensions keep
their completion. The items are typed by the place the expression is in:

- after `object.spec.`: the fields of the kind the policy matches, with their CEL
  type and the description of their schema; after `self.` in a CRD rule, the fields
  of the schema node the rule is on;
- at the start of an expression: the variables of the place (`object`, `params`,
  `variables` and the rest for a policy; `self` and, where the API server allows
  it, `oldSelf` for a CRD rule), the iteration variables of the macros around the
  cursor, and the functions and macros;
- after `variables.`: the policy's variables defined before the expression;
  inside `containers.all(c, c.`: the fields of `c`.

Fields are LSP kind Field, variables Variable, functions Function and macros
Keyword; a macro inserts a snippet such as `all(${1:x}, ${2})`. Completion needs a
YAML file that parses, and does nothing inside a string literal or a comment.

## Explain in the editor

`textDocument/hover` on a name inside a CEL expression shows a Markdown card: a
`cel` code block with the declaration, then its documentation. Outside CEL, in a
string literal and in documents that are not YAML there is no hover.

- a variable (`object`, `oldObject`, `request`, `params`, `namespaceObject`,
  `authorizer`, `variables` for a policy; `self`, `oldSelf` for a CRD rule): its CEL
  type and what it holds, such as "The object of the request. It is null for DELETE
  requests."; an iteration variable of a macro shows its type;
- a field (`object.spec.replicas`): its CEL type and the description in the
  schema; fields of `request` show their type only;
- a function or macro: the signature of every overload that fits the call, and the
  documentation cel-go has for it.

The range covers exactly the name. Kubernetes library functions such as
`quantity`, `url` and `cidr` show a description and examples.

## Troubleshooting

The server logs to stderr, never to stdout, which carries LSP. VS Code shows it in
the "CEL Lens" output channel (set `celLens.trace.server` to `messages` to see the
LSP traffic); Neovim writes it to the LSP log, opened with `:LspLog`. Run
`cel-language-server --version` to see which binary you have.

To report a wrong diagnostic, or a missing one, open an
[issue](http://gitea.gitea.svc.cluster.local:3000/cel-lens/cel-language-server/issues)
with the smallest YAML file that shows it, the output of
`cel-language-server check --format json FILE`, what the API server says
(`kubectl apply --dry-run=server`), and the version.

## Develop

Open the repository in its devcontainer, which has Go 1.26 and golangci-lint.

```sh
go run . --help      # run it
go test ./...        # test it
make check           # what CI runs: tidy, format, vet, lint, test with -race
make build           # bin/cel-language-server, versioned with git describe
make dist            # the release binary (linux/amd64) in dist/; PLATFORMS="..." builds others
make help            # every target
go test -run '^$' -bench . ./...   # the latency budgets
```

The last command runs the benchmarks and fails when one exceeds its budget:
locating 50 expressions in a 1,000-line file within 5 ms, the first schema
load within 50 ms, diagnostics within 200 ms of a change and a completion
within 50 ms, each on a file of about 1,000 lines; a hover or completion is
also held to 200 ms. The release workflow runs it automatically before it
builds the release files, so a tag that misses a budget is not released and the
failure shows the measured time and the budget. It is not part of `make check`, whose timing tests allow five times the idle time
so that a busy machine does not fail them.

`cel-language-server --version` prints the version the binary was built with: the
`-ldflags "-X main.version=..."` of the build, or `dev`.

## Layout

- `main.go` is the command: it parses the command line and calls into
  `internal/`. Its `run` function returns the exit code instead of exiting, so
  `main_test.go` tests the whole program.
- `internal/jsonrpc`, `internal/lsp` and `internal/server` are the JSON-RPC framing, the
  LSP types and the server; the protocol packages know nothing of CEL.
- `internal/` holds the packages, one purpose each; `internal/doc.go` explains
  the rules.
- Tests sit next to the code; fixtures and golden files in `testdata/`.

## Language server

`cel-language-server serve --stdio` runs the language server for editors: LSP 3.17 over
stdin and stdout, logs on stderr. It keeps open YAML documents in memory and
publishes CEL diagnostics about 100 ms after the last change; closing a document
clears them. It exits 0 after `shutdown` and `exit`, 1 otherwise.

Read `AGENTS.md` before changing anything: it is the rulebook, for people and agents.
