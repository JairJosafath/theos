package analysis

import (
	"bytes"
	"os"
	"path/filepath"
	"testing"
	"time"

	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// The system answers within 200 ms of a keystroke on a 1,000-line file; these
// benchmarks measure Explain and Complete on such files, a policy and a CRD
// in testdata/bench, so a regression shows in ns/op. They fail when one call
// takes longer than budget, so the release pipeline enforces the 200 ms.

// budget is the time allowed for one hover or completion.
const budget = 200 * time.Millisecond

// benchFile is a fixture and the cursor places in it.
type benchFile struct {
	name    string
	explain string // the hover is on the last two bytes of its last occurrence
	prefix  string // the completion is after the last occurrence of this
}

var benchFiles = []benchFile{
	{"policy", "startsWith", "object.spec."},
	{"crd", "self.count", "self.field1."},
}

// positionAt returns the position of the offset off in src.
func positionAt(src []byte, off int) position.Position {
	line := bytes.Count(src[:off], []byte{'\n'})
	return position.Position{Line: line, Character: off - (bytes.LastIndexByte(src[:off], '\n') + 1)}
}

// benchSource reads the fixture of f and checks it has 1,000 lines.
func benchSource(b *testing.B, f benchFile) []byte {
	b.Helper()
	src, err := os.ReadFile(filepath.Join("..", "..", "testdata", "bench", f.name+".yaml"))
	if err != nil {
		b.Fatal(err)
	}
	if n := bytes.Count(src, []byte{'\n'}); n < 990 || n > 1010 {
		b.Fatalf("%s.yaml has %d lines, want about 1,000", f.name, n)
	}
	return src
}

// BenchmarkExplain explains a name in a 1,000-line policy and CRD.
func BenchmarkExplain(b *testing.B) {
	for _, f := range benchFiles {
		b.Run(f.name, func(b *testing.B) {
			src := benchSource(b, f)
			pos := positionAt(src, bytes.LastIndex(src, []byte(f.explain))+len(f.explain)-2)
			if Explain(f.name+".yaml", src, pos) == nil {
				b.Fatalf("Explain(%s, %q) = nil, want a hover", f.name, f.explain)
			}
			for b.Loop() {
				Explain(f.name+".yaml", src, pos)
			}
			if got := b.Elapsed() / time.Duration(b.N); got > budget {
				b.Errorf("Explain(%s) took %v, want within %v", f.name, got, budget)
			}
		})
	}
}

// BenchmarkComplete completes after a dot at the end of a 1,000-line policy
// and CRD.
func BenchmarkComplete(b *testing.B) {
	for _, f := range benchFiles {
		b.Run(f.name, func(b *testing.B) {
			src := benchSource(b, f)
			pos := positionAt(src, bytes.LastIndex(src, []byte(f.prefix))+len(f.prefix))
			if len(Complete(f.name+".yaml", src, pos)) == 0 {
				b.Fatalf("Complete(%s, after %q) = none, want items", f.name, f.prefix)
			}
			for b.Loop() {
				Complete(f.name+".yaml", src, pos)
			}
			if got := b.Elapsed() / time.Duration(b.N); got > budget {
				b.Errorf("Complete(%s) took %v, want within %v", f.name, got, budget)
			}
		})
	}
}
