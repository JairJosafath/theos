package main

import (
	"bytes"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

var update = flag.Bool("update", false, "rewrite the golden files")

func TestRun(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name       string
		args       []string
		stdin      string
		wantCode   int
		wantStdout string // a substring of stdout; "" means stdout stays empty
		wantStderr string // a substring of stderr; "" means stderr stays empty
	}{
		{
			name:       "no arguments print the help",
			wantCode:   exitOK,
			wantStdout: "Usage: " + name + " [flags]\n       " + name + " check",
		},
		{
			name:       "help",
			args:       []string{"--help"},
			wantCode:   exitOK,
			wantStdout: "-version",
		},
		{
			name:       "version",
			args:       []string{"--version"},
			wantCode:   exitOK,
			wantStdout: name + " dev\n",
		},
		{
			name:       "unknown flag",
			args:       []string{"--nope"},
			wantCode:   exitUsage,
			wantStderr: "flag provided but not defined: -nope",
		},
		{
			name:       "serve without --stdio",
			args:       []string{"serve"},
			wantCode:   exitUsage,
			wantStderr: "need --stdio",
		},
		{
			name:       "serve help",
			args:       []string{"serve", "--help"},
			wantCode:   exitOK,
			wantStdout: "-stdio",
		},
		{
			name:       "serve ends without shutdown",
			args:       []string{"serve", "--stdio"},
			wantCode:   exitFailure,
			wantStderr: "exit without shutdown",
		},
		{
			name:       "serve shutdown and exit",
			args:       []string{"serve", "--stdio"},
			stdin:      frame(`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}`) + frame(`{"jsonrpc":"2.0","id":2,"method":"shutdown"}`) + frame(`{"jsonrpc":"2.0","method":"exit"}`),
			wantCode:   exitOK,
			wantStdout: `"serverInfo":{"name":"cel-language-server","version":"dev"}`,
		},
		{
			name:       "unexpected argument",
			args:       []string{"extra"},
			wantCode:   exitUsage,
			wantStderr: `unknown command "extra"`,
		},
		{
			name:       "check help",
			args:       []string{"check", "--help"},
			wantCode:   exitOK,
			wantStdout: "Example:\n  " + name + " check --format json",
		},
		{
			name:       "check without path",
			args:       []string{"check"},
			wantCode:   exitUsage,
			wantStderr: "check: missing PATH",
		},
		{
			name:       "check unknown flag",
			args:       []string{"check", "--nope", "x"},
			wantCode:   exitUsage,
			wantStderr: "flag provided but not defined: -nope",
		},
		{
			name:       "check unknown format",
			args:       []string{"check", "--format", "xml", "x"},
			wantCode:   exitUsage,
			wantStderr: `unknown format "xml"`,
		},
		{
			name:       "check missing file",
			args:       []string{"check", "testdata/nope.yaml"},
			wantCode:   exitFailure,
			wantStderr: "check testdata/nope.yaml",
		},
		{
			name:     "check clean file",
			args:     []string{"check", "testdata/crds/valid.yaml"},
			wantCode: exitOK,
		},
		{
			name:       "check clean file as json",
			args:       []string{"check", "--format", "json", "testdata/crds/valid.yaml"},
			wantCode:   exitOK,
			wantStdout: "[]\n",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			var stdout, stderr bytes.Buffer
			if got := run(tt.args, strings.NewReader(tt.stdin), &stdout, &stderr); got != tt.wantCode {
				t.Errorf("run(%q) = %d, want %d", tt.args, got, tt.wantCode)
			}
			checkOutput(t, "stdout", stdout.String(), tt.wantStdout)
			checkOutput(t, "stderr", stderr.String(), tt.wantStderr)
		})
	}
}

// checkOutput fails the test when got lacks want, or when want is empty and got
// is not.
func checkOutput(t *testing.T, stream, got, want string) {
	t.Helper()
	if want == "" && got != "" {
		t.Errorf("%s = %q, want it empty", stream, got)
	}
	if !strings.Contains(got, want) {
		t.Errorf("%s = %q, want it to contain %q", stream, got, want)
	}
}

// frame wraps a JSON-RPC body in LSP framing.
func frame(body string) string {
	return fmt.Sprintf("Content-Length: %d\r\n\r\n%s", len(body), body)
}

func TestRunCheckGolden(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name   string
		format string
		golden string
	}{
		{"text", "text", "testdata/check/all.txt"},
		{"json", "json", "testdata/check/all.json"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			var stdout, stderr bytes.Buffer
			args := []string{"check", "--format", tt.format, "testdata/policies", "testdata/crds"}
			if got := run(args, strings.NewReader(""), &stdout, &stderr); got != exitFailure {
				t.Errorf("run(%q) = %d, want %d", args, got, exitFailure)
			}
			if stderr.Len() > 0 {
				t.Errorf("stderr = %q, want it empty", stderr.String())
			}
			if *update {
				if err := os.MkdirAll(filepath.Dir(tt.golden), 0o750); err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(tt.golden, stdout.Bytes(), 0o600); err != nil {
					t.Fatal(err)
				}
			}
			want, err := os.ReadFile(tt.golden)
			if err != nil {
				t.Fatal(err)
			}
			if stdout.String() != string(want) {
				t.Errorf("run(%q) stdout =\n%s\nwant\n%s", args, stdout.String(), want)
			}
		})
	}
}
