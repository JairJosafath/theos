// Package check runs the analysis over files and directories, for the
// command line: it finds the YAML files, collects their diagnostics and
// writes them as text or JSON.
package check

import (
	"context"
	"fmt"
	"io/fs"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"c4factory.local/cel-lens/cel-language-server/internal/analysis"
)

// Finding is one diagnostic in one file.
type Finding struct {
	// Path is the file, as the caller named it or as found below a directory
	// the caller named.
	Path string
	// Diagnostic is the problem, with 0-based LSP positions.
	Diagnostic analysis.Diagnostic
}

// Files checks every path and returns the findings sorted by path and
// position. A path is a file, checked whatever its name, or a directory,
// searched recursively for *.yaml and *.yml files. No findings give nil.
// The error names the path that could not be read; Files stops at the first
// one, and returns ctx.Err() when ctx is cancelled.
func Files(ctx context.Context, paths []string) ([]Finding, error) {
	var files []string
	for _, p := range paths {
		found, err := expand(ctx, p)
		if err != nil {
			return nil, err
		}
		files = append(files, found...)
	}
	slices.Sort(files)
	files = slices.Compact(files)

	var out []Finding
	for _, file := range files {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		src, err := os.ReadFile(file)
		if err != nil {
			return nil, fmt.Errorf("check %s: %w", file, err)
		}
		for _, d := range analysis.Diagnose(file, src) {
			out = append(out, Finding{Path: file, Diagnostic: d})
		}
	}
	return out, nil
}

// HasErrors reports whether any finding is an error.
func HasErrors(findings []Finding) bool {
	return slices.ContainsFunc(findings, func(f Finding) bool {
		return f.Diagnostic.Severity == analysis.Error
	})
}

// expand lists the files a path stands for.
func expand(ctx context.Context, path string) ([]string, error) {
	info, err := os.Stat(path)
	if err != nil {
		return nil, fmt.Errorf("check %s: %w", path, err)
	}
	if !info.IsDir() {
		return []string{path}, nil
	}
	var files []string
	err = filepath.WalkDir(path, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if err := ctx.Err(); err != nil {
			return err
		}
		if !d.IsDir() && isYAML(p) {
			files = append(files, p)
		}
		return nil
	})
	if err != nil {
		return nil, fmt.Errorf("search %s: %w", path, err)
	}
	return files, nil
}

func isYAML(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	return ext == ".yaml" || ext == ".yml"
}
