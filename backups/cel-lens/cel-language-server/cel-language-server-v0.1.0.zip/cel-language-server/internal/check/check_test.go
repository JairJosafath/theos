package check

import (
	"bytes"
	"context"
	"errors"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"c4factory.local/cel-lens/cel-language-server/internal/analysis"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

const badPolicy = "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: \"1 +\"\n"

func TestFilesSearch(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	for _, name := range []string{"b.yaml", "a.yml", "sub/c.YAML", "skip.txt", "sub/skip.json"} {
		path := filepath.Join(dir, name)
		if err := os.MkdirAll(filepath.Dir(path), 0o750); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(badPolicy), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	odd := filepath.Join(dir, "skip.txt")

	findings, err := Files(context.Background(), []string{dir, odd, dir})
	if err != nil {
		t.Fatal(err)
	}
	var got []string
	for _, f := range findings {
		got = append(got, strings.TrimPrefix(f.Path, dir+string(filepath.Separator)))
	}
	want := "a.yml b.yaml skip.txt sub/c.YAML"
	if strings.Join(got, " ") != want {
		t.Errorf("Files paths = %q, want %q", got, want)
	}
}

func TestFilesErrors(t *testing.T) {
	t.Parallel()
	if _, err := Files(context.Background(), []string{"nope.yaml"}); !errors.Is(err, os.ErrNotExist) {
		t.Errorf("Files(missing) error = %v, want os.ErrNotExist", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Files(ctx, []string{t.TempDir()}); !errors.Is(err, context.Canceled) {
		t.Errorf("Files(cancelled) error = %v, want context.Canceled", err)
	}
}

func TestHasErrors(t *testing.T) {
	t.Parallel()
	at := func(s analysis.Severity) Finding { return Finding{Diagnostic: analysis.Diagnostic{Severity: s}} }
	tests := []struct {
		name string
		in   []Finding
		want bool
	}{
		{"none", nil, false},
		{"warnings only", []Finding{at(2), at(3), at(4)}, false},
		{"error among warnings", []Finding{at(2), at(analysis.Error)}, true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := HasErrors(tt.in); got != tt.want {
				t.Errorf("HasErrors(%s) = %v, want %v", tt.name, got, tt.want)
			}
		})
	}
}

func TestWrite(t *testing.T) {
	t.Parallel()
	f := []Finding{{Path: "p.yaml", Diagnostic: analysis.Diagnostic{
		Range: analysis.Range{
			Start: position.Position{Line: 4, Character: 2},
			End:   position.Position{Line: 4, Character: 6},
		},
		Severity: 2,
		Message:  "careful",
	}}}
	var text, js bytes.Buffer
	if err := WriteText(&text, f); err != nil {
		t.Fatal(err)
	}
	if want := "p.yaml:5:3: warning: careful\n"; text.String() != want {
		t.Errorf("WriteText = %q, want %q", text.String(), want)
	}
	if err := WriteJSON(&js, f); err != nil {
		t.Fatal(err)
	}
	want := `[
  {
    "path": "p.yaml",
    "range": {
      "start": {
        "line": 5,
        "column": 3
      },
      "end": {
        "line": 5,
        "column": 7
      }
    },
    "severity": "warning",
    "message": "careful"
  }
]
`
	if js.String() != want {
		t.Errorf("WriteJSON = %q, want %q", js.String(), want)
	}
}
