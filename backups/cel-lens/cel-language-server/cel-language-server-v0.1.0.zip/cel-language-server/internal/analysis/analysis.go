// Package analysis checks the CEL in Kubernetes YAML the way the API server
// does, and reports what it finds as editor diagnostics with ranges in the
// file. It reads ValidatingAdmissionPolicy documents, the matchConditions of
// webhook configurations and the x-kubernetes-validations of CustomResourceDefinitions; the schemas come from [k8sschema], so it works
// offline.
package analysis

import (
	"context"
	"errors"
	"fmt"
	"slices"

	"c4factory.local/cel-lens/cel-language-server/internal/k8sschema"
	"c4factory.local/cel-lens/cel-language-server/internal/locate"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// Source is the Source of every diagnostic.
const Source = "cel"

// Severity is how serious a diagnostic is, with the values of LSP 3.17.
type Severity int

// The severities of LSP 3.17 that Diagnose uses.
const (
	// Error is a problem the API server would reject.
	Error Severity = 1
)

// String returns the LSP name of s: "error", "warning", "information" or
// "hint"; any other value gives "unknown".
func (s Severity) String() string {
	names := [...]string{1: "error", 2: "warning", 3: "information", 4: "hint"}
	if s < 1 || int(s) >= len(names) {
		return "unknown"
	}
	return names[s]
}

// Range is a span of a file in LSP positions. End is exclusive; an empty
// range marks a place, such as the end of an expression.
type Range struct {
	Start, End position.Position
}

// Diagnostic is one problem found in a file.
type Diagnostic struct {
	// Range is where the problem is in the file.
	Range Range
	// Severity is how serious the problem is.
	Severity Severity
	// Message says what is wrong, in the API server's words.
	Message string
	// Source is always [Source].
	Source string
}

// Diagnose checks the YAML file src and returns what is wrong with its CEL,
// ordered by position. path names the file in the messages of failures that
// are not the author's. A file with no problems, an empty file and a file with
// no policies give nil. A YAML syntax error gives one diagnostic, and a
// document that does not decode as its kind gives one diagnostic for that
// document. Diagnose is safe for concurrent use.
func Diagnose(path string, src []byte) []Diagnostic {
	idx := position.NewIndex(src)
	docs, err := locate.Find(context.Background(), src)
	if err != nil {
		var se *locate.SyntaxError
		if errors.As(err, &se) {
			return []Diagnostic{lineDiagnostic(idx, se.Line, se.Column, se.Msg)}
		}
		return []Diagnostic{lineDiagnostic(idx, 1, 1, fmt.Sprintf("cannot read %s: %v", path, err))}
	}
	mapper, err := k8sschema.NewRESTMapper()
	if err != nil {
		return []Diagnostic{lineDiagnostic(idx, 1, 1, fmt.Sprintf("cannot check %s: %v", path, err))}
	}
	resolver := &k8sschema.Resolver{}
	var out []Diagnostic
	for _, doc := range docs {
		out = append(out, diagnoseDocument(&checker{path: path, idx: idx, resolver: resolver, mapper: mapper}, doc)...)
	}
	slices.SortStableFunc(out, func(a, b Diagnostic) int {
		if a.Range.Start.Line != b.Range.Start.Line {
			return a.Range.Start.Line - b.Range.Start.Line
		}
		return a.Range.Start.Character - b.Range.Start.Character
	})
	return out
}

func diagnoseDocument(c *checker, doc locate.Document) []Diagnostic {
	c.body = bodyOf(doc)
	switch doc.Kind {
	case "ValidatingAdmissionPolicy":
		return c.policy(doc)
	case "ValidatingWebhookConfiguration", "MutatingWebhookConfiguration":
		return c.webhooks(doc)
	case "CustomResourceDefinition":
		return c.crd(doc)
	}
	return nil
}

// lineDiagnostic marks the line of a file from a 1-based column to its end.
func lineDiagnostic(idx *position.Index, line, column int, msg string) Diagnostic {
	start := position.Position{Line: line - 1, Character: column - 1}
	end := start
	if off, err := idx.Offset(position.Position{Line: line - 1, Character: 1 << 30}); err == nil {
		if p, err := idx.Position(off); err == nil {
			end = p
		}
	}
	if end.Character < start.Character {
		end = start
	}
	return Diagnostic{Range: Range{Start: start, End: end}, Severity: Error, Message: msg, Source: Source}
}
