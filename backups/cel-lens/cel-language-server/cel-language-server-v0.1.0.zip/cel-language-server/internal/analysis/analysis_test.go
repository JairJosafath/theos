package analysis

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

var update = flag.Bool("update", false, "rewrite the golden files")

// inputs lists the YAML files that have a golden file next to them.
func inputs() ([]string, error) {
	var all []string
	for _, dir := range []string{"policies", "crds"} {
		files, err := filepath.Glob(filepath.Join("..", "..", "testdata", dir, "*.yaml"))
		if err != nil {
			return nil, err
		}
		all = append(all, files...)
	}
	return all, nil
}

// format writes diagnostics as line:col-line:col: message, counting from 1.
func format(ds []Diagnostic) string {
	var b strings.Builder
	for _, d := range ds {
		fmt.Fprintf(&b, "%d:%d-%d:%d: %s\n", d.Range.Start.Line+1, d.Range.Start.Character+1,
			d.Range.End.Line+1, d.Range.End.Character+1, d.Message)
	}
	return b.String()
}

func TestDiagnoseGolden(t *testing.T) {
	t.Parallel()
	files, err := inputs()
	if err != nil || len(files) == 0 {
		t.Fatalf("no testdata: %v", err)
	}
	for _, file := range files {
		t.Run(filepath.Base(filepath.Dir(file))+"/"+strings.TrimSuffix(filepath.Base(file), ".yaml"), func(t *testing.T) {
			t.Parallel()
			src, err := os.ReadFile(file)
			if err != nil {
				t.Fatal(err)
			}
			got := format(Diagnose(file, src))
			golden := strings.TrimSuffix(file, ".yaml") + ".golden"
			if *update {
				if err := os.WriteFile(golden, []byte(got), 0o600); err != nil {
					t.Fatal(err)
				}
			}
			want, err := os.ReadFile(golden)
			if err != nil {
				t.Fatal(err)
			}
			if got != string(want) {
				t.Errorf("Diagnose(%s) =\n%s\nwant\n%s", file, got, want)
			}
		})
	}
}

func TestDiagnoseInput(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		src  string
		want string
	}{
		{"empty", "", ""},
		{"comment only", "# nothing\n", ""},
		{"not a policy", "apiVersion: v1\nkind: ConfigMap\ndata:\n  a: object.spec.replica\n", ""},
		{"scalar document", "just text\n", ""},
		{"valid policy", "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: object.a == 1\n", ""},
		{"crlf", "apiVersion: admissionregistration.k8s.io/v1\r\nkind: ValidatingAdmissionPolicy\r\nspec:\r\n  validations:\r\n    - expression: \"1 +\"\r\n", "5:23-5:23: Syntax error"},
		{"v1beta1 policy", "apiVersion: admissionregistration.k8s.io/v1beta1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: object.a ==\n", "5:30-5:30: Syntax error"},
		{"wrong field type", "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: [1]\n", "1:1-1:"},
		{"webhook wrong field type", "apiVersion: admissionregistration.k8s.io/v1\nkind: MutatingWebhookConfiguration\nwebhooks: 3\n", "1:1-1:"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := format(Diagnose("x.yaml", []byte(tt.src)))
			if tt.want == "" && got != "" || !strings.HasPrefix(got, tt.want) {
				t.Errorf("Diagnose(%q) = %q, want prefix %q", tt.src, got, tt.want)
			}
			if tt.want != "" && strings.Count(got, "\n") != 1 {
				t.Errorf("Diagnose(%q) = %q, want one diagnostic", tt.src, got)
			}
		})
	}
}

func TestDiagnoseFields(t *testing.T) {
	t.Parallel()
	src := "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: object.a ==\n"
	got := Diagnose("x.yaml", []byte(src))
	if len(got) != 1 || got[0].Severity != Error || got[0].Source != "cel" {
		t.Errorf("Diagnose(policy) = %+v, want one Error with source cel", got)
	}
}

func FuzzDiagnose(f *testing.F) {
	files, _ := inputs()
	for _, file := range files {
		if src, err := os.ReadFile(file); err == nil {
			f.Add(src)
		}
	}
	f.Fuzz(func(_ *testing.T, src []byte) {
		Diagnose("fuzz.yaml", src)
	})
}

func BenchmarkDiagnose(b *testing.B) {
	var src strings.Builder
	src.WriteString("apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nmetadata:\n  name: big\nspec:\n  matchConstraints:\n    resourceRules:\n      - apiGroups: [\"apps\"]\n        apiVersions: [\"v1\"]\n        operations: [\"CREATE\"]\n        resources: [\"deployments\"]\n  variables:\n    - name: replicas\n      expression: object.spec.replicas\n  validations:\n")
	for i := range 330 {
		fmt.Fprintf(&src, "    - expression: variables.replicas <= %d && object.metadata.name.startsWith('a')\n      message: too many replicas\n      messageExpression: \"'replicas ' + string(variables.replicas)\"\n", i+1)
	}
	in := []byte(src.String())
	for b.Loop() {
		Diagnose("bench.yaml", in)
	}
}
