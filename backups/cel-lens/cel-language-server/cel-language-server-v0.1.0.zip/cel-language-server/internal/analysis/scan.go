package analysis

import "strings"

// binding is the iteration variable of a macro that encloses the cursor, such
// as c in containers.all(c, c.
type binding struct {
	// name is the variable; receiver is the text of the expression the macro
	// is called on, whose elements the variable stands for.
	name, receiver string
}

// cursor is what the text before the cursor says about what may come next.
type cursor struct {
	// inString is true when the cursor is in a string literal or a comment,
	// where nothing is completed.
	inString bool
	// member is true after a "."; receiver is then the text of the expression
	// left of it.
	member   bool
	receiver string
	// bindings are the iteration variables in scope, outermost first.
	bindings []binding
}

// scanCursor reads the text of an expression up to the cursor. The text often
// does not parse, so it does not use the CEL parser: it tracks strings and
// brackets, which is all that finding a receiver chain and the enclosing
// macros needs. isMacro tells which names are macros called on a receiver.
func scanCursor(text string, isMacro func(string) bool) cursor {
	s := scanner{text: text, match: map[int]int{}, quoteStart: map[int]int{}}
	if !s.scan() {
		return cursor{inString: true}
	}
	var cur cursor
	p := len(text)
	for p > 0 && isIdent(text[p-1]) {
		p--
	}
	if p > 0 && text[p-1] == '.' {
		cur.member = true
		cur.receiver = text[s.receiverStart(p-1) : p-1]
	}
	for _, open := range s.opens {
		if b, ok := s.macroBinding(open, isMacro); ok {
			cur.bindings = append(cur.bindings, b)
		}
	}
	return cur
}

type scanner struct {
	text string
	// opens are the brackets not closed at the end of text.
	opens []int
	// match maps the index of a closing bracket to its opening one.
	match map[int]int
	// quoteStart maps the index of the last byte of a string literal to its first.
	quoteStart map[int]int
}

// scan fills the scanner and reports false when text ends inside a string or
// a comment.
func (s *scanner) scan() bool {
	text := s.text
	for i := 0; i < len(text); {
		switch c := text[i]; c {
		case '\'', '"':
			end, ok := stringEnd(text, i)
			if !ok {
				return false
			}
			s.quoteStart[end-1] = i
			i = end
			continue
		case '/':
			if strings.HasPrefix(text[i:], "//") {
				nl := strings.IndexByte(text[i:], '\n')
				if nl < 0 {
					return false
				}
				i += nl
			}
		case '(', '[', '{':
			s.opens = append(s.opens, i)
		case ')', ']', '}':
			if n := len(s.opens); n > 0 {
				s.match[i] = s.opens[n-1]
				s.opens = s.opens[:n-1]
			}
		}
		i++
	}
	return true
}

// stringEnd returns the index after the string literal that starts with the
// quote at text[i], and false when it is not closed. A literal after r or R
// has no escapes; one that opens with three quotes may span lines.
func stringEnd(text string, i int) (int, bool) {
	q := text[i : i+1]
	if strings.HasPrefix(text[i:], strings.Repeat(q, 3)) {
		q = strings.Repeat(q, 3)
	}
	raw := i > 0 && (text[i-1] == 'r' || text[i-1] == 'R')
	for j := i + len(q); j < len(text); j++ {
		switch {
		case text[j] == '\\' && !raw:
			j++
		case strings.HasPrefix(text[j:], q):
			return j + len(q), true
		case text[j] == '\n' && len(q) == 1:
			return 0, false
		}
	}
	return 0, false
}

// receiverStart returns where the receiver chain that ends before text[end]
// starts: names, dots, calls, indexes and string literals.
func (s *scanner) receiverStart(end int) int {
	i := end
	for i > 0 {
		c := s.text[i-1]
		switch {
		case isIdent(c) || c == '.':
			i--
		case c == ')' || c == ']':
			open, ok := s.match[i-1]
			if !ok {
				return i
			}
			i = open
		case c == '\'' || c == '"':
			start, ok := s.quoteStart[i-1]
			if !ok {
				return i
			}
			i = start
		default:
			return i
		}
	}
	return i
}

// macroBinding returns the iteration variable of the macro call that the
// unclosed bracket at open starts, when the cursor is past its first argument.
func (s *scanner) macroBinding(open int, isMacro func(string) bool) (binding, bool) {
	if s.text[open] != '(' {
		return binding{}, false
	}
	k := open
	for k > 0 && isIdent(s.text[k-1]) {
		k--
	}
	name := s.text[k:open]
	if k == 0 || s.text[k-1] != '.' || !isMacro(name) {
		return binding{}, false
	}
	args := splitArgs(s.text[open+1:])
	v := strings.TrimSpace(args[0])
	if len(args) < 2 || !isIdentifier(v) {
		return binding{}, false
	}
	return binding{name: v, receiver: s.text[s.receiverStart(k-1) : k-1]}, true
}

// splitArgs splits the text of an unfinished argument list at its commas that
// are not inside a string or a bracket.
func splitArgs(text string) []string {
	var args []string
	depth, from := 0, 0
	for i := 0; i < len(text); i++ {
		switch text[i] {
		case '\'', '"':
			end, ok := stringEnd(text, i)
			if !ok {
				return append(args, text[from:])
			}
			i = end - 1
		case '(', '[', '{':
			depth++
		case ')', ']', '}':
			depth--
		case ',':
			if depth == 0 {
				args = append(args, text[from:i])
				from = i + 1
			}
		}
	}
	return append(args, text[from:])
}

// isIdentifier reports whether s is a single CEL name.
func isIdentifier(s string) bool {
	if s == "" || s[0] >= '0' && s[0] <= '9' {
		return false
	}
	for i := range len(s) {
		if !isIdent(s[i]) {
			return false
		}
	}
	return true
}
