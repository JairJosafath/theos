package analysis

import (
	"slices"
	"strings"

	"github.com/google/cel-go/cel"
	"github.com/google/cel-go/common"

	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// Hover explains the name under the cursor in a CEL expression.
type Hover struct {
	// Range covers exactly the name.
	Range Range
	// Signature is the declaration of the name: its type for a variable or a
	// field, one line per overload for a function.
	Signature string
	// Documentation says what the name stands for; empty when nothing is known.
	Documentation string
}

// Explain returns what the name at pos in the YAML file src is: a variable of
// the place the expression is in, a field of a typed object, a function or a
// macro. It returns nil for a position outside a CEL expression, inside a
// string of one, on something that is not a name or whose meaning is unknown,
// and in a file that is not valid YAML. path names the file in messages;
// Explain is safe for concurrent use.
func Explain(path string, src []byte, pos position.Position) *Hover {
	off, err := position.NewIndex(src).Offset(pos)
	if err != nil {
		return nil
	}
	sp, ok := findSpot(path, src, off)
	if !ok {
		return nil
	}
	text := sp.site.Text
	start, end := sp.at, sp.at
	for start > 0 && isIdent(text[start-1]) {
		start--
	}
	for end < len(text) && isIdent(text[end]) {
		end++
	}
	name := text[start:end]
	if !isIdentifier(name) {
		return nil
	}
	called := strings.HasPrefix(strings.TrimLeft(text[end:], " \t"), "(")
	sig, doc, ok := sp.pl.explain(text[:start], name, called)
	if !ok {
		return nil
	}
	from, err1 := sp.idx.Position(sp.site.offs[start])
	to, err2 := sp.idx.Position(sp.site.offs[end])
	if err1 != nil || err2 != nil {
		return nil
	}
	return &Hover{Range: Range{Start: from, End: to}, Signature: sig, Documentation: doc}
}

// explain describes name, which follows the text before of an expression and is
// called when an argument list follows it.
func (p *place) explain(before, name string, called bool) (sig, doc string, ok bool) {
	macros := p.env.Macros()
	env, locals, cur := p.bind(before)
	if cur.inString {
		return "", "", false
	}
	if !cur.member {
		if !called {
			return p.variable(env, locals, name)
		}
		return callable(env, name, false, nil, macros)
	}
	if cur.receiver == "" {
		return "", "", false
	}
	if cur.receiver == "variables" && slices.Contains(p.scope, "variables") {
		for _, v := range p.variables {
			if v.name == name {
				return name + ": " + typeString(v.typ), "", true
			}
		}
		return "", "", false
	}
	t, found := receiverType(env, cur.receiver)
	if !found {
		return "", "", false
	}
	if called {
		return callable(env, name, true, t, macros)
	}
	if info, ok := p.reg[t.TypeName()]; ok && t.Kind() == cel.StructKind {
		if f, ok := info.decl.Fields[name]; ok {
			return name + ": " + f.Type.CelType().String(), strings.TrimSpace(info.docs[name]), true
		}
	}
	return "", "", false
}

// variable describes a variable of the place or of an enclosing macro.
func (p *place) variable(env *cel.Env, locals []named, name string) (sig, doc string, ok bool) {
	for _, v := range slices.Backward(locals) {
		if v.name == name {
			return name + ": " + typeString(v.typ), "", true
		}
	}
	if !slices.Contains(p.scope, name) {
		return "", "", false
	}
	for _, v := range env.Variables() {
		if v.Name() == name {
			return name + ": " + typeString(v.Type()), variableDocs[name], true
		}
	}
	return "", "", false
}

// callable describes the function or macro name, called on a receiver of type
// recv when member is true.
func callable(env *cel.Env, name string, member bool, recv *cel.Type, macros []cel.Macro) (sig, doc string, ok bool) {
	if f, found := env.Functions()[name]; found {
		var sigs []string
		for _, o := range f.OverloadDecls() {
			if o.IsMemberFunction() == member && (!member || len(o.ArgTypes()) > 0 && accepts(o.ArgTypes()[0], recv)) {
				sigs = append(sigs, signature(f, o))
			}
		}
		if len(sigs) > 0 {
			return strings.Join(sigs, "\n"), functionDocumentation(f), true
		}
	}
	if member && recv.Kind() != cel.ListKind && recv.Kind() != cel.MapKind && recv.Kind() != cel.DynKind {
		return "", "", false
	}
	var sigs []string
	for _, m := range macros {
		if m.Function() != name || m.IsReceiverStyle() != member {
			continue
		}
		sigs = append(sigs, macroSignature(m))
		if d, ok := m.(interface{ Documentation() *common.Doc }); ok && doc == "" {
			doc = d.Documentation().Description
		}
	}
	if len(sigs) == 0 {
		return "", "", false
	}
	slices.Sort(sigs)
	return strings.Join(sigs, "\n"), doc, true
}

// macroSignature writes a macro as it is called: the iteration variable first
// for a macro on a receiver, then its other arguments.
func macroSignature(m cel.Macro) string {
	args := make([]string, m.ArgCount())
	for i := range args {
		args[i] = "arg" + string(rune('1'+i))
	}
	if m.IsReceiverStyle() && len(args) > 0 {
		args[0] = "x"
	}
	sig := m.Function() + "(" + strings.Join(args, ", ") + ")"
	if m.IsReceiverStyle() {
		sig = "<receiver>." + sig
	}
	return "macro " + sig
}
