package analysis

import (
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode/utf8"

	"github.com/google/cel-go/cel"
	"go.yaml.in/yaml/v3"
	sigsyaml "sigs.k8s.io/yaml"

	admissionv1 "k8s.io/api/admissionregistration/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
	plugincel "k8s.io/apiserver/pkg/admission/plugin/cel"
	apiservercel "k8s.io/apiserver/pkg/cel"
	"k8s.io/apiserver/pkg/cel/common"
	"k8s.io/apiserver/pkg/cel/environment"
	"k8s.io/apiserver/pkg/cel/openapi"
	"k8s.io/kube-openapi/pkg/validation/spec"

	"c4factory.local/cel-lens/cel-language-server/internal/k8sschema"
	"c4factory.local/cel-lens/cel-language-server/internal/locate"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// maxKinds is how many kinds of one policy are checked, as in the API server.
const maxKinds = 10

// mode is the environment the API server validates new expressions in.
const mode = environment.NewExpressions

// checker checks the expressions of one document.
type checker struct {
	path     string
	idx      *position.Index
	body     *yaml.Node
	resolver *k8sschema.Resolver
	mapper   *k8sschema.RESTMapper
	out      []Diagnostic
}

// site is an expression with its place in the file.
type site struct {
	locate.Expression
	node *yaml.Node
	// offs maps the bytes of Text to file offsets; nil when mapping failed.
	offs []int
}

func (c *checker) sites(doc locate.Document) []site {
	sites := make([]site, 0, len(doc.Expressions))
	for _, e := range doc.Expressions {
		s := site{Expression: e, node: nodeAt(c.body, e.Path)}
		if s.node != nil {
			s.offs, _ = c.idx.Scalar(s.node)
		}
		sites = append(sites, s)
	}
	return sites
}

var pathSegment = regexp.MustCompile(`^([^\[]+)(?:\[(\d+)\])?$`)

// nodeAt returns the node that the path of a [locate.Expression] names.
func nodeAt(n *yaml.Node, path string) *yaml.Node {
	for seg := range strings.SplitSeq(path, ".") {
		m := pathSegment.FindStringSubmatch(seg)
		if m == nil || n == nil || n.Kind != yaml.MappingNode {
			return nil
		}
		var next *yaml.Node
		for i := 0; i+1 < len(n.Content); i += 2 {
			if n.Content[i].Value == m[1] {
				next = n.Content[i+1]
			}
		}
		if next != nil && m[2] != "" {
			i, _ := strconv.Atoi(m[2])
			if next.Kind != yaml.SequenceNode || i >= len(next.Content) {
				return nil
			}
			next = next.Content[i]
		}
		n = next
	}
	return n
}

// index returns the number in the first [i] of a path.
func index(path string) int {
	i, j := strings.IndexByte(path, '['), strings.IndexByte(path, ']')
	n, _ := strconv.Atoi(path[i+1 : j])
	return n
}

// docError is the one diagnostic of a document that does not decode as its
// kind, on the line where the document starts.
func (c *checker) docError(kind string, err error) []Diagnostic {
	return []Diagnostic{c.docDiagnostic(fmt.Sprintf("invalid %s: %v", kind, err))}
}

func (c *checker) docDiagnostic(msg string) Diagnostic {
	return lineDiagnostic(c.idx, c.body.Line, c.body.Column, msg)
}

func decode(doc locate.Document, v any) error {
	b, err := yaml.Marshal(doc.Node)
	if err != nil {
		return err
	}
	return sigsyaml.Unmarshal(b, v)
}

// target is a kind that a policy's expressions are checked against.
type target struct {
	// label names the kind in messages; empty when there is only one target.
	label  string
	object *apiservercel.DeclType
}

func (c *checker) policy(doc locate.Document) []Diagnostic {
	var policy admissionv1.ValidatingAdmissionPolicy
	if err := decode(doc, &policy); err != nil {
		return c.docError(doc.Kind, err)
	}
	if len(doc.Expressions) == 0 {
		return nil
	}
	sc := scope{}
	if pk := policy.Spec.ParamKind; pk != nil {
		sc.hasParams = true
		if gv, err := schema.ParseGroupVersion(pk.APIVersion); err == nil {
			sc.params = c.declType(gv.WithKind(pk.Kind), "Params")
		}
	}
	sites := c.sites(doc)
	targets := c.targets(&policy)
	for _, t := range targets {
		sc.object = t.object
		if err := c.checkPolicy(sc, t.label, &policy, sites); err != nil {
			return []Diagnostic{c.docDiagnostic(fmt.Sprintf("cannot check %s: %v", c.path, err))}
		}
	}
	return c.out
}

// targets returns the kinds that the policy matches and the embedded schemas
// know; a policy that matches none is checked once, with object as dyn.
func (c *checker) targets(policy *admissionv1.ValidatingAdmissionPolicy) []target {
	var ts []target
	gvks := c.kinds(policy)
	for _, gvk := range gvks {
		if dt := c.declType(gvk, ""); dt != nil {
			ts = append(ts, target{label: gvk.GroupVersion().String() + " " + gvk.Kind, object: dt})
		}
	}
	if len(ts) == 0 {
		return []target{{}}
	}
	if len(ts) == 1 {
		ts[0].label = ""
	}
	return ts
}

// declType returns the CEL type of a kind's schema, or nil when the kind is
// not in the embedded schemas.
func (c *checker) declType(gvk schema.GroupVersionKind, suffix string) *apiservercel.DeclType {
	dt, _ := c.declAndSchema(gvk, suffix)
	return dt
}

// declAndSchema returns the CEL type of a kind's schema with the schema it
// comes from, or nil and nil when the kind is not in the embedded schemas.
func (c *checker) declAndSchema(gvk schema.GroupVersionKind, suffix string) (*apiservercel.DeclType, *spec.Schema) {
	s, err := c.resolver.ResolveSchema(gvk)
	if err != nil {
		return nil, nil
	}
	dt := common.SchemaDeclType(&openapi.Schema{Schema: s}, true)
	if dt == nil {
		return nil, nil
	}
	return dt.MaybeAssignTypeName(gvk.Kind + suffix), s
}

// kinds lists the kinds of the policy's resource rules like the API server's
// type checker: wildcards and subresources are skipped, and at most maxKinds
// are taken, in the order of group, version and kind.
func (c *checker) kinds(policy *admissionv1.ValidatingAdmissionPolicy) []schema.GroupVersionKind {
	mc := policy.Spec.MatchConstraints
	if mc == nil {
		return nil
	}
	seen := map[schema.GroupVersionKind]bool{}
	var out []schema.GroupVersionKind
	for _, rule := range mc.ResourceRules {
		groups, versions, resources := concrete(rule.APIGroups, false), concrete(rule.APIVersions, false), concrete(rule.Resources, true)
		for _, g := range groups {
			for _, v := range versions {
				for _, r := range resources {
					found, err := c.mapper.KindsFor(schema.GroupVersionResource{Group: g, Version: v, Resource: r})
					if err != nil {
						continue
					}
					for _, k := range found {
						if !seen[k] && !k.Empty() && len(out) < maxKinds {
							seen[k] = true
							out = append(out, k)
						}
					}
				}
			}
		}
	}
	sort.Slice(out, func(i, j int) bool { return out[i].String() < out[j].String() })
	return out
}

// concrete returns the names without wildcards; for a list that holds one
// wildcard and skip is false, it returns nothing, as the API server gives up.
func concrete(names []string, skip bool) []string {
	out := make([]string, 0, len(names))
	for _, n := range names {
		switch {
		case !strings.ContainsAny(n, "*/"):
			out = append(out, n)
		case !skip && strings.Contains(n, "*"):
			return nil
		}
	}
	return out
}

// recorder is the compiler of a composited compiler that keeps the issues of
// the last expression, which the API server's result type would flatten.
type recorder struct {
	comp *plugincel.CompositedCompiler
	ast  *cel.Ast
	iss  *cel.Issues
}

func (r *recorder) CompileCELExpression(a plugincel.ExpressionAccessor, _ plugincel.OptionalVariableDeclarations, m environment.Type) plugincel.CompilationResult {
	env, err := r.comp.Env(m)
	if err != nil {
		r.ast, r.iss = nil, nil
		return plugincel.CompilationResult{Error: &apiservercel.Error{Type: apiservercel.ErrorTypeInternal, Detail: err.Error()}}
	}
	r.ast, r.iss = env.Compile(a.GetExpression())
	if r.iss.Err() != nil {
		return plugincel.CompilationResult{Error: &apiservercel.Error{Type: apiservercel.ErrorTypeInvalid, Detail: r.iss.String()}}
	}
	return plugincel.CompilationResult{OutputType: r.ast.OutputType()}
}

// variable is a named expression of a policy.
type variable struct {
	name, text string
}

func (v variable) GetExpression() string    { return v.text }
func (v variable) ReturnTypes() []*cel.Type { return []*cel.Type{cel.AnyType} }
func (v variable) GetName() string          { return v.name }

// resultTypes are the types an expression of the site's kind may evaluate to.
func resultTypes(s site) []*cel.Type {
	if s.Kind == locate.MessageExpression {
		return []*cel.Type{cel.StringType}
	}
	if s.Kind == locate.AuditAnnotation {
		return []*cel.Type{cel.StringType, cel.NullType}
	}
	if s.Kind == locate.Variable {
		return []*cel.Type{cel.AnyType}
	}
	return []*cel.Type{cel.BoolType}
}

// checkPolicy compiles the policy's expressions in order against sc, so each
// variable is typed before the expressions that follow it.
func (c *checker) checkPolicy(sc scope, label string, policy *admissionv1.ValidatingAdmissionPolicy, sites []site) error {
	es, err := sc.envSet()
	if err != nil {
		return err
	}
	comp, err := plugincel.NewCompositedCompilerForTypeChecking(es)
	if err != nil {
		return err
	}
	rec := &recorder{comp: comp}
	comp.Compiler = rec
	for _, s := range sites {
		if s.Kind == locate.Variable {
			name := ""
			if i := index(s.Path); i < len(policy.Spec.Variables) {
				name = policy.Spec.Variables[i].Name
			}
			comp.CompileAndStoreVariable(variable{name: name, text: s.Text}, plugincel.OptionalVariableDeclarations{}, mode)
		} else {
			rec.CompileCELExpression(variable{text: s.Text}, plugincel.OptionalVariableDeclarations{}, mode)
		}
		c.report(s, label, rec.ast, rec.iss)
	}
	return nil
}

// webhooks checks the matchConditions of a webhook configuration.
func (c *checker) webhooks(doc locate.Document) []Diagnostic {
	var err error
	switch doc.Kind {
	case "ValidatingWebhookConfiguration":
		err = decode(doc, new(admissionv1.ValidatingWebhookConfiguration))
	default:
		err = decode(doc, new(admissionv1.MutatingWebhookConfiguration))
	}
	if err != nil {
		return c.docError(doc.Kind, err)
	}
	if len(doc.Expressions) == 0 {
		return nil
	}
	es, err := scope{}.envSet()
	if err == nil {
		var env *cel.Env
		if env, err = es.Env(mode); err == nil {
			for _, s := range c.sites(doc) {
				ast, iss := env.Compile(s.Text)
				c.report(s, "", ast, iss)
			}
		}
	}
	if err != nil {
		return []Diagnostic{c.docDiagnostic(fmt.Sprintf("cannot check %s: %v", c.path, err))}
	}
	return c.out
}

// report adds a diagnostic for each error of a compilation, or for the result
// type of an expression that compiled but has the wrong one.
func (c *checker) report(s site, label string, ast *cel.Ast, iss *cel.Issues) {
	prefix := ""
	if label != "" {
		prefix = label + ": "
	}
	if iss.Err() != nil {
		for _, e := range iss.Errors() {
			off := byteOffset(s.Text, e.Location.Line(), e.Location.Column())
			start, end := tokenAt(s.Text, off)
			c.add(s, start, end, prefix+e.Message)
		}
		return
	}
	if ast == nil {
		return
	}
	want, got := resultTypes(s), ast.OutputType()
	for _, w := range want {
		if got.IsExactType(w) || w == cel.AnyType || got.Kind() == cel.DynKind {
			return
		}
	}
	reason := fmt.Sprintf("must evaluate to %v but got %v", want[0], got)
	if len(want) > 1 {
		reason = fmt.Sprintf("must evaluate to one of %v but got %v", want, got)
	}
	trimmed := strings.TrimSpace(s.Text)
	start := strings.Index(s.Text, trimmed)
	c.add(s, start, start+len(trimmed), prefix+reason)
}

// add records a diagnostic for the bytes [start, end) of the expression's text.
func (c *checker) add(s site, start, end int, msg string) {
	var from, to position.Position
	var err error
	if s.offs != nil {
		if from, err = c.idx.Position(s.offs[start]); err == nil {
			to, err = c.idx.Position(s.offs[end])
		}
	}
	if s.offs == nil || err != nil {
		from = position.Position{Line: s.Line - 1, Character: s.Column - 1}
		to = from
	}
	c.out = append(c.out, Diagnostic{Range: Range{Start: from, End: to}, Severity: Error, Message: msg, Source: Source})
}

// byteOffset converts a CEL location, a 1-based line and a 0-based column
// counted in characters, to a byte offset in text, clamped to len(text).
func byteOffset(text string, line, col int) int {
	off := 0
	for ; line > 1; line-- {
		i := strings.IndexByte(text[off:], '\n')
		if i < 0 {
			return len(text)
		}
		off += i + 1
	}
	for ; col > 0 && off < len(text); col-- {
		_, w := utf8.DecodeRuneInString(text[off:])
		off += w
	}
	return off
}

// tokenAt returns the bytes of the token CEL means by an error at off: the
// identifier there, or after the "." there, or the operator there, else one
// character.
func tokenAt(text string, off int) (start, end int) {
	start = off
	if start+1 < len(text) && text[start] == '.' && isIdent(text[start+1]) {
		start++
	}
	end = start
	for end < len(text) && isIdent(text[end]) {
		end++
	}
	if end == start {
		for end < len(text) && strings.IndexByte("<>=!&|+-*/%", text[end]) >= 0 {
			end++
		}
	}
	if end == start && start < len(text) {
		_, w := utf8.DecodeRuneInString(text[start:])
		end += w
	}
	return start, end
}

func isIdent(b byte) bool {
	return b == '_' || b >= '0' && b <= '9' || b >= 'a' && b <= 'z' || b >= 'A' && b <= 'Z' || b >= 0x80
}
