package analysis

import (
	"fmt"
	"strings"
	"testing"

	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// explain returns the hover at the | in src.
func explain(src string) *Hover {
	i := strings.IndexByte(src, '|')
	before := src[:i]
	pos := position.Position{Line: strings.Count(before, "\n"), Character: len(before) - strings.LastIndexByte(before, '\n') - 1}
	return Explain("test.yaml", []byte(before+src[i+1:]), pos)
}

func TestExplain(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		src  string
		text string // the text the range covers
		sig  string // the signature
		doc  string // a part of the documentation
	}{
		{"variable", policy("obj|ect.spec.replicas > 0"), "object", "object: Deployment", "null for DELETE"},
		{"variable at its end", policy("object|.spec.replicas > 0"), "object", "object: Deployment", "null for DELETE"},
		{"request variable", policy("req|uest.userInfo.username != ''"), "request", "request: ", "admission request"},
		{"variable in a match condition", strings.Replace(policy("true"), "expression: true\n  variables", "expression: old|Object != null\n  variables", 1), "oldObject", "oldObject: Deployment", "null for CREATE"},
		{"field with description", policy("object.spec.repl|icas > 0"), "replicas", "replicas: int", "Number of desired pods."},
		{"field of a request", policy("request.user|Info.username != ''"), "userInfo", "userInfo: ", ""},
		{"field of an iteration variable", policy("object.spec.template.spec.containers.all(c, c.im|age != '')"), "image", "image: string", ""},
		{"iteration variable", policy("object.spec.template.spec.containers.all(c, |c.image != '')"), "c", "c: ", ""},
		{"policy variable", policy("variables.repl|icas > 0"), "replicas", "replicas: int", ""},
		{"function", policy("si|ze(object.metadata.name) > 0"), "size", "size(string) -> int", ""},
		{"member function", policy("object.metadata.name.start|sWith('a')"), "startsWith", "string.startsWith(string) -> bool", ""},
		{"macro", policy("object.spec.template.spec.containers.al|l(c, true)"), "all", "macro <receiver>.all(x, arg2)", ""},
		{"self in a CRD rule", fmt.Sprintf(crd, "true", "se|lf.count > 0"), "self", "self: ", "schema node"},
		{"field in a CRD rule", fmt.Sprintf(crd, "true", "self.co|unt > 0"), "count", "count: int", "How many."},
		{"member function on a dotted receiver in a CRD rule", fmt.Sprintf(crd, "true", "self.tags.si|ze() > 0"), "size", "size(", ""},
		{"macro on a dotted receiver in a CRD rule", fmt.Sprintf(crd, "true", "self.tags.al|l(t, t.key != '')"), "all", "macro <receiver>.all(", ""},
		{"field of an iteration variable in a CRD rule", fmt.Sprintf(crd, "true", "self.tags.all(t, t.k|ey != '')"), "key", "key: string", ""},
		{"iteration variable of a dotted receiver in a CRD rule", fmt.Sprintf(crd, "true", "self.tags.all(t, |t.key != '')"), "t", "t: ", ""},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			h := explain(tt.src)
			if h == nil {
				t.Fatalf("Explain(%q) = nil, want a hover", tt.name)
			}
			if !strings.Contains(h.Signature, tt.sig) {
				t.Errorf("Explain(%q).Signature = %q, want it to contain %q", tt.name, h.Signature, tt.sig)
			}
			if !strings.Contains(h.Documentation, tt.doc) {
				t.Errorf("Explain(%q).Documentation = %q, want it to contain %q", tt.name, h.Documentation, tt.doc)
			}
			if h.Range.Start.Line != h.Range.End.Line {
				t.Fatalf("Explain(%q).Range = %+v, want one line", tt.name, h.Range)
			}
			line := strings.Split(strings.Replace(tt.src, "|", "", 1), "\n")[h.Range.Start.Line]
			if got := line[h.Range.Start.Character:h.Range.End.Character]; got != tt.text {
				t.Errorf("Explain(%q).Range covers %q, want %q", tt.name, got, tt.text)
			}
		})
	}
}

func TestExplainFunctionOverloads(t *testing.T) {
	t.Parallel()
	h := explain(policy("si|ze(object.metadata.name) > 0"))
	if h == nil || strings.Count(h.Signature, "\n") < 2 {
		t.Fatalf("Explain(size) = %+v, want one signature line per overload", h)
	}
}

func TestExplainNothing(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name, src string
	}{
		{"yaml key", strings.Replace(policy("true"), "name: demo", "na|me: demo", 1)},
		{"in a string", policy("object.metadata.name == 'ob|ject'")},
		{"on an operator", policy("object.spec.replicas |> 0")},
		{"on a number", policy("object.spec.replicas > 1|0")},
		{"unknown name", policy("undefi|ned > 0")},
		{"unknown field", policy("object.spec.undefi|ned > 0")},
		{"variable not in the place", strings.Replace(policy("true"), "expression: true\n  variables", "expression: par|ams != null\n  variables", 1)},
		{"not yaml", "a: [\n  b|\n"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if h := explain(tt.src); h != nil {
				t.Errorf("Explain(%q) = %+v, want nil", tt.name, h)
			}
		})
	}
}
