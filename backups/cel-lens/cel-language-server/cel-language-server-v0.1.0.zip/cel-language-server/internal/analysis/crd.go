package analysis

import (
	"context"
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"k8s.io/apiextensions-apiserver/pkg/apis/apiextensions"
	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	"k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/validation"
	"k8s.io/apimachinery/pkg/util/validation/field"

	"c4factory.local/cel-lens/cel-language-server/internal/locate"
)

// celIssue is one error of a CEL compiler in the text API servers print:
// "ERROR: <input>:line:column: message", with a 1-based column, after a
// prefix such as "compilation failed: ".
var celIssue = regexp.MustCompile(`(?m)ERROR: <input>:(\d+):(\d+): (.*)$`)

// bracketKey matches a map key in a field path, such as [spec], but not an
// index such as [0].
var bracketKey = regexp.MustCompile(`\[([^\]\d][^\]]*|\d+[^\]\d][^\]]*)\]`)

// crd checks the x-kubernetes-validations of a CustomResourceDefinition by
// running the API server's own validation on it and keeping the findings about
// rules, so each version is compiled against its own schema.
func (c *checker) crd(doc locate.Document) []Diagnostic {
	var v1 apiextensionsv1.CustomResourceDefinition
	if err := decode(doc, &v1); err != nil {
		return c.docError(doc.Kind, err)
	}
	if len(doc.Expressions) == 0 {
		return nil
	}
	apiextensionsv1.SetObjectDefaults_CustomResourceDefinition(&v1)
	var crd apiextensions.CustomResourceDefinition
	if err := apiextensionsv1.Convert_v1_CustomResourceDefinition_To_apiextensions_CustomResourceDefinition(&v1, &crd, nil); err != nil {
		return c.docError(doc.Kind, err)
	}
	sites := map[string]site{}
	for _, s := range c.sites(doc) {
		sites[s.Path] = s
	}
	for _, e := range validation.ValidateCustomResourceDefinition(context.Background(), &crd) {
		if !aboutRules(e) {
			continue
		}
		path := bracketKey.ReplaceAllString(e.Field, ".$1")
		for _, p := range versionPaths(path, &v1) {
			if s, ok := sites[p]; ok {
				c.ruleError(s, e.Detail)
			} else if n := nodeAt(c.body, p); n != nil {
				c.out = append(c.out, lineDiagnostic(c.idx, n.Line, n.Column, e.Detail))
			}
		}
	}
	return c.out
}

// versionPaths returns the paths in the file that a field path of the
// validated CRD stands for. Defaulting moves a schema that all versions share
// to spec.validation, so there the error belongs to each version's schema.
func versionPaths(path string, crd *apiextensionsv1.CustomResourceDefinition) []string {
	rest, ok := strings.CutPrefix(path, "spec.validation.")
	if !ok {
		return []string{path}
	}
	var paths []string
	for i, v := range crd.Spec.Versions {
		if v.Schema != nil {
			paths = append(paths, fmt.Sprintf("spec.versions[%d].schema.%s", i, rest))
		}
	}
	return paths
}

// aboutRules reports whether e is about a rule or messageExpression, or is the
// cost total of a schema's rules.
func aboutRules(e *field.Error) bool {
	switch {
	case strings.Contains(e.Field, ".x-kubernetes-validations["):
		return strings.HasSuffix(e.Field, ".rule") || strings.HasSuffix(e.Field, ".messageExpression") ||
			strings.HasSuffix(e.Field, ".optionalOldSelf")
	case strings.HasSuffix(e.Field, ".openAPIV3Schema"):
		return strings.Contains(e.Detail, "x-kubernetes-validations estimated rule cost total")
	}
	return false
}

// ruleError reports the detail the API server gives for an expression: at each
// token that CEL names, or else on the whole expression.
func (c *checker) ruleError(s site, detail string) {
	issues := celIssue.FindAllStringSubmatch(detail, -1)
	if len(issues) == 0 {
		trimmed := strings.TrimSpace(s.Text)
		start := strings.Index(s.Text, trimmed)
		c.add(s, start, start+len(trimmed), detail)
		return
	}
	for _, m := range issues {
		line, _ := strconv.Atoi(m[1])
		col, _ := strconv.Atoi(m[2])
		start, end := tokenAt(s.Text, byteOffset(s.Text, line, col-1))
		c.add(s, start, end, m[3])
	}
}
