// Package lsp holds the types of the Language Server Protocol 3.17 messages
// the server uses, with their JSON encoding. It follows
// https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/
// and leaves out every field the server does not read or write.
package lsp

// Method names the server handles or sends.
const (
	MethodInitialize        = "initialize"
	MethodInitialized       = "initialized"
	MethodShutdown          = "shutdown"
	MethodExit              = "exit"
	MethodCancelRequest     = "$/cancelRequest"
	MethodDidOpen           = "textDocument/didOpen"
	MethodDidChange         = "textDocument/didChange"
	MethodDidClose          = "textDocument/didClose"
	MethodCompletion        = "textDocument/completion"
	MethodHover             = "textDocument/hover"
	MethodPublishDiagnostic = "textDocument/publishDiagnostics"
)

// SyncFull is the TextDocumentSyncKind in which every change carries the whole
// text of the document.
const SyncFull = 1

// SeverityError is the DiagnosticSeverity of an error.
const SeverityError = 1

// Position is a zero-based line and a zero-based offset in UTF-16 code units.
type Position struct {
	Line      int `json:"line"`
	Character int `json:"character"`
}

// Range is a span of a document; End is exclusive.
type Range struct {
	Start Position `json:"start"`
	End   Position `json:"end"`
}

// Diagnostic is a problem in a document.
type Diagnostic struct {
	Range    Range  `json:"range"`
	Severity int    `json:"severity,omitempty"`
	Source   string `json:"source,omitempty"`
	Message  string `json:"message"`
}

// InitializeResult answers initialize.
type InitializeResult struct {
	Capabilities ServerCapabilities `json:"capabilities"`
	ServerInfo   ServerInfo         `json:"serverInfo"`
}

// ServerCapabilities lists what the server can do.
type ServerCapabilities struct {
	TextDocumentSync   TextDocumentSyncOptions `json:"textDocumentSync"`
	CompletionProvider CompletionOptions       `json:"completionProvider"`
	HoverProvider      bool                    `json:"hoverProvider"`
}

// CompletionOptions say when the client asks for completions besides on typing
// a name.
type CompletionOptions struct {
	TriggerCharacters []string `json:"triggerCharacters"`
}

// TextDocumentSyncOptions says how the server wants documents synchronised.
type TextDocumentSyncOptions struct {
	OpenClose bool `json:"openClose"`
	Change    int  `json:"change"`
}

// ServerInfo names the server and its version.
type ServerInfo struct {
	Name    string `json:"name"`
	Version string `json:"version,omitempty"`
}

// TextDocumentItem is a document the client opens.
type TextDocumentItem struct {
	URI        string `json:"uri"`
	LanguageID string `json:"languageId"`
	Version    int    `json:"version"`
	Text       string `json:"text"`
}

// TextDocumentIdentifier names a document.
type TextDocumentIdentifier struct {
	URI string `json:"uri"`
}

// VersionedTextDocumentIdentifier names a document at a version.
type VersionedTextDocumentIdentifier struct {
	URI     string `json:"uri"`
	Version int    `json:"version"`
}

// DidOpenParams are the parameters of textDocument/didOpen.
type DidOpenParams struct {
	TextDocument TextDocumentItem `json:"textDocument"`
}

// DidChangeParams are the parameters of textDocument/didChange.
type DidChangeParams struct {
	TextDocument   VersionedTextDocumentIdentifier  `json:"textDocument"`
	ContentChanges []TextDocumentContentChangeEvent `json:"contentChanges"`
}

// TextDocumentContentChangeEvent is a change to a document. The server asks for
// full sync, so Text is the whole new text.
type TextDocumentContentChangeEvent struct {
	Text string `json:"text"`
}

// DidCloseParams are the parameters of textDocument/didClose.
type DidCloseParams struct {
	TextDocument TextDocumentIdentifier `json:"textDocument"`
}

// PublishDiagnosticsParams are the parameters of textDocument/publishDiagnostics.
// Diagnostics must not be nil: an empty list clears the document's problems.
type PublishDiagnosticsParams struct {
	URI         string       `json:"uri"`
	Version     *int         `json:"version,omitempty"`
	Diagnostics []Diagnostic `json:"diagnostics"`
}

// The CompletionItemKind values the server uses.
const (
	KindFunction = 3
	KindField    = 5
	KindVariable = 6
	KindKeyword  = 14
)

// InsertTextFormatSnippet is the InsertTextFormat in which the text has
// placeholders such as ${1:x}.
const InsertTextFormatSnippet = 2

// CompletionParams are the parameters of textDocument/completion.
type CompletionParams struct {
	TextDocument TextDocumentIdentifier `json:"textDocument"`
	Position     Position               `json:"position"`
}

// CompletionItem is one completion. Documentation is plain text.
type CompletionItem struct {
	Label            string `json:"label"`
	Kind             int    `json:"kind"`
	Detail           string `json:"detail,omitempty"`
	Documentation    string `json:"documentation,omitempty"`
	InsertText       string `json:"insertText,omitempty"`
	InsertTextFormat int    `json:"insertTextFormat,omitempty"`
}

// MarkupKindMarkdown is the kind of MarkupContent written in Markdown.
const MarkupKindMarkdown = "markdown"

// MarkupContent is text with a format.
type MarkupContent struct {
	Kind  string `json:"kind"`
	Value string `json:"value"`
}

// HoverParams are the parameters of textDocument/hover.
type HoverParams struct {
	TextDocument TextDocumentIdentifier `json:"textDocument"`
	Position     Position               `json:"position"`
}

// Hover is the result of textDocument/hover; the reply is null when there is
// nothing to show.
type Hover struct {
	Contents MarkupContent `json:"contents"`
	Range    Range         `json:"range"`
}
