package locate

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

var update = flag.Bool("update", false, "rewrite the golden files")

const testdata = "../../testdata/locate"

func TestFindGolden(t *testing.T) {
	t.Parallel()
	files, err := filepath.Glob(filepath.Join(testdata, "*.yaml"))
	if err != nil || len(files) == 0 {
		t.Fatalf("no testdata: %v", err)
	}
	for _, file := range files {
		t.Run(strings.TrimSuffix(filepath.Base(file), ".yaml"), func(t *testing.T) {
			t.Parallel()
			src, err := os.ReadFile(file)
			if err != nil {
				t.Fatal(err)
			}
			docs, err := Find(context.Background(), src)
			if err != nil {
				t.Fatalf("Find(%s) error: %v", file, err)
			}
			var buf bytes.Buffer
			enc := json.NewEncoder(&buf)
			enc.SetEscapeHTML(false)
			enc.SetIndent("", "  ")
			if err := enc.Encode(docs); err != nil {
				t.Fatal(err)
			}
			got := buf.Bytes()
			golden := strings.TrimSuffix(file, ".yaml") + ".golden.json"
			if *update {
				if err := os.WriteFile(golden, got, 0o600); err != nil {
					t.Fatal(err)
				}
			}
			want, err := os.ReadFile(golden)
			if err != nil {
				t.Fatal(err)
			}
			if !bytes.Equal(got, want) {
				t.Errorf("Find(%s) = %s, want %s", file, got, want)
			}
		})
	}
}

func TestFindDocuments(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name      string
		src       string
		wantDocs  int
		wantExprs int
	}{
		{"empty", "", 0, 0},
		{"comment only", "# nothing\n", 0, 0},
		{"separators only", "---\n---\n", 0, 0},
		{"other kind", "apiVersion: v1\nkind: Pod\n", 1, 0},
		{"scalar document", "just text\n", 1, 0},
		{"null expression", "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression:\n", 1, 0},
		{"wrong shapes", "apiVersion: apiextensions.k8s.io/v1\nkind: CustomResourceDefinition\nspec:\n  versions: 3\n", 1, 0},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			docs, err := Find(context.Background(), []byte(tt.src))
			if err != nil {
				t.Fatalf("Find(%q) error: %v", tt.src, err)
			}
			n := 0
			for _, d := range docs {
				n += len(d.Expressions)
			}
			if len(docs) != tt.wantDocs || n != tt.wantExprs {
				t.Errorf("Find(%q) = %d docs, %d expressions, want %d, %d", tt.src, len(docs), n, tt.wantDocs, tt.wantExprs)
			}
		})
	}
}

func TestFindSyntaxError(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		src  string
		line int
	}{
		{"first document", "a: 1\n\tb: 2\n", 2},
		{"later document", "a: 1\n---\nb: 2\n---\nc: 3\n\td: 4\n", 5},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			docs, err := Find(context.Background(), []byte(tt.src))
			var se *SyntaxError
			if !errors.As(err, &se) {
				t.Fatalf("Find(%q) error = %v, want *SyntaxError", tt.src, err)
			}
			if se.Line != tt.line || se.Column < 1 || docs != nil {
				t.Errorf("Find(%q) = %v, %d:%d, want no documents, line %d", tt.src, docs, se.Line, se.Column, tt.line)
			}
		})
	}
}

func TestFindCancelled(t *testing.T) {
	t.Parallel()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Find(ctx, []byte("a: 1\n")); !errors.Is(err, context.Canceled) {
		t.Errorf("Find(cancelled) error = %v, want context.Canceled", err)
	}
}

func TestKindString(t *testing.T) {
	t.Parallel()
	if got, want := Kind(0).String(), "Kind(0)"; got != want {
		t.Errorf("Kind(0).String() = %q, want %q", got, want)
	}
	if got, want := CRDRule.String(), "crdRule"; got != want {
		t.Errorf("CRDRule.String() = %q, want %q", got, want)
	}
}

func seeds(tb testing.TB) [][]byte {
	tb.Helper()
	files, err := filepath.Glob(filepath.Join(testdata, "*.yaml"))
	if err != nil {
		tb.Fatal(err)
	}
	var out [][]byte
	for _, f := range files {
		src, err := os.ReadFile(f)
		if err != nil {
			tb.Fatal(err)
		}
		out = append(out, src)
	}
	return out
}

func FuzzFind(f *testing.F) {
	for _, src := range seeds(f) {
		f.Add(src)
	}
	f.Fuzz(func(t *testing.T, src []byte) {
		docs, err := Find(context.Background(), src)
		if err != nil {
			var se *SyntaxError
			if !errors.As(err, &se) || se.Line < 1 || se.Column < 1 {
				t.Fatalf("Find error = %v, want *SyntaxError with a position", err)
			}
			return
		}
		for _, d := range docs {
			for _, e := range d.Expressions {
				if e.Line < 1 || e.Column < 1 {
					t.Fatalf("expression %q at %d:%d, want a position", e.Path, e.Line, e.Column)
				}
			}
		}
	})
}

// findBudget is the time allowed to locate 50 expressions in a file of 1,000
// lines: the 5 ms of the issue.
const findBudget = 5 * time.Millisecond

// BenchmarkFind fails when it takes longer than findBudget. It locates 50 expressions in a CRD of more than 1,000 lines of
// nested schema, with the expressions spread through it.
func BenchmarkFind(b *testing.B) {
	var sb strings.Builder
	sb.WriteString(`apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: widgets.example.com
spec:
  group: example.com
  names:
    kind: Widget
    plural: widgets
  scope: Namespaced
  versions:
    - name: v1
      served: true
      storage: true
      schema:
        openAPIV3Schema:
          type: object
          properties:
            spec:
              type: object
              properties:
`)
	for i := range 50 {
		fmt.Fprintf(&sb, `                field%[1]d:
                  type: object
                  description: field number %[1]d of the widget
                  required:
                    - name
                    - size
                  properties:
                    name:
                      type: string
                      maxLength: 63
                    size:
                      type: integer
                      minimum: 0
                      maximum: 100
                    tags:
                      type: array
                      items:
                        type: string
                  x-kubernetes-validations:
                    - rule: self.size <= 100
                      message: size is too large
`, i)
	}
	src := []byte(sb.String())
	if n := bytes.Count(src, []byte("\n")); n < 1000 {
		b.Fatalf("input has %d lines, want at least 1000", n)
	}
	ctx := context.Background()
	for b.Loop() {
		docs, err := Find(ctx, src)
		if err != nil || len(docs) != 1 || len(docs[0].Expressions) != 50 {
			b.Fatalf("Find: %v, %d docs", err, len(docs))
		}
	}
	if got := b.Elapsed() / time.Duration(b.N); got > findBudget {
		b.Errorf("Find took %v, want within %v", got, findBudget)
	}
}
