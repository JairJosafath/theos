// Package locate finds the CEL expressions in Kubernetes YAML. A document's
// apiVersion and kind say which fields hold CEL, so authors never mark it.
package locate

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"regexp"
	"strconv"
	"strings"

	"go.yaml.in/yaml/v3"
)

// Kind is the kind of place a CEL expression is in. Each kind has its own CEL
// environment. The zero value is not a valid kind.
type Kind int

// The kinds of place that hold CEL.
const (
	// MatchCondition is a matchConditions[].expression of a policy or webhook.
	MatchCondition Kind = iota + 1
	// Variable is a spec.variables[].expression of a ValidatingAdmissionPolicy.
	Variable
	// Validation is a spec.validations[].expression.
	Validation
	// MessageExpression is a spec.validations[].messageExpression.
	MessageExpression
	// AuditAnnotation is a spec.auditAnnotations[].valueExpression.
	AuditAnnotation
	// CRDRule is an x-kubernetes-validations[].rule of a CRD schema.
	CRDRule
	// CRDMessageExpression is an x-kubernetes-validations[].messageExpression.
	CRDMessageExpression
)

var kindNames = map[Kind]string{
	MatchCondition:       "matchCondition",
	Variable:             "variable",
	Validation:           "validation",
	MessageExpression:    "messageExpression",
	AuditAnnotation:      "auditAnnotation",
	CRDRule:              "crdRule",
	CRDMessageExpression: "crdMessageExpression",
}

// String returns the kind's name, such as "validation".
func (k Kind) String() string {
	if s, ok := kindNames[k]; ok {
		return s
	}
	return "Kind(" + strconv.Itoa(int(k)) + ")"
}

// MarshalText encodes k as its name, so JSON shows names, not numbers.
func (k Kind) MarshalText() ([]byte, error) { return []byte(k.String()), nil }

// Expression is one CEL expression found in a document.
type Expression struct {
	// Text is the decoded scalar value.
	Text string `json:"text"`
	// Kind is the kind of place the expression is in.
	Kind Kind `json:"kind"`
	// Doc is the index of the YAML document, counting from 0, empty ones included.
	Doc int `json:"doc"`
	// Path is the YAML path, such as spec.validations[1].messageExpression.
	Path string `json:"path"`
	// Line and Column are the 1-based position of the scalar's start in the file.
	// Column counts characters, not bytes.
	Line   int `json:"line"`
	Column int `json:"column"`
}

// Document is one non-empty YAML document of a file.
type Document struct {
	// Index is the document's index in the file, counting from 0.
	Index int `json:"index"`
	// APIVersion and Kind are the document's top-level fields; either may be
	// empty when the document has none.
	APIVersion string `json:"apiVersion"`
	Kind       string `json:"kind"`
	// Node is the decoded document, for later checks. It is not part of
	// the JSON form.
	Node *yaml.Node `json:"-"`
	// Expressions are the CEL expressions in the document, in a fixed order;
	// empty for kinds that hold none.
	Expressions []Expression `json:"expressions"`
}

// SyntaxError is a YAML syntax error with its position in the file.
type SyntaxError struct {
	// Line is 1-based. Column is 1-based too; the YAML parser reports only the
	// line, so Column is 1 unless it is known.
	Line, Column int
	// Msg says what was wrong.
	Msg string
}

func (e *SyntaxError) Error() string {
	return fmt.Sprintf("%d:%d: %s", e.Line, e.Column, e.Msg)
}

// errLine picks the line out of yaml.v3 errors, which have no typed form.
var errLine = regexp.MustCompile(`^yaml: (?:line (\d+): )?(.*)$`)

func syntaxError(err error) error {
	m := errLine.FindStringSubmatch(err.Error())
	if m == nil {
		return &SyntaxError{Line: 1, Column: 1, Msg: err.Error()}
	}
	line, _ := strconv.Atoi(m[1])
	if line < 1 {
		line = 1
	}
	return &SyntaxError{Line: line, Column: 1, Msg: m[2]}
}

// Find returns the non-empty documents of the YAML file src with the CEL
// expressions in each. Documents of kinds that hold no CEL come back with no
// expressions; empty documents and comments are skipped. Empty src yields no
// documents. A syntax error comes back as a *SyntaxError, and no documents.
// Find returns ctx.Err() when ctx is cancelled. It is safe for concurrent use.
func Find(ctx context.Context, src []byte) ([]Document, error) {
	dec := yaml.NewDecoder(bytes.NewReader(src))
	var docs []Document
	for index := 0; ; index++ {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		var root yaml.Node
		err := dec.Decode(&root)
		if errors.Is(err, io.EOF) {
			return docs, nil
		}
		if err != nil {
			return nil, syntaxError(err)
		}
		body := &root
		if root.Kind == yaml.DocumentNode && len(root.Content) == 1 {
			body = root.Content[0]
		}
		if body.Kind == 0 || (body.Kind == yaml.ScalarNode && body.Tag == "!!null") {
			continue
		}
		doc := Document{Index: index, Node: &root, Expressions: []Expression{}}
		if body.Kind == yaml.MappingNode {
			doc.APIVersion = scalar(child(body, "apiVersion"))
			doc.Kind = scalar(child(body, "kind"))
			doc.Expressions = collect(index, doc.APIVersion, doc.Kind, body)
		}
		docs = append(docs, doc)
	}
}

// field names a scalar field of a list item and the kind of place it is.
type field struct {
	key  string
	kind Kind
}

// list names a sequence of mappings under path whose fields hold CEL.
type list struct {
	path   []string
	fields []field
}

var policyLists = []list{
	{[]string{"spec", "matchConditions"}, []field{{"expression", MatchCondition}}},
	{[]string{"spec", "variables"}, []field{{"expression", Variable}}},
	{[]string{"spec", "validations"}, []field{{"expression", Validation}, {"messageExpression", MessageExpression}}},
	{[]string{"spec", "auditAnnotations"}, []field{{"valueExpression", AuditAnnotation}}},
}

func collect(doc int, apiVersion, kind string, body *yaml.Node) []Expression {
	c := &collector{doc: doc, out: []Expression{}}
	switch {
	case kind == "ValidatingAdmissionPolicy" && (apiVersion == "admissionregistration.k8s.io/v1" || apiVersion == "admissionregistration.k8s.io/v1beta1"):
		for _, l := range policyLists {
			c.list(body, l)
		}
	case (kind == "ValidatingWebhookConfiguration" || kind == "MutatingWebhookConfiguration") && apiVersion == "admissionregistration.k8s.io/v1":
		c.webhooks(body)
	case kind == "CustomResourceDefinition" && apiVersion == "apiextensions.k8s.io/v1":
		c.versions(body)
	}
	return c.out
}

type collector struct {
	doc int
	out []Expression
}

func (c *collector) add(n *yaml.Node, kind Kind, path string) {
	if n == nil || n.Kind != yaml.ScalarNode || n.Tag == "!!null" {
		return
	}
	c.out = append(c.out, Expression{Text: n.Value, Kind: kind, Doc: c.doc, Path: path, Line: n.Line, Column: n.Column})
}

// list adds the fields of every item of the sequence at l.path below n.
func (c *collector) list(n *yaml.Node, l list) {
	c.items(descendNode(n, l.path...), strings.Join(l.path, "."), l.fields)
}

func (c *collector) items(seq *yaml.Node, path string, fields []field) {
	if seq == nil || seq.Kind != yaml.SequenceNode {
		return
	}
	for i, item := range seq.Content {
		if item.Kind != yaml.MappingNode {
			continue
		}
		p := fmt.Sprintf("%s[%d]", path, i)
		for _, f := range fields {
			c.add(child(item, f.key), f.kind, p+"."+f.key)
		}
	}
}

func (c *collector) webhooks(body *yaml.Node) {
	seq := child(body, "webhooks")
	if seq == nil || seq.Kind != yaml.SequenceNode {
		return
	}
	for i, hook := range seq.Content {
		if hook.Kind != yaml.MappingNode {
			continue
		}
		c.items(child(hook, "matchConditions"), fmt.Sprintf("webhooks[%d].matchConditions", i),
			[]field{{"expression", MatchCondition}})
	}
}

func (c *collector) versions(body *yaml.Node) {
	seq := descendNode(body, "spec", "versions")
	if seq == nil || seq.Kind != yaml.SequenceNode {
		return
	}
	for i, v := range seq.Content {
		schema := descendNode(v, "schema", "openAPIV3Schema")
		c.schema(schema, fmt.Sprintf("spec.versions[%d].schema.openAPIV3Schema", i))
	}
}

// schema adds the x-kubernetes-validations of the schema n and of every
// schema nested in it.
func (c *collector) schema(n *yaml.Node, path string) {
	if n == nil || n.Kind != yaml.MappingNode {
		return
	}
	c.items(child(n, "x-kubernetes-validations"), path+".x-kubernetes-validations",
		[]field{{"rule", CRDRule}, {"messageExpression", CRDMessageExpression}})
	if props := child(n, "properties"); props != nil && props.Kind == yaml.MappingNode {
		for i := 0; i+1 < len(props.Content); i += 2 {
			c.schema(props.Content[i+1], path+".properties."+props.Content[i].Value)
		}
	}
	for _, key := range []string{"items", "additionalProperties", "not"} {
		c.schema(child(n, key), path+"."+key)
	}
	for _, key := range []string{"allOf", "anyOf", "oneOf"} {
		if seq := child(n, key); seq != nil && seq.Kind == yaml.SequenceNode {
			for i, s := range seq.Content {
				c.schema(s, fmt.Sprintf("%s.%s[%d]", path, key, i))
			}
		}
	}
}

func descendNode(n *yaml.Node, keys ...string) *yaml.Node {
	for _, k := range keys {
		n = child(n, k)
	}
	return n
}

// child returns the value of key in mapping n, or nil.
func child(n *yaml.Node, key string) *yaml.Node {
	if n == nil || n.Kind != yaml.MappingNode {
		return nil
	}
	for i := 0; i+1 < len(n.Content); i += 2 {
		if n.Content[i].Value == key {
			return n.Content[i+1]
		}
	}
	return nil
}

// scalar returns the value of scalar node n, or "" for anything else.
func scalar(n *yaml.Node) string {
	if n == nil || n.Kind != yaml.ScalarNode {
		return ""
	}
	return n.Value
}
