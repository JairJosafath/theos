package main

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"flag"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
	"time"
)

var update = flag.Bool("update", false, "rewrite the golden files")

func TestRun(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name       string
		args       []string
		stdin      string
		wantCode   int
		wantStdout string // a substring of stdout; "" means stdout stays empty
		wantStderr string // a substring of stderr; "" means stderr stays empty
	}{
		{
			name:       "no arguments print the help",
			wantCode:   exitOK,
			wantStdout: "Usage: " + name + " [flags]\n       " + name + " check",
		},
		{
			name:       "help",
			args:       []string{"--help"},
			wantCode:   exitOK,
			wantStdout: "-version",
		},
		{
			name:       "version",
			args:       []string{"--version"},
			wantCode:   exitOK,
			wantStdout: name + " dev\n",
		},
		{
			name:       "unknown flag",
			args:       []string{"--nope"},
			wantCode:   exitUsage,
			wantStderr: "flag provided but not defined: -nope",
		},
		{
			name:       "serve without --stdio",
			args:       []string{"serve"},
			wantCode:   exitUsage,
			wantStderr: "need --stdio",
		},
		{
			name:       "serve help",
			args:       []string{"serve", "--help"},
			wantCode:   exitOK,
			wantStdout: "-stdio",
		},
		{
			name:       "serve ends without shutdown",
			args:       []string{"serve", "--stdio"},
			wantCode:   exitFailure,
			wantStderr: "exit without shutdown",
		},
		{
			name:       "serve shutdown and exit",
			args:       []string{"serve", "--stdio"},
			stdin:      frame(`{"jsonrpc":"2.0","id":1,"method":"initialize","params":{}}`) + frame(`{"jsonrpc":"2.0","id":2,"method":"shutdown"}`) + frame(`{"jsonrpc":"2.0","method":"exit"}`),
			wantCode:   exitOK,
			wantStdout: `"serverInfo":{"name":"cel-language-server","version":"dev"}`,
		},
		{
			name:       "unexpected argument",
			args:       []string{"extra"},
			wantCode:   exitUsage,
			wantStderr: `unknown command "extra"`,
		},
		{
			name:       "check help",
			args:       []string{"check", "--help"},
			wantCode:   exitOK,
			wantStdout: "Example:\n  " + name + " check --format json",
		},
		{
			name:       "check without path",
			args:       []string{"check"},
			wantCode:   exitUsage,
			wantStderr: "check: missing PATH",
		},
		{
			name:       "check unknown flag",
			args:       []string{"check", "--nope", "x"},
			wantCode:   exitUsage,
			wantStderr: "flag provided but not defined: -nope",
		},
		{
			name:       "check unknown format",
			args:       []string{"check", "--format", "xml", "x"},
			wantCode:   exitUsage,
			wantStderr: `unknown format "xml"`,
		},
		{
			name:       "check missing file",
			args:       []string{"check", "testdata/nope.yaml"},
			wantCode:   exitFailure,
			wantStderr: "check testdata/nope.yaml",
		},
		{
			name:     "check clean file",
			args:     []string{"check", "testdata/crds/valid.yaml"},
			wantCode: exitOK,
		},
		{
			name:       "check clean file as json",
			args:       []string{"check", "--format", "json", "testdata/crds/valid.yaml"},
			wantCode:   exitOK,
			wantStdout: "[]\n",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			var stdout, stderr bytes.Buffer
			if got := run(t.Context(), tt.args, strings.NewReader(tt.stdin), &stdout, &stderr); got != tt.wantCode {
				t.Errorf("run(%q) = %d, want %d", tt.args, got, tt.wantCode)
			}
			checkOutput(t, "stdout", stdout.String(), tt.wantStdout)
			checkOutput(t, "stderr", stderr.String(), tt.wantStderr)
		})
	}
}

// checkOutput fails the test when got lacks want, or when want is empty and got
// is not.
func checkOutput(t *testing.T, stream, got, want string) {
	t.Helper()
	if want == "" && got != "" {
		t.Errorf("%s = %q, want it empty", stream, got)
	}
	if !strings.Contains(got, want) {
		t.Errorf("%s = %q, want it to contain %q", stream, got, want)
	}
}

// frame wraps a JSON-RPC body in LSP framing.
func frame(body string) string {
	return fmt.Sprintf("Content-Length: %d\r\n\r\n%s", len(body), body)
}

func TestRunCheckGolden(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name   string
		format string
		golden string
	}{
		{"text", "text", "testdata/check/all.txt"},
		{"json", "json", "testdata/check/all.json"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			var stdout, stderr bytes.Buffer
			args := []string{"check", "--format", tt.format, "testdata/policies", "testdata/crds"}
			if got := run(t.Context(), args, strings.NewReader(""), &stdout, &stderr); got != exitFailure {
				t.Errorf("run(%q) = %d, want %d", args, got, exitFailure)
			}
			if stderr.Len() > 0 {
				t.Errorf("stderr = %q, want it empty", stderr.String())
			}
			if *update {
				if err := os.MkdirAll(filepath.Dir(tt.golden), 0o750); err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(tt.golden, stdout.Bytes(), 0o600); err != nil {
					t.Fatal(err)
				}
			}
			want, err := os.ReadFile(tt.golden)
			if err != nil {
				t.Fatal(err)
			}
			if stdout.String() != string(want) {
				t.Errorf("run(%q) stdout =\n%s\nwant\n%s", args, stdout.String(), want)
			}
		})
	}
}

func TestRunCheckUnreadableFile(t *testing.T) {
	t.Parallel()
	const header = "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n"
	tests := []struct {
		name       string
		expression string
		wantStdout bool
	}{
		{name: "valid file", expression: "true", wantStdout: false},
		{name: "file with CEL error", expression: "nme == ''", wantStdout: true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			dir := t.TempDir()
			other := filepath.Join(dir, "other.yaml")
			policy := header + "    - expression: \"" + tt.expression + "\"\n"
			if err := os.WriteFile(other, []byte(policy), 0o600); err != nil {
				t.Fatal(err)
			}
			missing := filepath.Join(dir, "missing.yaml")

			var stdout, stderr bytes.Buffer
			code := run(t.Context(), []string{"check", missing, other}, strings.NewReader(""), &stdout, &stderr)
			if code != exitFailure {
				t.Errorf("run(check missing other) = %d, want %d", code, exitFailure)
			}
			if got := strings.Contains(stdout.String(), other); got != tt.wantStdout {
				t.Errorf("stdout = %q, mentions %s = %v, want %v", stdout.String(), other, got, tt.wantStdout)
			}
			if !strings.Contains(stderr.String(), missing) {
				t.Errorf("stderr = %q, want it to name %s", stderr.String(), missing)
			}
		})
	}
}

func TestRunCheckCancelled(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	policy := "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: \"true\"\n"
	if err := os.WriteFile(filepath.Join(dir, "p.yaml"), []byte(policy), 0o600); err != nil {
		t.Fatal(err)
	}
	for _, format := range []string{"text", "json"} {
		t.Run(format, func(t *testing.T) {
			t.Parallel()
			ctx, cancel := context.WithCancel(t.Context())
			cancel()

			var stdout, stderr bytes.Buffer
			code := run(ctx, []string{"check", "--format", format, dir}, strings.NewReader(""), &stdout, &stderr)
			if code != exitFailure {
				t.Errorf("run(check) with cancelled context = %d, want %d", code, exitFailure)
			}
			if want := "check interrupted: " + context.Canceled.Error(); !strings.Contains(stderr.String(), want) {
				t.Errorf("stderr = %q, want it to contain %q", stderr.String(), want)
			}
			if stdout.Len() != 0 {
				t.Errorf("stdout = %q, want it empty", stdout.String())
			}
		})
	}
}

// runMainEnv makes the test binary run main instead of the tests.
const runMainEnv = "CEL_LANGUAGE_SERVER_RUN_MAIN"

func TestServeEndsOnSignal(t *testing.T) {
	if os.Getenv(runMainEnv) == "1" {
		os.Args = []string{name, "serve", "--stdio"}
		main()
		return
	}
	t.Parallel()
	for _, sig := range []syscall.Signal{syscall.SIGTERM, syscall.SIGINT} {
		t.Run(sig.String(), func(t *testing.T) {
			t.Parallel()
			ctx, cancel := context.WithTimeout(t.Context(), 10*time.Second)
			defer cancel()
			cmd := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestServeEndsOnSignal$") //nolint:gosec // re-runs this test binary, no external input
			cmd.Env = append(os.Environ(), runMainEnv+"=1")
			stdin, err := cmd.StdinPipe() // held open: the server blocks reading it
			if err != nil {
				t.Fatal(err)
			}
			stdout, err := cmd.StdoutPipe()
			if err != nil {
				t.Fatal(err)
			}
			if err := cmd.Start(); err != nil {
				t.Fatal(err)
			}
			defer func() { _ = stdin.Close() }()
			// Wait until the child is inside server.Run: before that, Go's
			// default handling ends it whatever main does.
			const initialize = `{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"processId":null,"rootUri":null,"capabilities":{}}}`
			if _, err := fmt.Fprintf(stdin, "Content-Length: %d\r\n\r\n%s", len(initialize), initialize); err != nil {
				t.Fatal(err)
			}
			if _, err := bufio.NewReader(stdout).ReadString('{'); err != nil {
				t.Fatalf("read initialize response: %v", err)
			}
			if err := cmd.Process.Signal(sig); err != nil {
				t.Fatal(err)
			}
			err = cmd.Wait()
			if ctx.Err() != nil {
				t.Fatalf("serve after %v: still running after 10s, want it to end", sig)
			}
			var exit *exec.ExitError
			if !errors.As(err, &exit) || exit.Success() {
				t.Errorf("serve after %v: Wait = %v, want it to end with a failure", sig, err)
			}
		})
	}
}

func TestHandlesSignals(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		args []string
		want bool
	}{
		{"check", []string{"check", "a.yaml"}, true},
		{"serve", []string{"serve", "--stdio"}, false},
		{"no arguments", nil, false},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := handlesSignals(tt.args); got != tt.want {
				t.Errorf("handlesSignals(%q) = %v, want %v", tt.args, got, tt.want)
			}
		})
	}
}
