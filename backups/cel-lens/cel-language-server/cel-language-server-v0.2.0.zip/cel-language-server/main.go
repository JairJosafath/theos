// Command cel-language-server finds CEL in Kubernetes YAML and checks it the
// way the API server does, for editors and for CI.
//
// Usage:
//
//	cel-language-server [--version] [-h]
//	cel-language-server check [--format text|json] PATH...
//	cel-language-server serve --stdio
//
// The check command reads each PATH, a file or a directory searched for
// *.yaml and *.yml files, and prints one line per diagnostic to stdout. It
// exits 0 when there are no errors, 1 when there is at least one error or a
// path cannot be read, and 2 for a wrong command line.
//
// SIGINT and SIGTERM cancel a running check: it stops, reports the
// cancellation on stderr and exits 1.
//
// The serve command runs the language server: it speaks LSP 3.17 on stdin and
// stdout and logs to stderr. It exits 0 after a shutdown request and an exit
// notification, and 1 when the client exits without shutdown or the stream
// breaks.
//
// The flags are:
//
//	--version
//		Print the version and exit.
//	-h, --help
//		Print the help and exit.
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"log/slog"
	"os"
	"os/signal"
	"syscall"

	"c4factory.local/cel-lens/cel-language-server/internal/check"
	"c4factory.local/cel-lens/cel-language-server/internal/server"
)

// name is the program's name in messages and help, the same as its binary's.
const name = "cel-language-server"

// version is the release this binary was built from. make build and make dist
// set it with -ldflags "-X main.version=..."; go run and go test leave "dev".
var version = "dev"

// Exit codes, as shells and CI read them.
const (
	exitOK      = 0 // success, including --help and --version
	exitFailure = 1 // errors found, or a file could not be read
	exitUsage   = 2 // the command line was wrong
)

func main() {
	ctx := context.Background()
	stop := func() {}
	if handlesSignals(os.Args[1:]) {
		ctx, stop = signal.NotifyContext(ctx, os.Interrupt, syscall.SIGTERM)
	}
	code := run(ctx, os.Args[1:], os.Stdin, os.Stdout, os.Stderr)
	stop()
	os.Exit(code)
}

// handlesSignals reports whether the command in args stops cleanly on SIGINT
// and SIGTERM. Only check does; serve keeps Go's default, so a signal still
// ends a server stuck reading stdin.
func handlesSignals(args []string) bool {
	return len(args) > 0 && args[0] == "check"
}

// run is the whole program behind main: it parses args, reads stdin, writes
// results to stdout and diagnostics to stderr, and returns the exit code. It
// never exits or touches global state, so tests call it directly. Cancelling
// ctx stops a check run, which then writes no results and exits 1.
func run(ctx context.Context, args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	if len(args) > 0 && args[0] == "serve" {
		return serve(args[1:], stdin, stdout, stderr)
	}
	if len(args) > 0 && args[0] == "check" {
		return runCheck(ctx, args[1:], stdout, stderr)
	}
	flags := flag.NewFlagSet(name, flag.ContinueOnError)
	flags.SetOutput(io.Discard) // run reports parse errors itself
	showVersion := flags.Bool("version", false, "print the version and exit")

	err := flags.Parse(args)
	switch {
	case errors.Is(err, flag.ErrHelp):
		usage(stdout, flags)
		return exitOK
	case err != nil:
		return usageError(stderr, "%v", err)
	case flags.NArg() > 0:
		return usageError(stderr, "unknown command %q", flags.Arg(0))
	case *showVersion:
		fmt.Fprintln(stdout, name, version)
		return exitOK
	}
	usage(stdout, flags)
	return exitOK
}

// serve is the serve command: the language server over stdin and stdout.
func serve(args []string, stdin io.Reader, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet(name+" serve", flag.ContinueOnError)
	flags.SetOutput(io.Discard)
	stdio := flags.Bool("stdio", false, "speak LSP on stdin and stdout")
	err := flags.Parse(args)
	switch {
	case errors.Is(err, flag.ErrHelp):
		fmt.Fprintf(stdout, "Usage: %s serve --stdio\n\nFlags:\n", name)
		flags.SetOutput(stdout)
		flags.PrintDefaults()
		return exitOK
	case err != nil:
		fmt.Fprintf(stderr, "%s serve: %v\nRun '%s serve --help' for usage.\n", name, err, name)
		return exitUsage
	case flags.NArg() > 0 || !*stdio:
		fmt.Fprintf(stderr, "%s serve: need --stdio and no arguments\nRun '%s serve --help' for usage.\n", name, name)
		return exitUsage
	}
	log := slog.New(slog.NewTextHandler(stderr, nil))
	if err := server.New(version, log).Run(context.Background(), stdin, stdout); err != nil {
		log.Error("serve", "err", err)
		return exitFailure
	}
	return exitOK
}

// runCheck is the check command: it checks the paths in args.
func runCheck(ctx context.Context, args []string, stdout, stderr io.Writer) int {
	flags := flag.NewFlagSet(name+" check", flag.ContinueOnError)
	flags.SetOutput(io.Discard)
	format := flags.String("format", "text", "output `format`: text or json")

	err := flags.Parse(args)
	switch {
	case errors.Is(err, flag.ErrHelp):
		checkUsage(stdout, flags)
		return exitOK
	case err != nil:
		return usageError(stderr, "check: %v", err)
	case *format != "text" && *format != "json":
		return usageError(stderr, "check: unknown format %q, want text or json", *format)
	case flags.NArg() == 0:
		return usageError(stderr, "check: missing PATH")
	}

	findings, readErr := check.Files(ctx, flags.Args())
	if ctx.Err() != nil {
		fmt.Fprintf(stderr, "%s: check interrupted: %v\n", name, ctx.Err())
		return exitFailure
	}
	if readErr != nil {
		fmt.Fprintf(stderr, "%s: %v\n", name, readErr)
	}
	write := check.WriteText
	if *format == "json" {
		write = check.WriteJSON
	}
	if err := write(stdout, findings); err != nil {
		fmt.Fprintf(stderr, "%s: %v\n", name, err)
		return exitFailure
	}
	if readErr != nil || check.HasErrors(findings) {
		return exitFailure
	}
	return exitOK
}

// usageError reports a wrong command line on stderr and returns exitUsage.
func usageError(stderr io.Writer, format string, args ...any) int {
	fmt.Fprintf(stderr, "%s: %s\nRun '%s --help' for usage.\n", name, fmt.Sprintf(format, args...), name)
	return exitUsage
}

// usage writes the help text to w.
func usage(w io.Writer, flags *flag.FlagSet) {
	fmt.Fprintf(w, `Usage: %[1]s [flags]
       %[1]s check [--format text|json] PATH...
       %[1]s serve --stdio

Finds CEL in Kubernetes YAML and checks it the way the API server does.

Commands:
  check    check files and directories, for CI
  serve    run the language server for editors, over LSP on stdin and stdout

Flags:
`, name)
	flags.SetOutput(w)
	flags.PrintDefaults()
	fmt.Fprintf(w, "\nExample:\n  %s check policies/\n\nRun '%s check --help' for the check command.\n", name, name)
}

// checkUsage writes the help text of the check command to w.
func checkUsage(w io.Writer, flags *flag.FlagSet) {
	fmt.Fprintf(w, `Usage: %[1]s check [--format text|json] PATH...

Checks the CEL in Kubernetes YAML. A PATH is a file, or a directory searched
for *.yaml and *.yml files. Text output is one line per diagnostic:

  path:line:col: severity: message

Exit status: 0 without errors (warnings alone are fine), 1 with at least one
error or an unreadable path, 2 for a wrong command line.

Flags:
`, name)
	flags.SetOutput(w)
	flags.PrintDefaults()
	fmt.Fprintf(w, "\nExample:\n  %s check --format json policies/ crds/cost.yaml\n", name)
}
