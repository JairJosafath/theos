package main

import (
	"bytes"
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"testing"

	"go.yaml.in/yaml/v3"
)

// block is a fenced code block of the README.
type block struct {
	info string // the text after the opening fence
	body string
}

var fence = regexp.MustCompile("(?s)\n```([^\n]*)\n(.*?\n)```\n")

func readmeBlocks(t *testing.T) []block {
	t.Helper()
	src, err := os.ReadFile("README.md")
	if err != nil {
		t.Fatal(err)
	}
	var blocks []block
	for _, m := range fence.FindAllStringSubmatch("\n"+string(src), -1) {
		blocks = append(blocks, block{info: m[1], body: m[2]})
	}
	return blocks
}

// readmeDir returns a directory laid out as the README's examples expect:
// policies/ and crds/ holding the test files.
func readmeDir(t *testing.T) string {
	t.Helper()
	dir := t.TempDir()
	for src, dst := range map[string]string{
		"testdata/policies": "policies",
		"testdata/readme":   "policies",
		"testdata/crds":     "crds",
	} {
		if err := os.CopyFS(filepath.Join(dir, dst), os.DirFS(src)); err != nil {
			t.Fatal(err)
		}
	}
	return dir
}

// runCommand runs a README command line, which must start with the program's
// name and have no quoting, and returns its exit code and stdout.
func runCommand(t *testing.T, line string) (int, string) {
	t.Helper()
	fields := strings.Fields(line)
	if len(fields) == 0 || fields[0] != name {
		t.Fatalf("README command %q does not start with %s", line, name)
	}
	var stdout, stderr bytes.Buffer
	code := run(t.Context(), fields[1:], strings.NewReader(""), &stdout, &stderr)
	if stderr.Len() > 0 {
		t.Errorf("run(%q) stderr = %q, want it empty", line, stderr.String())
	}
	return code, stdout.String()
}

// TestREADMECheckExamples runs every `sh` block of the README that runs the
// program, in a directory with policies/ and crds/, and compares stdout with
// the block that follows it. A block's exit status is 0 unless its fence says
// `exit=N`.
func TestREADMECheckExamples(t *testing.T) {
	blocks := readmeBlocks(t)
	t.Chdir(readmeDir(t))
	ran := 0
	for i, b := range blocks {
		lang, wantCode, _ := strings.Cut(b.info, " ")
		if lang != "sh" || !strings.HasPrefix(b.body, name+" check ") {
			continue
		}
		ran++
		want := exitOK
		if wantCode != "" {
			n, ok := strings.CutPrefix(wantCode, "exit=")
			if !ok {
				t.Fatalf("README fence %q: want exit=N", b.info)
			}
			var err error
			if want, err = strconv.Atoi(n); err != nil {
				t.Fatalf("README fence %q: %v", b.info, err)
			}
		}
		for _, line := range strings.Split(strings.TrimSpace(b.body), "\n") {
			code, stdout := runCommand(t, line)
			if code != want {
				t.Errorf("run(%q) = %d, want %d", line, code, want)
			}
			if i+1 < len(blocks) && (blocks[i+1].info == "text" || blocks[i+1].info == "json") && stdout != blocks[i+1].body {
				t.Errorf("run(%q) stdout =\n%s\nREADME says\n%s", line, stdout, blocks[i+1].body)
			}
		}
	}
	if ran == 0 {
		t.Error("README has no check example")
	}
}

// TestREADMEActionsExample parses the README's Actions workflow and runs its
// check step.
func TestREADMEActionsExample(t *testing.T) {
	blocks := readmeBlocks(t)
	t.Chdir(readmeDir(t))
	var found bool
	for _, b := range blocks {
		if b.info != "yaml" || !strings.Contains(b.body, "jobs:") {
			continue
		}
		found = true
		var wf struct {
			Jobs map[string]struct {
				Steps []struct {
					Run string `yaml:"run"`
				} `yaml:"steps"`
			} `yaml:"jobs"`
		}
		if err := yaml.Unmarshal([]byte(b.body), &wf); err != nil {
			t.Fatalf("README workflow: %v", err)
		}
		var checks int
		for _, step := range wf.Jobs["cel"].Steps {
			if strings.HasPrefix(step.Run, name+" check ") {
				checks++
				// The directories hold errors by design: exit 1 is the CI failure.
				if code, _ := runCommand(t, step.Run); code != exitFailure {
					t.Errorf("run(%q) = %d, want %d", step.Run, code, exitFailure)
				}
			}
		}
		if checks != 1 {
			t.Errorf("README workflow has %d check steps, want 1", checks)
		}
	}
	if !found {
		t.Error("README has no Actions example")
	}
}

// TestREADMEInstallAndSetup checks what cannot run here: that the make
// targets, release files and Neovim command line the README names exist.
func TestREADMEInstallAndSetup(t *testing.T) {
	t.Parallel()
	makefile, err := os.ReadFile("Makefile")
	if err != nil {
		t.Fatal(err)
	}
	readme, err := os.ReadFile("README.md")
	if err != nil {
		t.Fatal(err)
	}
	for _, target := range []string{"make dist", "make build", "make check"} {
		if !strings.Contains(string(readme), target) {
			t.Errorf("README does not mention %q", target)
		}
		if !strings.Contains(string(makefile), "\n"+strings.TrimPrefix(target, "make ")+":") {
			t.Errorf("Makefile has no target for %q", target)
		}
	}
	for _, platform := range []string{"linux/amd64", "linux/arm64", "darwin/amd64", "darwin/arm64", "windows/amd64", "windows/arm64"} {
		if !strings.Contains(string(makefile), platform) {
			t.Errorf("Makefile does not build %s, which the README lists", platform)
		}
	}
	for _, b := range readmeBlocks(t) {
		if b.info != "lua" {
			continue
		}
		for _, want := range []string{"vim.lsp.config('cel'", "cmd = { 'cel-language-server', 'serve', '--stdio' }", "filetypes = { 'yaml' }", "vim.lsp.enable('cel')"} {
			if !strings.Contains(b.body, want) {
				t.Errorf("Neovim snippet lacks %q", want)
			}
		}
		return
	}
	t.Error("README has no Neovim snippet")
}

// shBlock returns the body of the README's first `sh` block that contains want.
func shBlock(t *testing.T, want string) string {
	t.Helper()
	for _, b := range readmeBlocks(t) {
		if b.info == "sh" && strings.Contains(b.body, want) {
			return b.body
		}
	}
	t.Fatalf("README has no sh block with %q", want)
	return ""
}

// goEnv returns the value of the go environment variable key, so a test that
// moves HOME still shares the real build and module caches instead of filling
// the disk with a second copy of every dependency.
func goEnv(t *testing.T, key string) string {
	t.Helper()
	out, err := exec.CommandContext(context.Background(), "go", "env", key).Output() //nolint:gosec // go env with a fixed test-chosen key
	if err != nil {
		t.Fatalf("go env %s: %v", key, err)
	}
	return strings.TrimSpace(string(out))
}

// sh runs script in dir with HOME and GOBIN set, the go caches kept, and bin first on PATH.
func sh(t *testing.T, dir, home, bin, script string) string {
	t.Helper()
	cmd := exec.CommandContext(context.Background(), "sh", "-ec", script) //nolint:gosec // test runs the README's own lines
	cmd.Dir = dir
	cmd.Env = append(os.Environ(), "HOME="+home, "GOBIN="+bin, "GOCACHE="+goEnv(t, "GOCACHE"), "GOMODCACHE="+goEnv(t, "GOMODCACHE"), "PATH="+bin+string(os.PathListSeparator)+os.Getenv("PATH"))
	out, err := cmd.CombinedOutput()
	if err != nil {
		t.Fatalf("sh %q: %v\n%s", script, err, out)
	}
	return string(out)
}

// TestREADMEReleaseInstall builds the linux/amd64 file the way `make dist`
// does, then runs the README's release block on it with HOME in a temp dir.
func TestREADMEReleaseInstall(t *testing.T) {
	if runtime.GOOS != "linux" || runtime.GOARCH != "amd64" {
		t.Skip("the README's release block installs the linux/amd64 file")
	}
	dist, home := t.TempDir(), t.TempDir()
	file := name + "_linux_amd64"
	build := exec.CommandContext(context.Background(), "go", "build", "-trimpath", "-ldflags", "-s -w -X main.version=test", "-o", filepath.Join(dist, file), ".") //nolint:gosec // fixed go build command, temp output path
	build.Env = append(os.Environ(), "CGO_ENABLED=0", "GOOS=linux", "GOARCH=amd64")
	if out, err := build.CombinedOutput(); err != nil {
		t.Fatalf("go build: %v\n%s", err, out)
	}
	sh(t, dist, home, t.TempDir(), "sha256sum "+name+"_* > SHA256SUMS")
	out := sh(t, dist, home, filepath.Join(home, ".local", "bin"), shBlock(t, "sha256sum --check"))
	if !strings.Contains(out, "test") {
		t.Errorf("README release block printed %q, want the version test", out)
	}
}

// TestREADMESourceInstall runs the README's `go install .` with GOBIN in a
// temp dir, then the installed binary.
func TestREADMESourceInstall(t *testing.T) {
	bin := t.TempDir()
	var script string
	for _, line := range strings.Split(shBlock(t, "go install ."), "\n") {
		if strings.HasPrefix(line, "go install") {
			script = line
		}
	}
	if script == "" {
		t.Fatal("README source block has no go install line")
	}
	wd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	sh(t, wd, t.TempDir(), bin, script+"\n"+name+" --version")
}
