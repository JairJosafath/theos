package analysis

import (
	"slices"
	"strings"

	"github.com/google/cel-go/cel"
	"github.com/google/cel-go/common/ast"
	"github.com/google/cel-go/parser"
)

// binding is the iteration variable of a macro that encloses the cursor, such
// as c in containers.all(c, c.
type binding struct {
	// name is the variable; receiver is the text of the expression the macro
	// is called on, whose elements the variable stands for.
	name, receiver string
}

// cursor is what the text before the cursor says about what may come next.
type cursor struct {
	// inString is true when the cursor is in a string literal or a comment,
	// where nothing is completed.
	inString bool
	// member is true after a "." or ".?", whatever blanks are around it; receiver is then the text of the expression
	// left of it.
	member   bool
	receiver string
	// optional is true after ".?", where the receiver may be an optional value
	// whose field is meant.
	optional bool
	// bindings are the iteration variables in scope, outermost first.
	bindings []binding
}

// placeholder stands for the name being typed at the cursor. Parsing the text
// with it in place gives the parser a complete expression, and finding it in the
// tree says what the cursor is: the member of a receiver or a name of its own.
const placeholder = "__cursor__"

// readCursor reads the text of an expression up to the cursor with the parser
// of env. The text often does not parse as it is, so the name being typed is
// replaced by a placeholder and the brackets still open are closed. When the
// result does not parse either, the cursor is a plain one.
func readCursor(env *cel.Env, text string) cursor {
	s := scanner{text: text}
	if !s.scan() {
		return cursor{inString: true}
	}
	for text != "" && isIdent(text[len(text)-1]) {
		text = text[:len(text)-1]
	}
	var closers strings.Builder
	for _, open := range slices.Backward(s.opens) {
		closers.WriteString(closer(s.text[open]))
	}
	env, err := env.Extend(cel.EnableMacroCallTracking()) // to write an expanded macro back as text
	if err != nil {
		return cursor{}
	}
	parsed, iss := env.Parse(text + placeholder + closers.String())
	if iss.Err() != nil {
		return cursor{}
	}
	w := walker{info: parsed.NativeRep().SourceInfo()}
	w.walk(parsed.NativeRep().Expr())
	return w.cur
}

// closer is the bracket that closes the open bracket b.
func closer(b byte) string {
	switch b {
	case '(':
		return ")"
	case '[':
		return "]"
	}
	return "}"
}

// walker finds the placeholder in a parsed expression.
type walker struct {
	info *ast.SourceInfo
	// bindings are the iteration variables of the comprehensions around the
	// node being visited, outermost first.
	bindings []binding
	cur      cursor
}

// walk visits e and below, and reports whether it found the placeholder, which
// leaves the cursor in w.cur.
func (w *walker) walk(e ast.Expr) bool {
	switch e.Kind() {
	case ast.IdentKind:
		switch e.AsIdent() {
		case placeholder:
			return w.found(cursor{})
		case "." + placeholder:
			return w.found(cursor{member: true})
		}
	case ast.SelectKind:
		sel := e.AsSelect()
		if sel.FieldName() == placeholder {
			return w.foundMember(sel.Operand(), false)
		}
		return w.walk(sel.Operand())
	case ast.CallKind:
		call := e.AsCall()
		if call.FunctionName() == "_?._" && len(call.Args()) == 2 {
			if lit := call.Args()[1]; lit.Kind() == ast.LiteralKind && lit.AsLiteral().Value() == placeholder {
				return w.foundMember(call.Args()[0], true)
			}
		}
		if call.IsMemberFunction() && w.walk(call.Target()) {
			return true
		}
		return w.walkAll(call.Args())
	case ast.ListKind:
		return w.walkAll(e.AsList().Elements())
	case ast.MapKind:
		for _, entry := range e.AsMap().Entries() {
			me := entry.AsMapEntry()
			if w.walk(me.Key()) || w.walk(me.Value()) {
				return true
			}
		}
	case ast.StructKind:
		for _, f := range e.AsStruct().Fields() {
			if w.walk(f.AsStructField().Value()) {
				return true
			}
		}
	case ast.ComprehensionKind:
		c := e.AsComprehension()
		if w.walk(c.IterRange()) {
			return true
		}
		b := binding{name: c.IterVar()}
		b.receiver, _ = parser.Unparse(c.IterRange(), w.info)
		w.bindings = append(w.bindings, b)
		defer func() { w.bindings = w.bindings[:len(w.bindings)-1] }()
		return w.walkAll([]ast.Expr{c.AccuInit(), c.LoopCondition(), c.LoopStep(), c.Result()})
	case ast.LiteralKind, ast.UnspecifiedExprKind:
	}
	return false
}

func (w *walker) walkAll(es []ast.Expr) bool {
	return slices.ContainsFunc(es, w.walk)
}

func (w *walker) foundMember(operand ast.Expr, optional bool) bool {
	recv, _ := parser.Unparse(operand, w.info)
	return w.found(cursor{member: true, receiver: recv, optional: optional})
}

func (w *walker) found(c cursor) bool {
	c.bindings = slices.Clone(w.bindings)
	w.cur = c
	return true
}

type scanner struct {
	text string
	// opens are the brackets not closed at the end of text.
	opens []int
}

// scan fills the scanner and reports false when text ends inside a string or
// a comment.
func (s *scanner) scan() bool {
	text := s.text
	for i := 0; i < len(text); {
		switch c := text[i]; c {
		case '\'', '"':
			end, ok := stringEnd(text, i)
			if !ok {
				return false
			}
			i = end
			continue
		case '/':
			if strings.HasPrefix(text[i:], "//") {
				nl := strings.IndexByte(text[i:], '\n')
				if nl < 0 {
					return false
				}
				i += nl
			}
		case '(', '[', '{':
			s.opens = append(s.opens, i)
		case ')', ']', '}':
			if n := len(s.opens); n > 0 {
				s.opens = s.opens[:n-1]
			}
		}
		i++
	}
	return true
}

// stringEnd returns the index after the string literal that starts with the
// quote at text[i], and false when it is not closed. A literal after r or R
// has no escapes; one that opens with three quotes may span lines.
func stringEnd(text string, i int) (int, bool) {
	q := text[i : i+1]
	if strings.HasPrefix(text[i:], strings.Repeat(q, 3)) {
		q = strings.Repeat(q, 3)
	}
	raw := i > 0 && (text[i-1] == 'r' || text[i-1] == 'R')
	for j := i + len(q); j < len(text); j++ {
		switch {
		case text[j] == '\\' && !raw:
			j++
		case strings.HasPrefix(text[j:], q):
			return j + len(q), true
		case text[j] == '\n' && len(q) == 1:
			return 0, false
		}
	}
	return 0, false
}

// isIdentifier reports whether s is a single CEL name.
func isIdentifier(s string) bool {
	if s == "" || s[0] >= '0' && s[0] <= '9' {
		return false
	}
	for i := range len(s) {
		if !isIdent(s[i]) {
			return false
		}
	}
	return true
}
