package analysis

import (
	"slices"
	"testing"

	"github.com/google/cel-go/cel"
)

func testEnv(tb testing.TB) *cel.Env {
	tb.Helper()
	env, err := cel.NewEnv(cel.OptionalTypes())
	if err != nil {
		tb.Fatal(err)
	}
	return env
}

func TestReadCursor(t *testing.T) {
	t.Parallel()
	env := testEnv(t)
	tests := []struct {
		name string
		text string
		want cursor
	}{
		{"empty", "", cursor{}},
		{"name", "obj", cursor{}},
		{"after an operator", "a == ", cursor{}},
		{"member", "object.spec.", cursor{member: true, receiver: "object.spec"}},
		{"member with a prefix", "object.spec.rep", cursor{member: true, receiver: "object.spec"}},
		{"after a call", "a.b(1, x[2]).", cursor{member: true, receiver: "a.b(1, x[2])"}},
		{"after an index", "a.b[0].", cursor{member: true, receiver: "a.b[0]"}},
		{"after a string", "'a.b'.", cursor{member: true, receiver: `"a.b"`}},
		{"receiver stops at an operator", "x && a.b.", cursor{member: true, receiver: "a.b"}},
		{"receiver stops at an open bracket", "f(a.", cursor{member: true, receiver: "a"}},
		{"newline after the dot", "object.\n  ", cursor{member: true, receiver: "object"}},
		{"blanks before the dot", "object . sp", cursor{member: true, receiver: "object"}},
		{"newline before the dot", "object\n  .sp", cursor{member: true, receiver: "object"}},
		{"optional selection", "object.?", cursor{member: true, receiver: "object"}},
		{"optional selection with a prefix", "object.?sp", cursor{member: true, receiver: "object"}},
		{"a dot alone", ".", cursor{member: true}},
		{"in a string", "a == 'x.", cursor{inString: true}},
		{"in a triple-quoted string", `"""a
b.`, cursor{inString: true}},
		{"after a raw string", `r'a\'.`, cursor{member: true, receiver: `"a\\"`}},
		{"after an escaped quote", `'a\'b'.`, cursor{member: true, receiver: `"a'b"`}},
		{"in a comment", "a // b.", cursor{inString: true}},
		{"after a comment", "a + // b\nc.", cursor{member: true, receiver: "c"}},
		{"macro", "xs.all(c, c.", cursor{member: true, receiver: "c", bindings: []binding{{"c", "xs"}}}},
		{"macro, still on the variable", "xs.all(c", cursor{}},
		{"macro after a comma", "xs.map(c, c.a, ", cursor{bindings: []binding{{"c", "xs"}}}},
		{"macro with a call in the argument", "xs.all(c, f(a, b) && ", cursor{bindings: []binding{{"c", "xs"}}}},
		{"closed macro", "xs.all(c, c.a) && ", cursor{}},
		{"nested macros", "a.b.exists(x, x.l.all(y, y.", cursor{member: true, receiver: "y", bindings: []binding{{"x", "a.b"}, {"y", "x.l"}}}},
		{"not a macro", "a.size(c, ", cursor{}},
		{"not a name", "xs.all(1, ", cursor{}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := readCursor(env, tt.text)
			if got.inString != tt.want.inString || got.member != tt.want.member || got.receiver != tt.want.receiver ||
				!slices.Equal(got.bindings, tt.want.bindings) {
				t.Errorf("readCursor(%q) = %+v, want %+v", tt.text, got, tt.want)
			}
		})
	}
}

func FuzzReadCursor(f *testing.F) {
	for _, seed := range []string{"", "a.b.", "xs.all(c, c.", "'a", `"""`, "a(b[c.", "))]]..", "r'\\"} {
		f.Add(seed)
	}
	env := testEnv(f)
	f.Fuzz(func(t *testing.T, text string) {
		got := readCursor(env, text)
		if got.member && len(got.receiver) > len(text) {
			t.Errorf("readCursor(%q).receiver = %q, longer than the text", text, got.receiver)
		}
	})
}
