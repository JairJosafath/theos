package analysis

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"c4factory.local/cel-lens/cel-language-server/internal/locate"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

var update = flag.Bool("update", false, "rewrite the golden files")

// inputs lists the YAML files that have a golden file next to them.
func inputs() ([]string, error) {
	var all []string
	for _, dir := range []string{"policies", "crds"} {
		files, err := filepath.Glob(filepath.Join("..", "..", "testdata", dir, "*.yaml"))
		if err != nil {
			return nil, err
		}
		all = append(all, files...)
	}
	return all, nil
}

// format writes diagnostics as line:col-line:col: message, counting from 1.
func format(ds []Diagnostic) string {
	var b strings.Builder
	for _, d := range ds {
		fmt.Fprintf(&b, "%d:%d-%d:%d: %s\n", d.Range.Start.Line+1, d.Range.Start.Character+1,
			d.Range.End.Line+1, d.Range.End.Character+1, d.Message)
	}
	return b.String()
}

func TestDiagnoseGolden(t *testing.T) {
	t.Parallel()
	files, err := inputs()
	if err != nil || len(files) == 0 {
		t.Fatalf("no testdata: %v", err)
	}
	for _, file := range files {
		t.Run(filepath.Base(filepath.Dir(file))+"/"+strings.TrimSuffix(filepath.Base(file), ".yaml"), func(t *testing.T) {
			t.Parallel()
			src, err := os.ReadFile(file)
			if err != nil {
				t.Fatal(err)
			}
			got := format(diagnose(t, file, src))
			golden := strings.TrimSuffix(file, ".yaml") + ".golden"
			if *update {
				if err := os.WriteFile(golden, []byte(got), 0o600); err != nil {
					t.Fatal(err)
				}
			}
			want, err := os.ReadFile(golden)
			if err != nil {
				t.Fatal(err)
			}
			if got != string(want) {
				t.Errorf("Diagnose(%s) =\n%s\nwant\n%s", file, got, want)
			}
		})
	}
}

func TestDiagnoseInput(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		src  string
		want string
	}{
		{"empty", "", ""},
		{"comment only", "# nothing\n", ""},
		{"not a policy", "apiVersion: v1\nkind: ConfigMap\ndata:\n  a: object.spec.replica\n", ""},
		{"scalar document", "just text\n", ""},
		{"valid policy", "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: object.a == 1\n", ""},
		{"crlf", "apiVersion: admissionregistration.k8s.io/v1\r\nkind: ValidatingAdmissionPolicy\r\nspec:\r\n  validations:\r\n    - expression: \"1 +\"\r\n", "5:23-5:23: Syntax error"},
		{"v1beta1 policy", "apiVersion: admissionregistration.k8s.io/v1beta1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: object.a ==\n", "5:30-5:30: Syntax error"},
		{"wrong field type", "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: [1]\n", "5:19-5:22: invalid"},
		{"webhook wrong field type", "apiVersion: admissionregistration.k8s.io/v1\nkind: MutatingWebhookConfiguration\nwebhooks: 3\n", "3:11-3:12: invalid"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := format(diagnose(t, "x.yaml", []byte(tt.src)))
			if tt.want == "" && got != "" || !strings.HasPrefix(got, tt.want) {
				t.Errorf("Diagnose(%q) = %q, want prefix %q", tt.src, got, tt.want)
			}
			if tt.want != "" && strings.Count(got, "\n") != 1 {
				t.Errorf("Diagnose(%q) = %q, want one diagnostic", tt.src, got)
			}
		})
	}
}

func TestDiagnoseFields(t *testing.T) {
	t.Parallel()
	src := "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: object.a ==\n"
	got := diagnose(t, "x.yaml", []byte(src))
	if len(got) != 1 || got[0].Severity != Error || got[0].Source != "cel" {
		t.Errorf("Diagnose(policy) = %+v, want one Error with source cel", got)
	}
}

func FuzzDiagnose(f *testing.F) {
	files, _ := inputs()
	for _, file := range files {
		if src, err := os.ReadFile(file); err == nil {
			f.Add(src)
		}
	}
	f.Fuzz(func(t *testing.T, src []byte) {
		diagnose(t, "fuzz.yaml", src)
	})
}

func BenchmarkDiagnose(b *testing.B) {
	var src strings.Builder
	src.WriteString("apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nmetadata:\n  name: big\nspec:\n  matchConstraints:\n    resourceRules:\n      - apiGroups: [\"apps\"]\n        apiVersions: [\"v1\"]\n        operations: [\"CREATE\"]\n        resources: [\"deployments\"]\n  variables:\n    - name: replicas\n      expression: object.spec.replicas\n  validations:\n")
	for i := range 330 {
		fmt.Fprintf(&src, "    - expression: variables.replicas <= %d && object.metadata.name.startsWith('a')\n      message: too many replicas\n      messageExpression: \"'replicas ' + string(variables.replicas)\"\n", i+1)
	}
	in := []byte(src.String())
	var an Analyzer
	for b.Loop() {
		if _, err := an.Diagnose(context.Background(), "bench.yaml", in); err != nil {
			b.Fatal(err)
		}
	}
}

func TestDiagnoseSyntaxErrorKeepsOtherDocuments(t *testing.T) {
	t.Parallel()
	const bad = "a: 1\n\tb: 2\n"
	const policy = "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: object.a ==\n"
	tests := []struct {
		name  string
		src   string
		lines [2]int // 0-based lines of the two diagnostics, in order
	}{
		{"broken then policy", bad + "---\n" + policy, [2]int{1, 7}},
		{"policy then broken", policy + "---\n" + bad, [2]int{4, 7}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := diagnose(t, "x.yaml", []byte(tt.src))
			if len(got) != 2 {
				t.Fatalf("Diagnose(%q) = %+v, want 2 diagnostics", tt.src, got)
			}
			if got[0].Range.Start.Line != tt.lines[0] || got[1].Range.Start.Line != tt.lines[1] {
				t.Errorf("Diagnose(%q) lines = %d, %d, want %d, %d", tt.src, got[0].Range.Start.Line, got[1].Range.Start.Line, tt.lines[0], tt.lines[1])
			}
		})
	}
}

func TestDiagnoseDecodeErrorField(t *testing.T) {
	t.Parallel()
	const head = "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\n"
	tests := []struct {
		name string
		src  string
		want Range
	}{
		{"top-level spec field", head + "spec:\n  validations: 5\n", Range{position.Position{Line: 3, Character: 15}, position.Position{Line: 3, Character: 16}}},
		{"field inside a list", head + "spec:\n  validations:\n    - expression: x\n      message: [a]\n", Range{position.Position{Line: 5, Character: 15}, position.Position{Line: 5, Character: 18}}},
		{"bad value in a later list element", head + "spec:\n  validations:\n    - expression: \"true\"\n      message: fine\n    - expression: \"true\"\n      message: [a]\n", Range{position.Position{Line: 7, Character: 15}, position.Position{Line: 7, Character: 18}}},
		{"metadata field", head + "metadata:\n  name: x\n  labels: oops\n", Range{position.Position{Line: 4, Character: 10}, position.Position{Line: 4, Character: 14}}},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			t.Parallel()
			got := diagnose(t, "x.yaml", []byte(tc.src))
			if len(got) != 1 || got[0].Range != tc.want {
				t.Errorf("Diagnose(%q) = %+v, want one diagnostic at %+v", tc.name, got, tc.want)
			}
		})
	}
}

func TestDocErrorFallsBackToDocumentStart(t *testing.T) {
	t.Parallel()
	src := []byte("kind: ValidatingAdmissionPolicy\nspec: {}\n")
	docs, err := locate.Find(context.Background(), src)
	if err != nil || len(docs) != 1 {
		t.Fatalf("Find = %v, %v, want one document", docs, err)
	}
	c := &checker{idx: position.NewIndex(src), body: bodyOf(docs[0])}
	for _, field := range []string{"", "spec.missing"} {
		got := c.docError("ValidatingAdmissionPolicy", &json.UnmarshalTypeError{Field: field})
		if len(got) != 1 || got[0].Range.Start != (position.Position{}) {
			t.Errorf("docError(field %q) = %+v, want one diagnostic at the document start", field, got)
		}
	}
}

// diagnose checks src with a new Analyzer and an uncancelled context.
func diagnose(tb testing.TB, path string, src []byte) []Diagnostic {
	tb.Helper()
	got, err := new(Analyzer).Diagnose(context.Background(), path, src)
	if err != nil {
		tb.Fatalf("Diagnose(%s) error: %v", path, err)
	}
	return got
}

// tenKinds is a policy that matches ten kinds of the embedded schemas, with n
// validations.
func tenKinds(n int) []byte {
	var src strings.Builder
	src.WriteString(`apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingAdmissionPolicy
metadata:
  name: ten
spec:
  matchConstraints:
    resourceRules:
      - apiGroups: ["apps"]
        apiVersions: ["v1"]
        operations: ["CREATE"]
        resources: ["deployments", "statefulsets", "daemonsets", "replicasets"]
      - apiGroups: [""]
        apiVersions: ["v1"]
        operations: ["CREATE"]
        resources: ["pods", "services", "configmaps", "secrets"]
      - apiGroups: ["batch"]
        apiVersions: ["v1"]
        operations: ["CREATE"]
        resources: ["jobs", "cronjobs"]
  validations:
`)
	for i := range n {
		fmt.Fprintf(&src, "    - expression: object.metadata.name.startsWith('a') && size(object.metadata.name) < %d\n", i+10)
	}
	return []byte(src.String())
}

func BenchmarkDiagnoseTenKinds(b *testing.B) {
	in := tenKinds(30)
	b.Run("reused", func(b *testing.B) {
		var an Analyzer
		for b.Loop() {
			if _, err := an.Diagnose(context.Background(), "ten.yaml", in); err != nil {
				b.Fatal(err)
			}
		}
	})
	b.Run("rebuilt", func(b *testing.B) {
		for b.Loop() {
			var an Analyzer
			if _, err := an.Diagnose(context.Background(), "ten.yaml", in); err != nil {
				b.Fatal(err)
			}
		}
	})
}

func TestDiagnoseReusesEnvironments(t *testing.T) {
	t.Parallel()
	in := tenKinds(2)
	var an Analyzer
	for call := 1; call <= 2; call++ {
		if _, err := an.Diagnose(context.Background(), "ten.yaml", in); err != nil {
			t.Fatalf("Diagnose call %d: %v", call, err)
		}
		if call == 1 && an.builds.Load() != maxKinds {
			t.Fatalf("builds after the first call = %d, want %d, one per kind", an.builds.Load(), maxKinds)
		}
	}
	if an.builds.Load() != maxKinds {
		t.Errorf("builds after the second call = %d, want %d, none new", an.builds.Load(), maxKinds)
	}
}

func TestDiagnoseCancelled(t *testing.T) {
	t.Parallel()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	var an Analyzer
	got, err := an.Diagnose(ctx, "ten.yaml", tenKinds(2))
	if !errors.Is(err, context.Canceled) || got != nil {
		t.Errorf("Diagnose(cancelled) = %v, %v, want nil, %v", got, err, context.Canceled)
	}
	if an.builds.Load() != 0 {
		t.Errorf("builds after a cancelled call = %d, want 0", an.builds.Load())
	}
}

func TestDiagnoseUnknownParamKindsShareEnvironments(t *testing.T) {
	t.Parallel()
	var an Analyzer
	for _, kind := range []string{"A", "AB", "ABC", "MyVeryOwnPolicyParameterKindName"} {
		in := strings.Replace(string(tenKinds(1)), "spec:\n", "spec:\n  paramKind:\n    apiVersion: example.com/v1\n    kind: "+kind+"\n", 1)
		if _, err := an.Diagnose(context.Background(), "ten.yaml", []byte(in)); err != nil {
			t.Fatalf("Diagnose(paramKind %s): %v", kind, err)
		}
	}
	if got := an.builds.Load(); got != maxKinds {
		t.Errorf("builds after unknown paramKinds = %d, want %d, one per kind", got, maxKinds)
	}
}

func TestDiagnoseCRDRuleUnderOddPropertyNames(t *testing.T) {
	t.Parallel()
	const head = "apiVersion: apiextensions.k8s.io/v1\nkind: CustomResourceDefinition\nmetadata:\n  name: widgets.example.com\nspec:\n  group: example.com\n  scope: Namespaced\n  names:\n    plural: widgets\n    singular: widget\n    kind: Widget\n  versions:\n    - name: v1\n      served: true\n      storage: true\n      schema:\n        openAPIV3Schema:\n          type: object\n          properties:\n"
	tests := []struct {
		name string
		prop string
	}{
		{"digit", `"1"`},
		{"dots and slash", `example.com/foo`},
		{"brackets", `"a[b]"`},
		{"bracket index", `"a[0]"`},
		{"closing bracket", `"a]b"`},
		{"backslash", `'a\b'`},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			src := head + "            " + tt.prop + ":\n              type: object\n              x-kubernetes-validations:\n                - rule: self.nope > 0\n"
			got := diagnose(t, "crd.yaml", []byte(src))
			lines := strings.Split(src, "\n")
			line := len(lines) - 2
			col := strings.Index(lines[line], "nope")
			if len(got) != 1 {
				t.Fatalf("Diagnose(property %s) = %s, want one diagnostic", tt.prop, format(got))
			}
			r := got[0].Range
			if r.Start.Line != line || r.Start.Character != col || r.End.Line != line || r.End.Character != col+len("nope") {
				t.Errorf("Diagnose(property %s) range = %+v, want %d:%d-%d on the token nope", tt.prop, r, line, col, col+len("nope"))
			}
		})
	}
}

func TestDiagnoseCRDNonStructuralSchemaHint(t *testing.T) {
	t.Parallel()
	const head = "apiVersion: apiextensions.k8s.io/v1\nkind: CustomResourceDefinition\nmetadata:\n  name: widgets.example.com\nspec:\n  group: example.com\n  scope: Namespaced\n  names:\n    plural: widgets\n    singular: widget\n    kind: Widget\n  versions:\n    - name: v1\n      served: true\n      storage: true\n      schema:\n        openAPIV3Schema:\n          type: object\n          properties:\n            size:\n              type: integer\n"
	const rules = "          x-kubernetes-validations:\n            - rule: self.nope > 0\n            - rule: self.size > 0\n"
	tests := []struct {
		name string
		src  string
		want []Diagnostic
	}{
		{"property without type", head + "            loose:\n              description: no type\n" + rules, []Diagnostic{{
			Range:    Range{Start: position.Position{Line: 24, Character: 20}, End: position.Position{Line: 24, Character: 33}},
			Severity: Hint, Message: nonStructuralHint, Source: Source,
		}}},
		{"structural", head + rules, []Diagnostic{{
			Range:    Range{Start: position.Position{Line: 22, Character: 25}, End: position.Position{Line: 22, Character: 29}},
			Severity: Error, Message: "undefined field 'nope'", Source: Source,
		}}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := diagnose(t, "crd.yaml", []byte(tt.src))
			if !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Diagnose(%s) = %s, want %s", tt.name, format(got), format(tt.want))
			}
		})
	}
}
