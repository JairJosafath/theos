// Package analysis checks the CEL in Kubernetes YAML the way the API server
// does, and reports what it finds as editor diagnostics with ranges in the
// file. It reads ValidatingAdmissionPolicy documents, the matchConditions of
// webhook configurations and the x-kubernetes-validations of CustomResourceDefinitions; the schemas come from [k8sschema], so it works
// offline.
package analysis

import (
	"context"
	"errors"
	"fmt"
	"slices"
	"sync"
	"sync/atomic"

	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apiserver/pkg/cel/environment"

	"c4factory.local/cel-lens/cel-language-server/internal/k8sschema"
	"c4factory.local/cel-lens/cel-language-server/internal/locate"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// Source is the Source of every diagnostic.
const Source = "cel"

// Severity is how serious a diagnostic is, with the values of LSP 3.17.
type Severity int

// The severities of LSP 3.17 that Diagnose uses.
const (
	// Error is a problem the API server would reject.
	Error Severity = 1
	// Hint is a note that is no problem, such as why something is not checked.
	Hint Severity = 4
)

// String returns the LSP name of s: "error", "warning", "information" or
// "hint"; any other value gives "unknown".
func (s Severity) String() string {
	names := [...]string{1: "error", 2: "warning", 3: "information", 4: "hint"}
	if s < 1 || int(s) >= len(names) {
		return "unknown"
	}
	return names[s]
}

// Range is a span of a file in LSP positions. End is exclusive; an empty
// range marks a place, such as the end of an expression.
type Range struct {
	Start, End position.Position
}

// Diagnostic is one problem found in a file.
type Diagnostic struct {
	// Range is where the problem is in the file.
	Range Range
	// Severity is how serious the problem is.
	Severity Severity
	// Message says what is wrong, in the API server's words.
	Message string
	// Source is always [Source].
	Source string
}

// Analyzer checks files and keeps what it builds for them, the CEL environment
// of each kind a policy matches, so that later calls do not build it again.
// The zero value is ready to use. It is safe for concurrent use.
type Analyzer struct {
	mu       sync.Mutex
	mapper   *k8sschema.RESTMapper
	resolver k8sschema.Resolver
	envs     map[envKey]*envEntry
	builds   atomic.Int32 // environments built, for tests
}

// restMapper returns the mapper of the embedded files, built on first use.
func (a *Analyzer) restMapper() (*k8sschema.RESTMapper, error) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.mapper == nil {
		m, err := k8sschema.NewRESTMapper()
		if err != nil {
			return nil, err
		}
		a.mapper = m
	}
	return a.mapper, nil
}

// envKey names the environment of a scope by the kinds that type its variables.
type envKey struct {
	object, params schema.GroupVersionKind
	hasParams      bool
}

// envEntry is the environment of one key, built once.
type envEntry struct {
	once sync.Once
	es   *environment.EnvSet
	err  error
}

// envSet returns the environment of sc, built the first time its key is asked
// for. Callers of different keys build at the same time. The key names only
// the kinds that type variables, so a params kind the schemas lack has the
// zero GVK and the cache holds at most one environment per known kind pair.
func (a *Analyzer) envSet(key envKey, sc scope) (*environment.EnvSet, error) {
	a.mu.Lock()
	if a.envs == nil {
		a.envs = map[envKey]*envEntry{}
	}
	e, ok := a.envs[key]
	if !ok {
		e = &envEntry{}
		a.envs[key] = e
	}
	a.mu.Unlock()
	e.once.Do(func() {
		e.es, e.err = sc.envSet()
		a.builds.Add(1)
	})
	return e.es, e.err
}

// Diagnose checks the YAML file src and returns what is wrong with its CEL,
// ordered by position. path names the file in the messages of failures that
// are not the author's. A file with no problems, an empty file and a file with
// no policies give nil. A YAML syntax error gives one diagnostic, next to those of the
// documents without one, and a document that does not decode as its kind
// gives one diagnostic for that document. When ctx is cancelled, Diagnose
// stops and returns nil and ctx.Err().
func (a *Analyzer) Diagnose(ctx context.Context, path string, src []byte) ([]Diagnostic, error) {
	idx := position.NewIndex(src)
	docs, err := locate.Find(ctx, src)
	var out []Diagnostic
	if err != nil {
		var se *locate.SyntaxError
		if !errors.As(err, &se) {
			if ctx.Err() != nil {
				return nil, ctx.Err()
			}
			return []Diagnostic{lineDiagnostic(idx, 1, 1, fmt.Sprintf("cannot read %s: %v", path, err))}, nil
		}
		out = append(out, lineDiagnostic(idx, se.Line, se.Column, se.Msg))
	}
	if len(docs) == 0 {
		return out, nil
	}
	mapper, err := a.restMapper()
	if err != nil {
		return []Diagnostic{lineDiagnostic(idx, 1, 1, fmt.Sprintf("cannot check %s: %v", path, err))}, nil
	}
	for _, doc := range docs {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		c := &checker{path: path, idx: idx, resolver: &a.resolver, mapper: mapper, envs: a.envSet}
		found, err := diagnoseDocument(ctx, c, doc)
		if err != nil {
			return nil, err
		}
		out = append(out, found...)
	}
	slices.SortStableFunc(out, func(a, b Diagnostic) int {
		if a.Range.Start.Line != b.Range.Start.Line {
			return a.Range.Start.Line - b.Range.Start.Line
		}
		return a.Range.Start.Character - b.Range.Start.Character
	})
	return out, nil
}

func diagnoseDocument(ctx context.Context, c *checker, doc locate.Document) ([]Diagnostic, error) {
	c.body = bodyOf(doc)
	switch doc.Kind {
	case "ValidatingAdmissionPolicy":
		return c.policy(ctx, doc)
	case "ValidatingWebhookConfiguration", "MutatingWebhookConfiguration":
		return c.webhooks(doc), ctx.Err()
	case "CustomResourceDefinition":
		return c.crd(doc), ctx.Err()
	}
	return nil, nil
}

// lineDiagnostic marks the line of a file from a 1-based column to its end.
func lineDiagnostic(idx *position.Index, line, column int, msg string) Diagnostic {
	start := position.Position{Line: line - 1, Character: column - 1}
	end := start
	if off, err := idx.Offset(position.Position{Line: line - 1, Character: 1 << 30}); err == nil {
		if p, err := idx.Position(off); err == nil {
			end = p
		}
	}
	if end.Character < start.Character {
		end = start
	}
	return Diagnostic{Range: Range{Start: start, End: end}, Severity: Error, Message: msg, Source: Source}
}
