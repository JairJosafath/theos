package analysis

import (
	"github.com/google/cel-go/cel"

	"k8s.io/apimachinery/pkg/util/version"
	plugincel "k8s.io/apiserver/pkg/admission/plugin/cel"
	apiservercel "k8s.io/apiserver/pkg/cel"
	"k8s.io/apiserver/pkg/cel/environment"
	"k8s.io/apiserver/pkg/cel/library"
)

// scope says what the variables of an admission expression's environment are.
type scope struct {
	// object types object and oldObject; nil means dyn.
	object *apiservercel.DeclType
	// params types params; nil means dyn. It matters only when hasParams.
	params    *apiservercel.DeclType
	hasParams bool
}

// envSet builds the environment of the API server's admission expressions:
// namespaceObject, request, object, oldObject, authorizer, and params when
// the scope has them. It follows the type checker of the validating admission
// policy plugin, which keeps the same variables.
func (s scope) envSet() (*environment.EnvSet, error) {
	namespaceType := plugincel.BuildNamespaceType()
	requestType := plugincel.BuildRequestType()
	declTypes := []*apiservercel.DeclType{namespaceType, requestType}
	opts := []cel.EnvOption{
		cel.Variable(plugincel.NamespaceVarName, namespaceType.CelType()),
		cel.Variable(plugincel.RequestVarName, requestType.CelType()),
		cel.Variable(plugincel.ObjectVarName, celType(s.object)),
		cel.Variable(plugincel.OldObjectVarName, celType(s.object)),
		cel.Variable("authorizer", library.AuthorizerType),
	}
	if s.object != nil {
		declTypes = append(declTypes, s.object)
	}
	if s.hasParams {
		opts = append(opts, cel.Variable(plugincel.ParamsVarName, celType(s.params)))
		if s.params != nil {
			declTypes = append(declTypes, s.params)
		}
	}
	return environment.MustBaseEnvSet(environment.DefaultCompatibilityVersion()).Extend(
		environment.VersionedOptions{
			IntroducedVersion: version.MajorMinor(1, 0),
			EnvOptions:        opts,
			DeclTypes:         declTypes,
		},
	)
}

func celType(t *apiservercel.DeclType) *cel.Type {
	if t == nil {
		return cel.DynType
	}
	return t.CelType()
}
