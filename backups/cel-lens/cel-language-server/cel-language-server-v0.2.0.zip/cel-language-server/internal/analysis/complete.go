package analysis

import (
	"bytes"
	"cmp"
	"context"
	"encoding/json"
	"fmt"
	"regexp"
	"slices"
	"sort"
	"strings"

	"github.com/google/cel-go/cel"
	"github.com/google/cel-go/common/decls"
	"k8s.io/kube-openapi/pkg/validation/spec"
	sigsyaml "sigs.k8s.io/yaml"

	"go.yaml.in/yaml/v3"

	admissionv1 "k8s.io/api/admissionregistration/v1"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/version"
	plugincel "k8s.io/apiserver/pkg/admission/plugin/cel"
	apiservercel "k8s.io/apiserver/pkg/cel"
	"k8s.io/apiserver/pkg/cel/common"
	"k8s.io/apiserver/pkg/cel/environment"
	"k8s.io/apiserver/pkg/cel/openapi"

	"c4factory.local/cel-lens/cel-language-server/internal/k8sschema"
	"c4factory.local/cel-lens/cel-language-server/internal/locate"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// ItemKind is what a completion item stands for. The zero value is not a
// valid kind.
type ItemKind int

// The kinds of completion item.
const (
	// Field is a field of an object.
	Field ItemKind = iota + 1
	// Variable is a variable in scope.
	Variable
	// Function is a function of the environment.
	Function
	// Keyword is a macro, which is syntax rather than a function.
	Keyword
)

// Item is one completion.
type Item struct {
	// Label is the text the item inserts, unless Snippet is set.
	Label string
	// Kind says what the item is.
	Kind ItemKind
	// Detail is the CEL type of a field or variable, or the signature of a
	// function; empty when unknown.
	Detail string
	// Documentation is the description of a field in its schema, or of a
	// function or macro with examples; empty when there is none.
	Documentation string
	// Snippet is the text to insert in the syntax of LSP snippets, for macros;
	// empty for the other kinds.
	Snippet string
}

// Complete returns the completions at pos in the YAML file src: the fields,
// variables, functions and macros that fit the CEL expression the position is
// in, typed by the environment of that place. Items are ordered by kind,
// then name. A position outside a CEL expression, inside
// a string of one, in a file that is not valid YAML, or after something whose
// type is unknown gives nil. path names the file in messages; Complete is safe
// for concurrent use.
func Complete(path string, src []byte, pos position.Position) []Item {
	off, err := position.NewIndex(src).Offset(pos)
	if err != nil {
		return nil
	}
	src = withPlaceholder(src, off)
	sp, ok := findSpot(path, src, off)
	if !ok {
		return nil
	}
	return sp.pl.items(sp.site.Text[:sp.at])
}

// spot is a position inside a CEL expression, with the place of the expression.
type spot struct {
	pl   *place
	site site
	// at is the index in site.Text of the byte at the position.
	at  int
	idx *position.Index
}

// findSpot finds the expression of the YAML file src that contains the byte
// offset off, and the place it is in. It reports false for a position outside
// every expression, a document that is not valid YAML, and a place whose
// environment cannot be built.
func findSpot(path string, src []byte, off int) (spot, bool) {
	idx := position.NewIndex(src)
	docs, _ := locate.Find(context.Background(), src) // the documents without a syntax error still count
	for _, doc := range docs {
		c := &checker{path: path, idx: idx, body: bodyOf(doc), resolver: &k8sschema.Resolver{}}
		sites := c.sites(doc)
		for i, s := range sites {
			if at, ok := s.index(src, off); ok {
				pl := c.place(doc, sites, i)
				if pl == nil {
					return spot{}, false
				}
				return spot{pl: pl, site: s, at: at, idx: idx}, true
			}
		}
	}
	return spot{}, false
}

// emptyExpression matches the text of a line before the cursor when the line
// starts an expression that has no text yet.
var emptyExpression = regexp.MustCompile(`^[ \t-]*(?:expression|rule|messageExpression|valueExpression):[ \t]*$`)

// withPlaceholder gives an expression that is still empty at off one
// character, because the YAML of an empty value holds no scalar to find the
// expression by. The placeholder is after the cursor, so it is not completed.
func withPlaceholder(src []byte, off int) []byte {
	start := bytes.LastIndexByte(src[:off], '\n') + 1
	end := off
	for end < len(src) && (src[end] == ' ' || src[end] == '\t') {
		end++
	}
	if end < len(src) && src[end] != '\n' && src[end] != '\r' || !emptyExpression.Match(src[start:off]) {
		return src
	}
	return slices.Concat(src[:off], []byte("_"), src[off:])
}

// index returns the index in the text of the expression of the byte at the file
// offset off of src, and false when off is not inside the expression. Blanks after a plain
// scalar are not part of it, but the cursor there is still at its end.
func (s site) index(src []byte, off int) (int, bool) {
	if len(s.offs) == 0 || off < s.offs[0] {
		return 0, false
	}
	if end := s.offs[len(s.offs)-1]; off > end {
		if len(bytes.Trim(src[end:off], " \t")) > 0 {
			return 0, false
		}
		off = end
	}
	return sort.Search(len(s.offs), func(i int) bool { return s.offs[i] > off }) - 1, true
}

// variableDocs describes the variables of expressions.
var variableDocs = map[string]string{
	"object":          "The object of the request. It is null for DELETE requests.",
	"oldObject":       "The existing object. It is null for CREATE requests.",
	"request":         "The attributes of the admission request.",
	"params":          "The parameter resource the policy binding refers to; null without spec.paramKind.",
	"namespaceObject": "The namespace of the object of the request. It is null for cluster-scoped resources.",
	"authorizer":      "Checks what the user of the request may do, such as authorizer.group('apps').resource('deployments').check('create').allowed().",
	"variables":       "The values of spec.variables, by name.",
	"self":            "The value of the schema node the rule is on.",
	"oldSelf":         "The value before the update, for rules that compare it with self.",
}

// matchScope and policyScope are the variables a place offers.
var (
	matchScope  = []string{"object", "oldObject", "request", "namespaceObject", "authorizer"}
	policyScope = []string{"object", "oldObject", "request", "params", "namespaceObject", "authorizer", "variables"}
)

// named is a policy variable with its type.
type named struct {
	name string
	typ  *cel.Type
}

// place is what completion knows about where an expression is.
type place struct {
	env *cel.Env
	// scope names the variables the place offers.
	scope []string
	reg   registry
	// variables are the policy variables defined before the expression.
	variables []named
}

// bodyOf returns the mapping of a document, below the document node.
func bodyOf(doc locate.Document) *yaml.Node {
	body := doc.Node
	if body.Kind == yaml.DocumentNode && len(body.Content) == 1 {
		body = body.Content[0]
	}
	return body
}

// place returns the place of sites[at], or nil when its environment cannot be built.
func (c *checker) place(doc locate.Document, sites []site, at int) *place {
	var pl *place
	var err error
	switch doc.Kind {
	case "ValidatingAdmissionPolicy":
		pl, err = c.policyPlace(doc, sites, at)
	case "ValidatingWebhookConfiguration", "MutatingWebhookConfiguration":
		pl, err = webhookPlace()
	case "CustomResourceDefinition":
		pl, err = c.crdPlace(sites[at])
	}
	if err != nil {
		return nil
	}
	return pl
}

func webhookPlace() (*place, error) {
	es, err := scope{}.envSet()
	if err != nil {
		return nil, err
	}
	env, err := es.Env(mode)
	if err != nil {
		return nil, err
	}
	reg := registry{}
	reg.add(plugincel.BuildNamespaceType(), nil)
	reg.add(plugincel.BuildRequestType(), nil)
	return &place{env: env, scope: matchScope, reg: reg}, nil
}

// policyPlace builds the environment of a policy's expression like the
// checker does, for the first kind the policy matches that the embedded
// schemas know, with the variables that precede the expression stored.
func (c *checker) policyPlace(doc locate.Document, sites []site, at int) (*place, error) {
	var policy admissionv1.ValidatingAdmissionPolicy
	if err := decode(doc, &policy); err != nil {
		return nil, err
	}
	mapper, err := k8sschema.NewRESTMapper()
	if err != nil {
		return nil, err
	}
	c.mapper = mapper
	reg := registry{}
	reg.add(plugincel.BuildNamespaceType(), nil)
	reg.add(plugincel.BuildRequestType(), nil)
	sc := scope{hasParams: true}
	if pk := policy.Spec.ParamKind; pk != nil {
		if gv, err := schema.ParseGroupVersion(pk.APIVersion); err == nil {
			if dt, s := c.declAndSchema(gv.WithKind(pk.Kind), "Params"); dt != nil {
				sc.params = dt
				reg.add(dt, s)
			}
		}
	}
	for _, gvk := range c.kinds(&policy) {
		if dt, s := c.declAndSchema(gvk, ""); dt != nil {
			sc.object = dt
			reg.add(dt, s)
			break
		}
	}
	es, err := sc.envSet()
	if err != nil {
		return nil, err
	}
	comp, err := plugincel.NewCompositedCompilerForTypeChecking(es)
	if err != nil {
		return nil, err
	}
	rec := &recorder{comp: comp}
	comp.Compiler = rec
	pl := &place{reg: reg, scope: policyScope}
	if sites[at].Kind == locate.MatchCondition {
		pl.scope = matchScope
	}
	for _, s := range sites[:at] {
		if s.Kind != locate.Variable {
			continue
		}
		i := index(s.Path)
		if i >= len(policy.Spec.Variables) {
			continue
		}
		name := policy.Spec.Variables[i].Name
		res := comp.CompileAndStoreVariable(variable{name: name, text: s.Text}, plugincel.OptionalVariableDeclarations{}, mode)
		pl.variables = append(pl.variables, named{name, res.OutputType})
	}
	pl.env, err = comp.Env(mode)
	if err != nil {
		return nil, err
	}
	return pl, nil
}

// crdPlace builds the environment of a CRD rule: self is the schema node the
// rule is on, and oldSelf is there where the API server allows transition rules.
func (c *checker) crdPlace(s site) (*place, error) {
	path, _, ok := strings.Cut(s.Path, ".x-kubernetes-validations[")
	node := nodeAt(c.body, path)
	if !ok || node == nil {
		return nil, fmt.Errorf("find the schema of %s", s.Path)
	}
	raw, err := yaml.Marshal(node)
	if err == nil {
		raw, err = sigsyaml.YAMLToJSON(raw)
	}
	var sch spec.Schema
	if err == nil {
		err = json.Unmarshal(raw, &sch)
	}
	if err != nil {
		return nil, fmt.Errorf("read the schema of %s: %w", s.Path, err)
	}
	decl := common.SchemaDeclType(&openapi.Schema{Schema: &sch}, strings.HasSuffix(path, ".openAPIV3Schema"))
	if decl == nil {
		return nil, fmt.Errorf("type the schema of %s", s.Path)
	}
	decl = decl.MaybeAssignTypeName("self")
	pl := &place{scope: []string{"self"}}
	opts := []cel.EnvOption{cel.Variable("self", decl.CelType())}
	if c.transitionAllowed(path) {
		pl.scope = append(pl.scope, "oldSelf")
		opts = append(opts, cel.Variable("oldSelf", decl.CelType()))
	}
	es, err := environment.MustBaseEnvSet(environment.DefaultCompatibilityVersion()).Extend(
		environment.VersionedOptions{
			IntroducedVersion: version.MajorMinor(1, 0),
			EnvOptions:        opts,
			DeclTypes:         []*apiservercel.DeclType{decl},
		},
	)
	if err != nil {
		return nil, err
	}
	if pl.env, err = es.Env(mode); err != nil {
		return nil, err
	}
	pl.reg = registry{}
	pl.reg.add(decl, &sch)
	return pl, nil
}

// transitionAllowed reports whether a rule on the schema at path may use
// oldSelf: not below the items of a list that is not a map-type list, whose
// items cannot be matched with their old values.
func (c *checker) transitionAllowed(path string) bool {
	segs := strings.Split(path, ".")
	for k, seg := range segs {
		if seg != "items" || k == 0 || segs[k-1] == "properties" {
			continue
		}
		parent := strings.Join(segs[:k], ".")
		if n := nodeAt(c.body, parent+".x-kubernetes-list-type"); n == nil || n.Value != "map" {
			return false
		}
	}
	return true
}

// registry finds the object types of an environment by name, with the
// descriptions of their fields.
type registry map[string]typeInfo

type typeInfo struct {
	decl *apiservercel.DeclType
	// docs maps a field to its description in the schema.
	docs map[string]string
}

// add registers the object types in t and below, with their descriptions from
// s, which may be nil.
func (r registry) add(t *apiservercel.DeclType, s *spec.Schema) {
	switch {
	case t == nil:
	case t.IsObject():
		info := typeInfo{decl: t, docs: map[string]string{}}
		for name, f := range t.Fields {
			var sub *spec.Schema
			if s != nil {
				if p, ok := s.Properties[name]; ok {
					sub = &p
					info.docs[name] = p.Description
				}
			}
			r.add(f.Type, sub)
		}
		r[t.TypeName()] = info
	case t.IsList():
		var sub *spec.Schema
		if s != nil && s.Items != nil {
			sub = s.Items.Schema
		}
		r.add(t.ElemType, sub)
	case t.IsMap():
		var sub *spec.Schema
		if s != nil && s.AdditionalProperties != nil {
			sub = s.AdditionalProperties.Schema
		}
		r.add(t.ElemType, sub)
	}
}

// bind reads the text of an expression before a position with the parser: the
// cursor, and the environment extended with the iteration variables of the macros around it.
func (p *place) bind(before string) (env *cel.Env, locals []named, cur cursor) {
	cur = readCursor(p.env, before)
	env = p.env
	if cur.inString {
		return env, nil, cur
	}
	for _, b := range cur.bindings {
		t := cel.DynType
		if rt, ok := p.receiverType(env, b.receiver); ok {
			t = elementType(rt)
		}
		next, err := env.Extend(cel.Variable(b.name, t))
		if err != nil {
			continue
		}
		env = next
		locals = append(locals, named{b.name, t})
	}
	return env, locals, cur
}

// items returns the completions after the text of an expression.
func (p *place) items(before string) []Item {
	macros := p.env.Macros()
	env, locals, cur := p.bind(before)
	if cur.inString {
		return nil
	}
	if !cur.member {
		return p.globals(env, locals, macros)
	}
	if cur.receiver == "" {
		return nil
	}
	if cur.receiver == "variables" && slices.Contains(p.scope, "variables") {
		return p.variableItems()
	}
	t, ok := receiverType(env, cur.receiver)
	if !ok {
		return nil
	}
	if cur.optional {
		t = unwrapOptional(t)
	}
	if inner := unwrapOptional(t); inner != t {
		// A field of an optional value is selected, and stays optional.
		items := members(env, t, macros)
		if info, ok := p.reg[inner.TypeName()]; ok && inner.Kind() == cel.StructKind {
			items = append(items, info.fieldItems()...)
			sortItems(items)
		}
		return items
	}
	if info, ok := p.reg[t.TypeName()]; ok && t.Kind() == cel.StructKind {
		return info.fieldItems()
	}
	return members(env, t, macros)
}

// receiverType is receiverType of the environment, except that variables.name
// has the type of the policy variable name when the place offers variables.
func (p *place) receiverType(env *cel.Env, text string) (*cel.Type, bool) {
	if name, ok := strings.CutPrefix(text, "variables."); ok && slices.Contains(p.scope, "variables") {
		for _, v := range p.variables {
			if v.name == name {
				return v.typ, true
			}
		}
	}
	return receiverType(env, text)
}

// receiverType is the type of the value the expression text evaluates to. In a
// CRD environment a dotted path such as self.tags compiles to the type of a
// type, wrapping the type of the value; receiverType unwraps it.
func receiverType(env *cel.Env, text string) (*cel.Type, bool) {
	ast, iss := env.Compile(text)
	if iss.Err() != nil {
		return nil, false
	}
	t := ast.OutputType()
	if t.Kind() == cel.TypeKind && len(t.Parameters()) == 1 {
		t = t.Parameters()[0]
	}
	return t, true
}

// unwrapOptional is the type of the value in t when t is optional_type(T),
// the type of a field selected with ".?": it is T that the next field is of.
func unwrapOptional(t *cel.Type) *cel.Type {
	if t.Kind() == cel.OpaqueKind && t.TypeName() == "optional_type" && len(t.Parameters()) == 1 {
		return t.Parameters()[0]
	}
	return t
}

// elementType is the type of the iteration variable of a macro over a value of
// type t: the element of a list, the key of a map.
func elementType(t *cel.Type) *cel.Type {
	if (t.Kind() == cel.ListKind || t.Kind() == cel.MapKind) && len(t.Parameters()) > 0 {
		return t.Parameters()[0]
	}
	return cel.DynType
}

func (i typeInfo) fieldItems() []Item {
	items := make([]Item, 0, len(i.decl.Fields))
	for name, f := range i.decl.Fields {
		items = append(items, Item{Label: name, Kind: Field, Detail: f.Type.CelType().String(), Documentation: strings.TrimSpace(i.docs[name])})
	}
	sortItems(items)
	return items
}

func (p *place) variableItems() []Item {
	items := make([]Item, 0, len(p.variables))
	for _, v := range p.variables {
		detail := cel.DynType.String()
		if v.typ != nil {
			detail = v.typ.String()
		}
		items = append(items, Item{Label: v.name, Kind: Field, Detail: detail})
	}
	sortItems(items)
	return items
}

// globals returns what may start an expression: the variables of the place and
// of the enclosing macros, the functions called without a receiver, and the
// macros that are not.
func (p *place) globals(env *cel.Env, locals []named, macros []cel.Macro) []Item {
	var items []Item
	declared := map[string]*cel.Type{}
	for _, v := range env.Variables() {
		declared[v.Name()] = v.Type()
	}
	for _, name := range p.scope {
		items = append(items, Item{Label: name, Kind: Variable, Detail: typeString(declared[name]), Documentation: variableDocs[name]})
	}
	for _, v := range locals {
		items = append(items, Item{Label: v.name, Kind: Variable, Detail: typeString(v.typ)})
	}
	for name, f := range env.Functions() {
		if !isIdentifier(name) || strings.HasPrefix(name, "_") {
			continue
		}
		for _, o := range f.OverloadDecls() {
			if !o.IsMemberFunction() {
				items = append(items, functionItem(f, o))
				break
			}
		}
	}
	items = append(items, macroItems(macros, false)...)
	sortItems(items)
	return items
}

// members returns what may follow a "." after a value of type t: the functions
// and macros called on it.
func members(env *cel.Env, t *cel.Type, macros []cel.Macro) []Item {
	var items []Item
	for name, f := range env.Functions() {
		if !isIdentifier(name) || strings.HasPrefix(name, "_") {
			continue
		}
		for _, o := range f.OverloadDecls() {
			if o.IsMemberFunction() && len(o.ArgTypes()) > 0 && accepts(o.ArgTypes()[0], t) {
				items = append(items, functionItem(f, o))
				break
			}
		}
	}
	if k := t.Kind(); k == cel.ListKind || k == cel.MapKind || k == cel.DynKind {
		items = append(items, macroItems(macros, true)...)
	}
	sortItems(items)
	return items
}

// accepts reports whether a member function whose receiver is declared as
// param can be called on a value of type t.
func accepts(param, t *cel.Type) bool {
	pk, tk := param.Kind(), t.Kind()
	switch {
	case pk == cel.DynKind || pk == cel.TypeParamKind || tk == cel.DynKind || tk == cel.TypeParamKind:
		return true
	case pk != tk:
		return false
	case pk == cel.OpaqueKind || pk == cel.StructKind:
		return param.TypeName() == t.TypeName()
	}
	return true
}

// signature is how an overload of f is written: name(args) -> result, or
// receiver.name(args) -> result for a member function.
func signature(f *decls.FunctionDecl, o *decls.OverloadDecl) string {
	args := make([]string, len(o.ArgTypes()))
	for i, a := range o.ArgTypes() {
		args[i] = a.String()
	}
	sig := f.Name() + "(" + strings.Join(args, ", ") + ")"
	if o.IsMemberFunction() {
		sig = args[0] + "." + f.Name() + "(" + strings.Join(args[1:], ", ") + ")"
	}
	return sig + " -> " + o.ResultType().String()
}

func functionItem(f *decls.FunctionDecl, o *decls.OverloadDecl) Item {
	sig := signature(f, o)
	if n := len(f.OverloadDecls()); n > 1 {
		sig += fmt.Sprintf(" (+%d overloads)", n-1)
	}
	return Item{Label: f.Name(), Kind: Function, Detail: sig, Documentation: functionDocumentation(f)}
}

// macroItems returns the items of the macros that are called on a receiver or
// not, one per name, in the form with the fewest arguments.
func macroItems(macros []cel.Macro, receiver bool) []Item {
	least := map[string]cel.Macro{}
	for _, m := range macros {
		if old, ok := least[m.Function()]; m.IsReceiverStyle() == receiver && (!ok || m.ArgCount() < old.ArgCount()) {
			least[m.Function()] = m
		}
	}
	items := make([]Item, 0, len(least))
	for _, m := range least {
		items = append(items, macroItem(m))
	}
	return items
}

// macroItem returns the item of a macro, which inserts its call with the
// iteration variable and the arguments as snippet placeholders.
func macroItem(m cel.Macro) Item {
	args := make([]string, m.ArgCount())
	for i := range args {
		args[i] = fmt.Sprintf("${%d}", i+1)
	}
	if m.IsReceiverStyle() && len(args) > 0 {
		args[0] = "${1:x}"
	}
	return Item{Label: m.Function(), Kind: Keyword, Detail: "macro", Documentation: macroDocumentation(m.Function()), Snippet: m.Function() + "(" + strings.Join(args, ", ") + ")"}
}

func typeString(t *cel.Type) string {
	if t == nil {
		return cel.DynType.String()
	}
	return t.String()
}

// sortItems orders items by kind, then label, then snippet.
func sortItems(items []Item) {
	slices.SortStableFunc(items, func(a, b Item) int {
		return cmp.Or(cmp.Compare(a.Kind, b.Kind), strings.Compare(a.Label, b.Label), strings.Compare(a.Snippet, b.Snippet))
	})
}
