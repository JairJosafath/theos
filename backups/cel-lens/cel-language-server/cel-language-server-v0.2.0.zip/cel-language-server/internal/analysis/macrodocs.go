package analysis

import "sync"

// macroDocs returns the documentation of the macros of Kubernetes' CEL
// environment by name, all their forms. Every example compiles in the
// environment of admission expressions. It is safe for concurrent use and its
// result must not be modified.
var macroDocs = sync.OnceValue(func() map[string]funcDoc {
	return map[string]funcDoc{
		"has": {
			description: "Tests whether a field is present, without failing when it is not: has(m.x) is false when the map or object m has no x. The argument must be a field selection, and a map key counts as a field.",
			examples:    []string{"has({'a': 1}.a)"},
		},
		"all": {
			description: "Tests that a predicate holds for every element of a list, or every key of a map; it is true for an empty one. With two variables, as Kubernetes enables, the predicate sees the index and the element of a list, or the key and the value of a map.",
			examples:    []string{"[1, 2, 3].all(x, x > 0)", "{'a': 1, 'b': 2}.all(k, v, v > 0)", "['a', 'b'].all(i, v, v != '')"},
		},
		"exists": {
			description: "Tests that a predicate holds for at least one element of a list, or one key of a map; it is false for an empty one. With two variables the predicate sees the index and the element of a list, or the key and the value of a map.",
			examples:    []string{"[1, 2, 3].exists(x, x > 2)", "{'a': 1, 'b': 2}.exists(k, v, k == 'b' && v == 2)"},
		},
		"exists_one": {
			description: "Tests that a predicate holds for exactly one element of a list, or one key of a map. With two variables the predicate sees the index and the element of a list, or the key and the value of a map. existsOne is another name for the two-variable form.",
			examples:    []string{"[1, 2, 3].exists_one(x, x > 2)", "{'a': 1, 'b': 2}.exists_one(k, v, v > 1)"},
		},
		"existsOne": {
			description: "Tests that a predicate holds for exactly one element of a list, or one key of a map, seeing the index and the element of a list, or the key and the value of a map. It is the two-variable form of exists_one.",
			examples:    []string{"[1, 2, 3].existsOne(i, v, i == 0 && v == 1)"},
		},
		"map": {
			description: "Returns a list with a transform applied to every element of a list, or every key of a map. With a predicate in the middle, only the elements for which it holds are transformed.",
			examples:    []string{"[1, 2, 3].map(x, x * 2)", "[1, 2, 3].map(x, x > 1, x * 2)", "{'a': 1}.map(k, k + '!')"},
		},
		"filter": {
			description: "Returns a list of the elements of a list, or the keys of a map, for which a predicate holds, in order.",
			examples:    []string{"[1, 2, 3].filter(x, x > 1)", "{'a': 1, 'b': 2}.filter(k, k != 'a')"},
		},
		"optMap": {
			description: "Applies a transform to the value of an optional and returns an optional of the result; an optional without a value stays without one.",
			examples:    []string{"optional.of(2).optMap(x, x * 2)"},
		},
		"optFlatMap": {
			description: "Applies a transform that returns an optional to the value of an optional, and returns that optional rather than one wrapped in another; an optional without a value stays without one.",
			examples:    []string{"optional.of(2).optFlatMap(x, optional.of(x * 2))"},
		},
		"transformList": {
			description: "Two-variable comprehension that returns a list: the transform is evaluated for each index and element of a list, or each key and value of a map, in order. With a predicate before the transform, only the entries for which it holds contribute.",
			examples:    []string{"['a', 'b'].transformList(i, v, string(i) + v)", "[1, 2, 3, 4].transformList(i, v, i % 2 == 0, v * 10)", "{'a': 1}.transformList(k, v, k + string(v))"},
		},
		"transformMap": {
			description: "Two-variable comprehension that returns a map: it keeps the keys of a map, or the indexes of a list, and replaces each value with the transform of the key and value. With a predicate before the transform, only the entries for which it holds are kept.",
			examples:    []string{"{'a': 1, 'b': 2}.transformMap(k, v, v + 1)", "{'a': 1, 'b': 2}.transformMap(k, v, v > 1, v * 10)", "['x', 'y'].transformMap(i, v, v + v)"},
		},
		"transformMapEntry": {
			description: "Two-variable comprehension that returns a map built from entries: the third argument is a one-entry map made for each key and value of a map, or index and element of a list. Entries that share a key are an error. With a predicate before it, only the entries for which it holds contribute.",
			examples:    []string{"{'a': 1, 'b': 2}.transformMapEntry(k, v, {v: k})", "['x', 'y'].transformMapEntry(i, v, {v: i})", "{'a': 1, 'b': 2}.transformMapEntry(k, v, v > 1, {k + '!': v})"},
		},
		"sortBy": {
			description: "Returns a list sorted in ascending order of a key computed for each element. The keys must be of one comparable type.",
			examples:    []string{"[{'n': 2}, {'n': 1}].sortBy(e, e.n)"},
		},
	}
})

// macroDocumentation returns the description of the macro name followed by its
// examples, as functionDocumentation does for a function; empty when nothing
// documents it.
func macroDocumentation(name string) string {
	doc := macroDocs()[name]
	return withExamples(doc.description, doc.examples)
}
