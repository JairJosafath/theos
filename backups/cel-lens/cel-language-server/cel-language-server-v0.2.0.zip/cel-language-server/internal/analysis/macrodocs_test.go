package analysis

import (
	"strings"
	"testing"
)

func TestMacrosDocumented(t *testing.T) {
	t.Parallel()
	seen := map[string]bool{}
	for _, m := range docEnv(t).Macros() {
		seen[m.Function()] = true
		doc := macroDocs()[m.Function()]
		if strings.TrimSpace(doc.description) == "" {
			t.Errorf("macro %s has no description; add it to macroDocs", m.Function())
		}
		if len(doc.examples) == 0 {
			t.Errorf("macro %s has no example; add it to macroDocs", m.Function())
		}
	}
	for name := range macroDocs() {
		if !seen[name] {
			t.Errorf("macroDocs documents %s, which the environment does not have", name)
		}
	}
}

func TestMacroExamplesCompile(t *testing.T) {
	t.Parallel()
	env := docEnv(t)
	for name, doc := range macroDocs() {
		for _, e := range doc.examples {
			t.Run(name+"/"+e, func(t *testing.T) {
				t.Parallel()
				if _, iss := env.Compile(e); iss.Err() != nil {
					t.Errorf("Compile(%q) = %v, want no error", e, iss.Err())
				}
			})
		}
	}
}

func TestMacroDocumentationShown(t *testing.T) {
	t.Parallel()
	tests := []struct {
		macro string
		hover string // the expression to hover the macro in
		after string // the expression to complete the macro in
		want  string // a part of the documentation
	}{
		{"all", "object.spec.template.spec.containers.al|l(c, true)", "object.spec.template.spec.containers.|", "`[1, 2, 3].all(x, x > 0)`"},
		{"exists", "object.spec.template.spec.containers.exi|sts(c, true)", "object.spec.template.spec.containers.|", "`[1, 2, 3].exists(x, x > 2)`"},
		{"exists_one", "object.spec.template.spec.containers.exists_o|ne(c, true)", "object.spec.template.spec.containers.|", "`[1, 2, 3].exists_one(x, x > 2)`"},
		{"map", "object.spec.template.spec.containers.m|ap(c, c.name)", "object.spec.template.spec.containers.|", "`[1, 2, 3].map(x, x * 2)`"},
		{"filter", "object.spec.template.spec.containers.fil|ter(c, true)", "object.spec.template.spec.containers.|", "`[1, 2, 3].filter(x, x > 1)`"},
		{"has", "ha|s(object.spec.replicas)", "|", "`has({'a': 1}.a)`"},
		{"transformList", "object.metadata.labels.transform|List(k, v, k + v)", "object.metadata.labels.|", "`['a', 'b'].transformList(i, v, string(i) + v)`"},
		{"transformMap", "object.metadata.labels.transform|Map(k, v, v)", "object.metadata.labels.|", "`{'a': 1, 'b': 2}.transformMap(k, v, v + 1)`"},
		{"transformMapEntry", "object.metadata.labels.transform|MapEntry(k, v, {k:v})", "object.metadata.labels.|", "`{'a': 1, 'b': 2}.transformMapEntry(k, v, {v: k})`"},
	}
	for _, tt := range tests {
		t.Run(tt.macro, func(t *testing.T) {
			t.Parallel()
			h := explain(policy(tt.hover))
			if h == nil {
				t.Fatalf("Explain(%s) = nil, want its documentation", tt.macro)
			}
			if !strings.HasPrefix(h.Signature, "macro "+tt.macro+"(") {
				t.Errorf("Explain(%s).Signature = %q, want a macro signature", tt.macro, h.Signature)
			}
			it, ok := find(complete(t, policy(tt.after)), tt.macro)
			if !ok {
				t.Fatalf("Complete(%s) has no %s", tt.after, tt.macro)
			}
			for what, doc := range map[string]string{"Explain": h.Documentation, "Complete": it.Documentation} {
				if strings.TrimSpace(strings.SplitN(doc, "\n", 2)[0]) == "" {
					t.Errorf("%s(%s) documentation = %q, want a description", what, tt.macro, doc)
				}
				if !strings.Contains(doc, "Examples:") || !strings.Contains(doc, tt.want) {
					t.Errorf("%s(%s) documentation = %q, want examples with %q", what, tt.macro, doc, tt.want)
				}
			}
		})
	}
}

func TestTransformDocumentationTwoVariables(t *testing.T) {
	t.Parallel()
	for _, name := range []string{"transformList", "transformMap", "transformMapEntry"} {
		doc := macroDocumentation(name)
		if !strings.Contains(doc, "Two-variable") || !strings.Contains(doc, name+"(k, v,") && !strings.Contains(doc, name+"(i, v,") {
			t.Errorf("macroDocumentation(%s) = %q, want the two-variable form explained and shown", name, doc)
		}
	}
}
