package analysis

import (
	"strings"
	"sync"

	"github.com/google/cel-go/common/decls"
)

// funcDoc documents the function or operator of one name, all its overloads.
type funcDoc struct {
	// description is one paragraph; empty keeps the description the function
	// declares itself, which cel-go's standard functions already carry.
	description string
	// examples are CEL expressions that compile in the environment of
	// admission expressions.
	examples []string
}

// functionDocs returns the documentation of the functions of Kubernetes' CEL
// environment by name: the Kubernetes libraries, whose declarations carry
// none, and examples for every function. It is safe for concurrent use and
// its result must not be modified.
var functionDocs = sync.OnceValue(func() map[string]funcDoc {
	return map[string]funcDoc{
		// Operators.
		"!_":      {examples: []string{"!(1 > 2)"}},
		"-_":      {examples: []string{"-(1 + 2)"}},
		"_!=_":    {examples: []string{"'a' != 'b'"}},
		"_%_":     {examples: []string{"7 % 3"}},
		"_&&_":    {examples: []string{"1 < 2 && 'a' == 'a'"}},
		"_*_":     {examples: []string{"6 * 7"}},
		"_+_":     {examples: []string{"1 + 2", "'a' + 'b'", "[1] + [2]"}},
		"_-_":     {examples: []string{"5 - 3", "timestamp('2024-01-02T00:00:00Z') - timestamp('2024-01-01T00:00:00Z')"}},
		"_/_":     {examples: []string{"7 / 2"}},
		"_<=_":    {examples: []string{"1 <= 2"}},
		"_<_":     {examples: []string{"1 < 2"}},
		"_==_":    {examples: []string{"'a' == 'a'"}},
		"_>=_":    {examples: []string{"2 >= 1"}},
		"_>_":     {examples: []string{"2 > 1"}},
		"_?._":    {examples: []string{"{'a': 1}.?a"}},
		"_?_:_":   {examples: []string{"1 < 2 ? 'yes' : 'no'"}},
		"_[?_]":   {examples: []string{"[1, 2][?0]"}},
		"_[_]":    {examples: []string{"[1, 2][0]", "{'a': 1}['a']"}},
		"_||_":    {examples: []string{"1 > 2 || 'a' == 'a'"}},
		"in":      {description: "Tests whether a value is an element of a list or a key of a map. It is the operator `in`, written between the value and the list or map.", examples: []string{"1 in [1, 2, 3]", "'a' in {'a': 1}"}},
		"_in_":    {description: "Tests whether a value is an element of a list or a key of a map. It is the operator `in`, written between the value and the list or map.", examples: []string{"1 in [1, 2, 3]", "'a' in {'a': 1}"}},
		"bool":    {examples: []string{"bool('true')"}},
		"bytes":   {examples: []string{"bytes('abc')"}},
		"double":  {examples: []string{"double(3)"}},
		"int":     {examples: []string{"int('42')", "int(3.7)"}},
		"uint":    {examples: []string{"uint(7)"}},
		"string":  {examples: []string{"string(42)"}},
		"dyn":     {examples: []string{"dyn(1) == 1.0"}},
		"type":    {examples: []string{"type(1) == int"}},
		"size":    {examples: []string{"size('abc')", "size([1, 2])", "size({'a': 1})"}},
		"matches": {examples: []string{"'abc123'.matches('^[a-z]+[0-9]+$')"}},

		"contains":   {examples: []string{"'kubernetes'.contains('netes')"}},
		"startsWith": {examples: []string{"'kubernetes'.startsWith('kube')"}},
		"endsWith":   {examples: []string{"'kubernetes'.endsWith('netes')"}},

		"duration":  {examples: []string{"duration('90s')"}},
		"timestamp": {examples: []string{"timestamp('2024-01-01T00:00:00Z')"}},
		"getDate":   {examples: []string{"timestamp('2024-03-15T00:00:00Z').getDate()"}},
		"getDayOfMonth": {examples: []string{
			"timestamp('2024-03-15T00:00:00Z').getDayOfMonth()",
		}},
		"getDayOfWeek": {examples: []string{"timestamp('2024-03-15T00:00:00Z').getDayOfWeek()"}},
		"getDayOfYear": {examples: []string{"timestamp('2024-03-15T00:00:00Z').getDayOfYear()"}},
		"getFullYear":  {examples: []string{"timestamp('2024-03-15T00:00:00Z').getFullYear()"}},
		"getHours":     {examples: []string{"timestamp('2024-03-15T10:30:00Z').getHours()", "duration('90m').getHours()"}},
		"getMilliseconds": {examples: []string{
			"timestamp('2024-03-15T10:30:00.250Z').getMilliseconds()",
		}},
		"getMinutes": {examples: []string{"timestamp('2024-03-15T10:30:00Z').getMinutes()", "duration('90m').getMinutes()"}},
		"getMonth":   {examples: []string{"timestamp('2024-03-15T00:00:00Z').getMonth()"}},
		"getSeconds": {examples: []string{"timestamp('2024-03-15T10:30:45Z').getSeconds()", "duration('90s').getSeconds()"}},

		"optional.none":           {examples: []string{"optional.none().hasValue()"}},
		"optional.of":             {examples: []string{"optional.of(1).value()"}},
		"optional.ofNonZeroValue": {examples: []string{"optional.ofNonZeroValue(0).hasValue()"}},
		"optional.unwrap":         {examples: []string{"optional.unwrap([optional.of(1), optional.none()])"}},
		"unwrapOpt":               {examples: []string{"[optional.of(1), optional.none()].unwrapOpt()"}},
		"hasValue":                {examples: []string{"optional.of(1).hasValue()"}},
		"value":                   {examples: []string{"optional.of(1).value()"}},
		"or":                      {examples: []string{"optional.none().or(optional.of(2))"}},
		"orValue":                 {examples: []string{"optional.none().orValue(2)"}},
		"first":                   {examples: []string{"[1, 2].first().value()"}},
		"last":                    {examples: []string{"[1, 2].last().value()"}},

		// Strings and regular expressions.
		"charAt": {
			description: "Returns the character of a string at a zero-based index, as a string of one character. The index may equal the length of the string, which returns the empty string; a larger or negative index is an error.",
			examples:    []string{"'hello'.charAt(1)"},
		},
		"find": {
			description: "Returns the first part of a string that matches an RE2 regular expression, or the empty string when nothing matches. Use matches() to only test for a match.",
			examples:    []string{"'abc123def'.find('[0-9]+')"},
		},
		"findAll": {
			description: "Returns every non-overlapping part of a string that matches an RE2 regular expression, in order. An optional second argument limits the number of matches; a negative limit means no limit, and 0 returns an empty list.",
			examples:    []string{"'a1b22c333'.findAll('[0-9]+')", "'a1b22c333'.findAll('[0-9]+', 2)"},
		},
		"format": {
			description: "Formats a string by replacing each %s, %d, %f, %e, %b, %o, %x, %X or %% in it with the matching element of a list of arguments, like printf. %s accepts any value; the others need numbers, and a mismatch is an error.",
			examples:    []string{"'%s has %d replicas'.format(['web', 3])"},
		},
		"indexOf": {
			description: "Returns the zero-based index of the first occurrence of a substring in a string, or of a value in a list, and -1 when it is absent. For a string, an optional second argument says where to start searching.",
			examples:    []string{"'hello hello'.indexOf('hello')", "'hello hello'.indexOf('hello', 1)", "[1, 2, 3].indexOf(2)"},
		},
		"lastIndexOf": {
			description: "Returns the zero-based index of the last occurrence of a substring in a string, or of a value in a list, and -1 when it is absent. For a string, an optional second argument is the index at which the search starts, going backwards.",
			examples:    []string{"'hello hello'.lastIndexOf('hello')", "[1, 2, 1].lastIndexOf(1)"},
		},
		"lowerAscii": {
			description: "Returns a string with its ASCII letters in lower case; characters outside ASCII stay as they are.",
			examples:    []string{"'Hello'.lowerAscii()"},
		},
		"upperAscii": {
			description: "Returns a string with its ASCII letters in upper case; characters outside ASCII stay as they are.",
			examples:    []string{"'Hello'.upperAscii()"},
		},
		"replace": {
			description: "Returns a string in which every occurrence of a substring is replaced by another string. An optional third argument limits the number of replacements; a negative limit means no limit.",
			examples:    []string{"'a-b-c'.replace('-', '_')", "'a-b-c'.replace('-', '_', 1)"},
		},
		"split": {
			description: "Splits a string around a separator and returns the parts as a list. An optional second argument limits the number of parts; the last part then holds the rest of the string.",
			examples:    []string{"'a,b,c'.split(',')", "'a,b,c'.split(',', 2)"},
		},
		"substring": {
			description: "Returns the part of a string from a zero-based start index, up to an optional end index that is not included. An index outside the string is an error.",
			examples:    []string{"'hello'.substring(1)", "'hello'.substring(1, 3)"},
		},
		"trim": {
			description: "Returns a string without the white space at its start and end.",
			examples:    []string{"'  hello  '.trim()"},
		},
		"join": {
			description: "Joins the strings of a list into one string, with an optional separator between them; without one they are joined directly.",
			examples:    []string{"['a', 'b', 'c'].join()", "['a', 'b', 'c'].join(', ')"},
		},
		"strings.quote": {
			description: "Returns a string quoted and escaped so that it reads as a CEL string literal, which is how to print a string that contains quotes, backslashes or control characters.",
			examples:    []string{"strings.quote('say \"hi\"')"},
		},

		// Lists and sets.
		"distinct": {
			description: "Returns a list without duplicates, keeping the first occurrence of each value in its place.",
			examples:    []string{"[1, 2, 1, 3].distinct()"},
		},
		"flatten": {
			description: "Flattens a list of lists by one level, or by as many levels as an optional argument says (0 changes nothing).",
			examples:    []string{"[[1, 2], [3]].flatten()", "[[1], [2]].flatten(1)"},
		},
		"reverse": {
			description: "Returns a list with its elements in the opposite order.",
			examples:    []string{"[1, 2, 3].reverse()"},
		},
		"slice": {
			description: "Returns the elements of a list from a start index up to an end index that is not included. The indexes are zero-based, and one outside the list is an error.",
			examples:    []string{"[1, 2, 3, 4].slice(1, 3)"},
		},
		"sort": {
			description: "Returns a list with its elements in ascending order. The elements must be of one comparable type: numbers, strings, bytes, booleans, durations or timestamps.",
			examples:    []string{"[3, 1, 2].sort()"},
		},
		"isSorted": {
			description: "Returns true when the elements of a list are in ascending order, which is also true for an empty list or one element. The elements must be of one comparable type: numbers, strings, bytes, booleans, durations or timestamps.",
			examples:    []string{"[1, 2, 3].isSorted()", "['b', 'a'].isSorted()"},
		},
		"sum": {
			description: "Returns the sum of the numbers or durations of a list, and zero for an empty list. An integer overflow is an error.",
			examples:    []string{"[1, 2, 3].sum()", "[duration('1m'), duration('30s')].sum()"},
		},
		"min": {
			description: "Returns the smallest element of a list of one comparable type: numbers, strings, bytes, booleans, durations or timestamps. An empty list is an error.",
			examples:    []string{"[3, 1, 2].min()"},
		},
		"max": {
			description: "Returns the largest element of a list of one comparable type: numbers, strings, bytes, booleans, durations or timestamps. An empty list is an error.",
			examples:    []string{"[3, 1, 2].max()"},
		},
		"includes": {
			description: "Returns true when a list contains a value, comparing with ==. It is an alias of the `in` operator that reads left to right.",
			examples:    []string{"[1, 2, 3].includes(2)"},
		},
		"lists.range": {
			description: "Returns the list of the integers from 0 up to, but not including, a number: lists.range(3) is [0, 1, 2]. A number below 1 gives an empty list.",
			examples:    []string{"lists.range(3)"},
		},
		"sets.contains": {
			description: "Returns true when the first list contains every element of the second, ignoring order and duplicates. The empty list is contained in every list.",
			examples:    []string{"sets.contains([1, 2, 3], [3, 1])"},
		},
		"sets.equivalent": {
			description: "Returns true when two lists hold the same elements, ignoring order and duplicates.",
			examples:    []string{"sets.equivalent([1, 2, 2], [2, 1])"},
		},
		"sets.intersects": {
			description: "Returns true when two lists share at least one element. A list that is empty never intersects.",
			examples:    []string{"sets.intersects([1, 2], [2, 3])"},
		},

		// Quantities.
		"quantity": {
			description: "Converts a string to a Quantity, the Kubernetes representation of resource amounts such as 500Mi, 2 or 100m, or fails when the string is not one. Quantities compare by value, so quantity('1Gi') is greater than quantity('1G'); the comparisons are the methods isLessThan, isGreaterThan and compareTo.",
			examples:    []string{"quantity('500Mi')", "quantity('100m').isLessThan(quantity('1'))"},
		},
		"isQuantity": {
			description: "Returns true when a string is a valid Quantity, which is when quantity() on it does not fail. Use it to guard quantity() on a value that may be malformed.",
			examples:    []string{"isQuantity('500Mi')", "isQuantity('abc')"},
		},
		"isInteger": {
			description: "Returns true when a Quantity can be written as an integer, so that asInteger() does not fail: 2Gi can, 100m cannot.",
			examples:    []string{"quantity('2Gi').isInteger()"},
		},
		"asInteger": {
			description: "Returns a Quantity as an int, failing when it is not a whole number or does not fit in 64 bits. Check isInteger() first when that is possible.",
			examples:    []string{"quantity('2Ki').asInteger()"},
		},
		"asApproximateFloat": {
			description: "Returns a Quantity as a double. The result may be rounded, so do not use it to compare quantities exactly; use compareTo, isLessThan or isGreaterThan.",
			examples:    []string{"quantity('100m').asApproximateFloat()"},
		},
		"add": {
			description: "Returns the sum of a Quantity and another Quantity or an int, as a Quantity.",
			examples:    []string{"quantity('1Gi').add(quantity('512Mi'))", "quantity('1').add(2)"},
		},
		"sub": {
			description: "Returns the difference of a Quantity and another Quantity or an int, as a Quantity.",
			examples:    []string{"quantity('1Gi').sub(quantity('512Mi'))", "quantity('3').sub(2)"},
		},
		"sign": {
			description: "Returns 1 for a positive Quantity, 0 for zero and -1 for a negative one.",
			examples:    []string{"sign(quantity('-1'))"},
		},
		"compareTo": {
			description: "Compares a Quantity or a Semver with another of the same type, and returns 0 when they are equal, 1 when the receiver is greater and -1 when it is less.",
			examples:    []string{"quantity('1Gi').compareTo(quantity('1G'))", "semver('1.2.3').compareTo(semver('2.0.0'))"},
		},
		"isGreaterThan": {
			description: "Returns true when a Quantity or a Semver is greater than another of the same type.",
			examples:    []string{"quantity('1Gi').isGreaterThan(quantity('1G'))", "semver('1.2.3').isGreaterThan(semver('1.2.0'))"},
		},
		"isLessThan": {
			description: "Returns true when a Quantity or a Semver is less than another of the same type.",
			examples:    []string{"quantity('100m').isLessThan(quantity('1'))", "semver('1.2.3').isLessThan(semver('2.0.0'))"},
		},

		// Semantic versions.
		"semver": {
			description: "Converts a string to a Semver, a semantic version as semver.org defines it, or fails when the string is not one. With a second argument true the string is normalized first: a leading v is removed, missing minor and patch numbers become 0 and leading zeros are dropped.",
			examples:    []string{"semver('1.2.3')", "semver('v1.2', true)"},
		},
		"isSemver": {
			description: "Returns true when a string is a valid semantic version, which is when semver() on it does not fail. With a second argument true the string is normalized first, as semver() does.",
			examples:    []string{"isSemver('1.2.3')", "isSemver('v1.2', true)"},
		},
		"major": {
			description: "Returns the major number of a Semver as an int.",
			examples:    []string{"semver('1.2.3').major()"},
		},
		"minor": {
			description: "Returns the minor number of a Semver as an int.",
			examples:    []string{"semver('1.2.3').minor()"},
		},
		"patch": {
			description: "Returns the patch number of a Semver as an int.",
			examples:    []string{"semver('1.2.3').patch()"},
		},

		// URLs.
		"url": {
			description: "Parses a string as an absolute URL and returns a URL value, or fails when it is not one. Read its parts with getScheme, getHost, getHostname, getPort, getEscapedPath and getQuery.",
			examples:    []string{"url('https://example.com:8443/a/b?x=1&x=2').getHost()"},
		},
		"isURL": {
			description: "Returns true when a string is an absolute URL, which is when url() on it does not fail. Use it to guard url() on a value that may be malformed.",
			examples:    []string{"isURL('https://example.com/path')"},
		},
		"getScheme": {
			description: "Returns the scheme of a URL, such as https, or the empty string when it has none.",
			examples:    []string{"url('https://example.com/a').getScheme()"},
		},
		"getHost": {
			description: "Returns the host of a URL with its port when it has one, like example.com:8443. An IPv6 address keeps its brackets.",
			examples:    []string{"url('https://example.com:8443/a').getHost()"},
		},
		"getHostname": {
			description: "Returns the host of a URL without its port. An IPv6 address comes without brackets.",
			examples:    []string{"url('https://example.com:8443/a').getHostname()"},
		},
		"getPort": {
			description: "Returns the port of a URL as a string, or the empty string when the URL names none; the default port of the scheme is not filled in.",
			examples:    []string{"url('https://example.com:8443/a').getPort()"},
		},
		"getEscapedPath": {
			description: "Returns the path of a URL in its escaped form, as it is sent over the wire, or the empty string when it has none.",
			examples:    []string{"url('https://example.com/a%20b/c').getEscapedPath()"},
		},
		"getQuery": {
			description: "Returns the query of a URL as a map from each parameter name to the list of its values, in order. The map is empty when the URL has no query.",
			examples:    []string{"url('https://example.com/?x=1&x=2&y=3').getQuery()['x']"},
		},

		// IP addresses and CIDR ranges.
		"ip": {
			description: "Converts a string to an IP address, IPv4 or IPv6, or fails when it is not one; an address with a zone, like fe80::1%eth0, is refused. Called on a CIDR, it returns the address that is part of it, which is not necessarily the first of its range.",
			examples:    []string{"ip('192.168.0.1')", "cidr('192.168.0.1/24').ip()"},
		},
		"isIP": {
			description: "Returns true when a string is an IP address, IPv4 or IPv6, which is when ip() on it does not fail. Use it to guard ip() on a value that may be malformed.",
			examples:    []string{"isIP('192.168.0.1')", "isIP('2001:db8::1')"},
		},
		"ip.isCanonical": {
			description: "Returns true when a string is an IP address in its canonical text form: no leading zeros in IPv4, and IPv6 in the shortest lower-case form, so 2001:db8::1 is canonical and 2001:DB8:0::1 is not. The string must be a valid address, or the call fails.",
			examples:    []string{"ip.isCanonical('2001:db8::1')", "ip.isCanonical('2001:DB8:0::1')"},
		},
		"family": {
			description: "Returns the family of an IP address: 4 for IPv4 and 6 for IPv6.",
			examples:    []string{"ip('192.168.0.1').family()"},
		},
		"isUnspecified": {
			description: "Returns true when an IP address is the unspecified address, 0.0.0.0 or ::.",
			examples:    []string{"ip('0.0.0.0').isUnspecified()"},
		},
		"isLoopback": {
			description: "Returns true when an IP address is a loopback address: 127.0.0.0/8 for IPv4 and ::1 for IPv6.",
			examples:    []string{"ip('127.0.0.1').isLoopback()"},
		},
		"isLinkLocalMulticast": {
			description: "Returns true when an IP address is a link-local multicast address: 224.0.0.0/24 for IPv4 and ff02::/16 for IPv6.",
			examples:    []string{"ip('224.0.0.1').isLinkLocalMulticast()"},
		},
		"isLinkLocalUnicast": {
			description: "Returns true when an IP address is a link-local unicast address: 169.254.0.0/16 for IPv4 and fe80::/10 for IPv6.",
			examples:    []string{"ip('169.254.169.254').isLinkLocalUnicast()"},
		},
		"isGlobalUnicast": {
			description: "Returns true when an IP address is a global unicast address: not unspecified, loopback, multicast or link-local, and for IPv4 not the broadcast address. Private addresses, like 10.0.0.1, count as global here.",
			examples:    []string{"ip('8.8.8.8').isGlobalUnicast()"},
		},
		"cidr": {
			description: "Converts a string like 10.0.0.0/8 or 2001:db8::/32 to a CIDR, an IP address with a prefix length, or fails when it is not one. The address needs not be the first of its range; masked() returns the range itself.",
			examples:    []string{"cidr('10.0.0.0/8')"},
		},
		"isCIDR": {
			description: "Returns true when a string is a CIDR, IPv4 or IPv6, which is when cidr() on it does not fail. Use it to guard cidr() on a value that may be malformed.",
			examples:    []string{"isCIDR('10.0.0.0/8')"},
		},
		"containsIP": {
			description: "Returns true when an IP address lies in a CIDR range. The address is an IP or a string; a string that is not an address is an error. An IPv4 address is never in an IPv6 range.",
			examples:    []string{"cidr('10.0.0.0/8').containsIP('10.1.2.3')", "cidr('10.0.0.0/8').containsIP(ip('192.168.0.1'))"},
		},
		"containsCIDR": {
			description: "Returns true when a CIDR range lies entirely within another, which includes being equal to it. The argument is a CIDR or a string; a string that is not a CIDR is an error.",
			examples:    []string{"cidr('10.0.0.0/8').containsCIDR('10.1.0.0/16')", "cidr('10.0.0.0/8').containsCIDR(cidr('10.0.0.0/8'))"},
		},
		"masked": {
			description: "Returns a CIDR with the bits of its address after the prefix set to zero, which is the first address of its range: 192.168.0.1/24 becomes 192.168.0.0/24.",
			examples:    []string{"cidr('192.168.0.1/24').masked()"},
		},
		"prefixLength": {
			description: "Returns the prefix length of a CIDR, the number after the slash, as an int.",
			examples:    []string{"cidr('192.168.0.0/24').prefixLength()"},
		},

		// Named formats.
		"format.named": {
			description: "Returns the Format of the given name as an optional, or optional.none() when the name is unknown. The names are dns1123Label, dns1123Subdomain, dns1035Label, qualifiedName, dns1123LabelPrefix, dns1123SubdomainPrefix, dns1035LabelPrefix, labelValue, uri, uuid, byte, date and datetime.",
			examples:    []string{"format.named('dns1123Label').value().validate('my-name')"},
		},
		"validate": {
			description: "Checks a string against a Format. It returns optional.none() when the string is valid, and otherwise an optional with the list of what is wrong, ready to join into a message.",
			examples:    []string{"format.dns1123Label().validate(object.metadata.name).hasValue()", "format.uuid().validate('123e4567-e89b-12d3-a456-426614174000').orValue([]).join('; ')"},
		},
		"format.byte": {
			description: "Returns the Format of base64-encoded strings, for validate().",
			examples:    []string{"format.byte().validate('aGVsbG8=')"},
		},
		"format.date": {
			description: "Returns the Format of dates written YYYY-MM-DD, for validate().",
			examples:    []string{"format.date().validate('2021-01-01')"},
		},
		"format.datetime": {
			description: "Returns the Format of RFC 3339 date-times, for validate().",
			examples:    []string{"format.datetime().validate('2021-01-01T00:00:00Z')"},
		},
		"format.dns1035Label": {
			description: "Returns the Format of DNS-1035 labels, for validate(): lower-case letters, digits and '-', starting with a letter, ending with a letter or digit, at most 63 characters.",
			examples:    []string{"format.dns1035Label().validate('my-label-name')"},
		},
		"format.dns1035LabelPrefix": {
			description: "Returns the Format of the prefix of a DNS-1035 label, for validate(): as a label, but it may end with '-'. Use it for generateName.",
			examples:    []string{"format.dns1035LabelPrefix().validate('my-label-prefix-')"},
		},
		"format.dns1123Label": {
			description: "Returns the Format of DNS-1123 labels, for validate(): lower-case letters, digits and '-', starting and ending with a letter or digit, at most 63 characters.",
			examples:    []string{"format.dns1123Label().validate('my-label-name')"},
		},
		"format.dns1123LabelPrefix": {
			description: "Returns the Format of the prefix of a DNS-1123 label, for validate(): as a label, but it may end with '-'. Use it for generateName.",
			examples:    []string{"format.dns1123LabelPrefix().validate('my-label-prefix-')"},
		},
		"format.dns1123Subdomain": {
			description: "Returns the Format of DNS-1123 subdomains, for validate(): DNS-1123 labels joined with '.', at most 253 characters. It is the format of most object names.",
			examples:    []string{"format.dns1123Subdomain().validate('apiextensions.k8s.io')"},
		},
		"format.dns1123SubdomainPrefix": {
			description: "Returns the Format of the prefix of a DNS-1123 subdomain, for validate(): as a subdomain, but it may end with '-' or '.'. Use it for generateName.",
			examples:    []string{"format.dns1123SubdomainPrefix().validate('mysubdomain.prefix.')"},
		},
		"format.labelValue": {
			description: "Returns the Format of label values, for validate(): empty, or at most 63 characters of letters, digits, '-', '_' and '.', starting and ending with a letter or digit.",
			examples:    []string{"format.labelValue().validate('my-value')"},
		},
		"format.qualifiedName": {
			description: "Returns the Format of qualified names, for validate(): a name of at most 63 characters, optionally preceded by a DNS subdomain and '/', as in label and annotation keys.",
			examples:    []string{"format.qualifiedName().validate('apiextensions.k8s.io/v1beta1')"},
		},
		"format.uri": {
			description: "Returns the Format of URIs, for validate(). It uses the same check as isURL() but returns the error.",
			examples:    []string{"format.uri().validate('http://example.com')"},
		},
		"format.uuid": {
			description: "Returns the Format of UUIDs, for validate(): 36 characters of hexadecimal digits in groups of 8-4-4-4-12.",
			examples:    []string{"format.uuid().validate('123e4567-e89b-12d3-a456-426614174000')"},
		},

		// Authorization.
		"path": {
			description: "Returns a PathCheck for a non-resource request path such as /healthz, to authorize with check(). The leading '/' is optional and an empty path is an error. Only expressions that have the authorizer variable can use it.",
			examples:    []string{"authorizer.path('/healthz').check('get').allowed()"},
		},
		"group": {
			description: "Returns a GroupCheck for the resources of an API group, to continue with resource(). The core group is the empty string.",
			examples:    []string{"authorizer.group('apps').resource('deployments').check('create').allowed()"},
		},
		"serviceAccount": {
			description: "Returns an Authorizer that checks as the given service account, namespace first, instead of as the user of the request. The namespace must be a DNS label and the name a DNS subdomain, or the call fails.",
			examples:    []string{"authorizer.serviceAccount('kube-system', 'default').group('').resource('pods').check('get').allowed()"},
		},
		"resource": {
			description: "Returns a ResourceCheck for a resource of an API group, to refine with subresource(), namespace(), name() and the selectors, and to run with check(). It takes the lower-case plural name, like deployments.",
			examples:    []string{"authorizer.group('').resource('pods').check('get').allowed()"},
		},
		"subresource": {
			description: "Returns a ResourceCheck for a subresource of the resource, like status or scale. The empty string unsets it.",
			examples:    []string{"authorizer.group('apps').resource('deployments').subresource('scale').check('update').allowed()"},
		},
		"namespace": {
			description: "Returns a ResourceCheck for the resource in a namespace. Leave it out, or pass the empty string, for the cluster scope, which is right for cluster-scoped resources.",
			examples:    []string{"authorizer.group('').resource('pods').namespace('default').check('list').allowed()"},
		},
		"name": {
			description: "Returns a ResourceCheck for the object of the given name. The empty string unsets it.",
			examples:    []string{"authorizer.group('').resource('secrets').namespace('default').name('tls').check('get').allowed()"},
		},
		"fieldSelector": {
			description: "Returns a ResourceCheck that includes a field selector, given as a string, in the authorization check. A selector that does not parse adds no requirement.",
			examples:    []string{"authorizer.group('').resource('pods').fieldSelector('spec.nodeName=node1').check('list').allowed()"},
		},
		"labelSelector": {
			description: "Returns a ResourceCheck that includes a label selector, given as a string, in the authorization check. A selector that does not parse adds no requirement.",
			examples:    []string{"authorizer.group('').resource('pods').labelSelector('app=web').check('list').allowed()"},
		},
		"check": {
			description: "Asks the authorizer whether the user of the request may do a verb, such as get, list, create, update, patch, delete or watch, on the path or resource of a PathCheck or ResourceCheck. It returns a Decision to read with allowed(), errored(), error() and reason(). A check can be slow when the cluster authorizes through webhooks.",
			examples:    []string{"authorizer.path('/healthz').check('get').allowed()", "authorizer.group('').resource('pods').check('delete').allowed()"},
		},
		"allowed": {
			description: "Returns true when the authorizer's Decision is to allow. It is false for a decision of no opinion, and for an error.",
			examples:    []string{"authorizer.group('').resource('pods').check('get').allowed()"},
		},
		"reason": {
			description: "Returns the reason the authorizer gave for its Decision, as a string; it can be empty.",
			examples:    []string{"authorizer.group('').resource('pods').check('get').reason()"},
		},
		"errored": {
			description: "Returns true when the authorization check ended in an error, as opposed to a decision.",
			examples:    []string{"authorizer.group('').resource('pods').check('get').errored()"},
		},
		"error": {
			description: "Returns the error of an authorization check that errored, as a string, and the empty string otherwise.",
			examples:    []string{"authorizer.group('').resource('pods').check('get').error()"},
		},
	}
})

// functionDocumentation returns the description of f followed by its examples,
// as plain text that reads as Markdown too; empty when nothing documents f.
func functionDocumentation(f *decls.FunctionDecl) string {
	doc := functionDocs()[f.Name()]
	desc := doc.description
	if desc == "" {
		desc = f.Description()
	}
	return withExamples(desc, doc.examples)
}

// withExamples appends examples to a description as a Markdown list; without
// examples it returns the description.
func withExamples(desc string, examples []string) string {
	var b strings.Builder
	b.WriteString(desc)
	for i, e := range examples {
		if i == 0 {
			b.WriteString("\n\nExamples:")
		}
		b.WriteString("\n- `" + e + "`")
	}
	return b.String()
}
