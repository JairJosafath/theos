package analysis

import (
	"strings"
	"testing"

	"github.com/google/cel-go/cel"
	"k8s.io/apiserver/pkg/cel/environment"
)

// docEnv returns the environment of admission expressions.
func docEnv(t *testing.T) *cel.Env {
	t.Helper()
	es, err := scope{}.envSet()
	if err != nil {
		t.Fatalf("envSet() = %v", err)
	}
	env, err := es.Env(environment.StoredExpressions)
	if err != nil {
		t.Fatalf("Env() = %v", err)
	}
	return env
}

// internal reports whether a function is one the checker and the libraries
// declare for their own use, which no author writes.
func internal(name string) bool {
	return strings.Contains(name, "@") || strings.HasPrefix(name, "__")
}

func TestFunctionsDocumented(t *testing.T) {
	t.Parallel()
	env := docEnv(t)
	for name, f := range env.Functions() {
		if internal(name) {
			continue
		}
		doc := functionDocumentation(f)
		if strings.TrimSpace(f.Description()) == "" && functionDocs()[name].description == "" {
			t.Errorf("function %s has no description; add it to functionDocs", name)
		}
		if len(functionDocs()[name].examples) == 0 {
			t.Errorf("function %s has no example; add it to functionDocs", name)
		}
		if !strings.Contains(doc, "Examples:") {
			t.Errorf("functionDocumentation(%s) = %q, want it to list examples", name, doc)
		}
	}
	for name := range functionDocs() {
		if _, ok := env.Functions()[name]; !ok {
			t.Errorf("functionDocs documents %s, which the environment does not have", name)
		}
	}
}

func TestFunctionExamplesCompile(t *testing.T) {
	t.Parallel()
	env := docEnv(t)
	for name, doc := range functionDocs() {
		for _, e := range doc.examples {
			t.Run(name+"/"+e, func(t *testing.T) {
				t.Parallel()
				if _, iss := env.Compile(e); iss.Err() != nil {
					t.Errorf("Compile(%q) = %v, want no error", e, iss.Err())
				}
			})
		}
	}
}

func TestExplainKubernetesFunction(t *testing.T) {
	t.Parallel()
	h := explain(policy("quan|tity('1Gi').isInteger()"))
	if h == nil {
		t.Fatal("Explain(quantity) = nil, want its documentation")
	}
	for _, want := range []string{"Quantity", "Examples:", "`quantity('500Mi')`"} {
		if !strings.Contains(h.Documentation, want) {
			t.Errorf("Explain(quantity).Documentation = %q, want it to contain %q", h.Documentation, want)
		}
	}
}

func TestCompleteKubernetesFunction(t *testing.T) {
	t.Parallel()
	items := complete(t, policy("is|"))
	it, ok := find(items, "isQuantity")
	if !ok {
		t.Fatalf("Complete(is) = %v, want isQuantity among them", labels(items))
	}
	if !strings.Contains(it.Documentation, "`isQuantity('500Mi')`") {
		t.Errorf("Complete(is) isQuantity.Documentation = %q, want its example", it.Documentation)
	}
}
