package analysis

import (
	"context"
	"fmt"
	"regexp"
	"strconv"
	"strings"

	"k8s.io/apiextensions-apiserver/pkg/apis/apiextensions"
	apiextensionsv1 "k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/v1"
	"k8s.io/apiextensions-apiserver/pkg/apis/apiextensions/validation"
	structuralschema "k8s.io/apiextensions-apiserver/pkg/apiserver/schema"
	"k8s.io/apimachinery/pkg/util/validation/field"

	"c4factory.local/cel-lens/cel-language-server/internal/locate"
)

// celIssue is one error of a CEL compiler in the text API servers print:
// "ERROR: <input>:line:column: message", with a 1-based column, after a
// prefix such as "compilation failed: ".
var celIssue = regexp.MustCompile(`(?m)ERROR: <input>:(\d+):(\d+): (.*)$`)

// crd checks the x-kubernetes-validations of a CustomResourceDefinition by
// running the API server's own validation on it and keeping the findings about
// rules, so each version is compiled against its own schema.
func (c *checker) crd(doc locate.Document) []Diagnostic {
	var v1 apiextensionsv1.CustomResourceDefinition
	if err := decode(doc, &v1); err != nil {
		return c.docError(doc.Kind, err)
	}
	if len(doc.Expressions) == 0 {
		return nil
	}
	apiextensionsv1.SetObjectDefaults_CustomResourceDefinition(&v1)
	var crd apiextensions.CustomResourceDefinition
	if err := apiextensionsv1.Convert_v1_CustomResourceDefinition_To_apiextensions_CustomResourceDefinition(&v1, &crd, nil); err != nil {
		return c.docError(doc.Kind, err)
	}
	sites := map[string]site{}
	all := c.sites(doc)
	for _, s := range all {
		sites[s.Path] = s
	}
	c.structuralHints(&crd, all)
	for _, e := range validation.ValidateCustomResourceDefinition(context.Background(), &crd) {
		if !aboutRules(e) {
			continue
		}
		path := filePath(e.Field)
		for _, p := range versionPaths(path, &v1) {
			if s, ok := sites[p]; ok {
				c.ruleError(s, e.Detail)
			} else if n := nodeAt(c.body, p); n != nil {
				c.out = append(c.out, lineDiagnostic(c.idx, n.Line, n.Column, e.Detail))
			}
		}
	}
	return c.out
}

// structuralHints adds one hint for each version whose schema is not
// structural and has rules: the API server compiles rules only for a
// structural schema, so it reports nothing for them. The hint is on the first
// rule of the version.
func (c *checker) structuralHints(crd *apiextensions.CustomResourceDefinition, sites []site) {
	for i, v := range crd.Spec.Versions {
		sch, err := apiextensions.GetSchemaForVersion(crd, v.Name)
		if err != nil || sch == nil || sch.OpenAPIV3Schema == nil || structural(sch.OpenAPIV3Schema) {
			continue
		}
		prefix := fmt.Sprintf("spec.versions[%d].schema.", i)
		for _, s := range sites {
			if strings.HasPrefix(s.Path, prefix) {
				c.add(s, 0, len(s.Text), nonStructuralHint)
				c.out[len(c.out)-1].Severity = Hint
				break
			}
		}
	}
}

// nonStructuralHint is the message of the hint on rules of a schema that is
// not structural.
const nonStructuralHint = "x-kubernetes-validations are not checked: they need a structural schema, and this one is not (every property needs a type)"

// structural reports whether the API server accepts s as a structural schema.
func structural(s *apiextensions.JSONSchemaProps) bool {
	st, err := structuralschema.NewStructural(s)
	return err == nil && len(structuralschema.ValidateStructural(nil, st)) == 0
}

// versionPaths returns the paths in the file that a field path of the
// validated CRD stands for. Defaulting moves a schema that all versions share
// to spec.validation, so there the error belongs to each version's schema.
func versionPaths(path string, crd *apiextensionsv1.CustomResourceDefinition) []string {
	const prefix = "spec.validation."
	rest, ok := strings.CutPrefix(path, prefix)
	if !ok {
		return []string{path}
	}
	var paths []string
	for i, v := range crd.Spec.Versions {
		if v.Schema != nil {
			paths = append(paths, fmt.Sprintf("spec.versions[%d].schema.%s", i, rest))
		}
	}
	return paths
}

// aboutRules reports whether e is about a rule or messageExpression, or is the
// cost total of a schema's rules.
func aboutRules(e *field.Error) bool {
	switch {
	case strings.Contains(e.Field, ".x-kubernetes-validations["):
		return strings.HasSuffix(e.Field, ".rule") || strings.HasSuffix(e.Field, ".messageExpression") ||
			strings.HasSuffix(e.Field, ".optionalOldSelf")
	case strings.HasSuffix(e.Field, ".openAPIV3Schema"):
		return strings.Contains(e.Detail, "x-kubernetes-validations estimated rule cost total")
	}
	return false
}

// ruleError reports the detail the API server gives for an expression: at each
// token that CEL names, or else on the whole expression.
func (c *checker) ruleError(s site, detail string) {
	issues := celIssue.FindAllStringSubmatch(detail, -1)
	if len(issues) == 0 {
		trimmed := strings.TrimSpace(s.Text)
		start := strings.Index(s.Text, trimmed)
		c.add(s, start, start+len(trimmed), detail)
		return
	}
	for _, m := range issues {
		line, _ := strconv.Atoi(m[1])
		col, _ := strconv.Atoi(m[2])
		start, end := tokenAt(s.Text, byteOffset(s.Text, line, col-1))
		c.add(s, start, end, m[3])
	}
}

// mapFields are the schema fields whose bracketed subscripts in a field path
// are map keys rather than list indexes.
var mapFields = map[string]bool{"properties": true, "patternProperties": true, "definitions": true, "dependencies": true}

// filePath turns a field path of the validated CRD, which prints keys and
// indexes alike in brackets and does not escape them, into a path that
// [locate.Steps] splits. A key ends at the first ']' that is followed by '.',
// '[' or the end of the path.
func filePath(fp string) string {
	var path, name string
	for i := 0; i < len(fp); {
		switch fp[i] {
		case '.':
			i++
		case '[':
			end := keyEnd(fp, i+1, mapFields[name])
			sub := fp[i+1 : end]
			if n, err := strconv.Atoi(sub); err == nil && !mapFields[name] {
				path = locate.Item(path, n)
			} else {
				path = locate.Key(path, sub)
			}
			i = end + 1
		default:
			end := strings.IndexAny(fp[i:], ".[")
			if end < 0 {
				end = len(fp) - i
			}
			name = fp[i : i+end]
			path = locate.Key(path, name)
			i += end
		}
	}
	return path
}

// keyEnd returns the index of the ']' that closes the subscript starting at
// from. A map key may hold brackets itself, so it closes at the first ']' that
// ends the path or precedes '.' or '['.
func keyEnd(fp string, from int, isKey bool) int {
	end := from
	for {
		j := strings.IndexByte(fp[end:], ']')
		if j < 0 {
			return len(fp)
		}
		end += j
		if !isKey || end+1 == len(fp) || fp[end+1] == '.' || fp[end+1] == '[' {
			return end
		}
		end++
	}
}
