package position

import (
	"errors"
	"fmt"
	"math"
	"strconv"
	"strings"
	"unicode/utf8"

	"go.yaml.in/yaml/v3"
)

// Scalar maps the decoded value of scalar node n to byte offsets in the file.
// The result has len(n.Value)+1 elements: element i is the offset of value byte
// i, and the last is the offset where the value's text ends (before a closing
// quote, after the last character of a plain or block scalar), which is where
// an error at the end of the expression belongs.
//
// A byte that YAML wrote as an escape (`\n`, `\"`, `é`, `”`) maps to the
// escape's first byte. A line break that YAML folded into a space or kept as a
// newline maps to the break in the file. Every other byte maps to itself.
//
// The cost is linear in the scalar's source lines. It returns an error, and no
// offsets, when n is not a scalar of this file.
func (x *Index) Scalar(n *yaml.Node) ([]int, error) {
	if n.Kind != yaml.ScalarNode {
		return nil, fmt.Errorf("map scalar at %d:%d: not a scalar node", n.Line, n.Column)
	}
	start, err := x.nodeStart(n)
	if err != nil {
		return nil, err
	}
	d := decoder{src: x.src, value: n.Value, offs: make([]int, 0, len(n.Value)+1)}
	switch {
	case n.Style&yaml.DoubleQuotedStyle != 0:
		err = d.double(start)
	case n.Style&yaml.SingleQuotedStyle != 0:
		err = d.single(start)
	case n.Style&yaml.LiteralStyle != 0:
		err = d.block(start, false)
	case n.Style&yaml.FoldedStyle != 0:
		err = d.block(start, true)
	default:
		err = d.plain(start)
	}
	if err == nil && len(d.offs) != len(n.Value)+1 {
		err = fmt.Errorf("source decodes to %d bytes, value has %d", len(d.offs)-1, len(n.Value))
	}
	if err != nil {
		return nil, fmt.Errorf("map scalar at %d:%d: %w", n.Line, n.Column, err)
	}
	return d.offs, nil
}

// nodeStart returns the offset of the scalar's first character: yaml.Node
// positions a scalar at its tag or anchor when it has one.
func (x *Index) nodeStart(n *yaml.Node) (int, error) {
	if n.Line < 1 || n.Line > len(x.starts) || n.Column < 1 {
		return 0, fmt.Errorf("map scalar at %d:%d: %w", n.Line, n.Column, ErrOutOfRange)
	}
	pos, end := x.starts[n.Line-1], x.lineEnd(n.Line-1)
	for col := 1; col < n.Column; col++ {
		if pos >= end {
			return 0, fmt.Errorf("map scalar at %d:%d: %w", n.Line, n.Column, ErrOutOfRange)
		}
		_, w := utf8.DecodeRune(x.src[pos:end])
		pos += w
	}
	for pos < len(x.src) && (x.src[pos] == '!' || x.src[pos] == '&') {
		for pos < len(x.src) && !isSpace(x.src[pos]) {
			pos++
		}
		for pos < len(x.src) && isSpace(x.src[pos]) {
			pos++
		}
	}
	return pos, nil
}

func isBreak(c byte) bool { return c == '\n' || c == '\r' }

func isSpace(c byte) bool { return c == ' ' || c == '\t' || isBreak(c) }

// decoder rebuilds a scalar's value from its source, recording where each byte
// came from.
type decoder struct {
	src   []byte
	value string
	offs  []int
	// keep is len(offs) after the last byte that line folding must not trim:
	// anything but a space or tab written literally.
	keep int
}

// literal records a byte that is written as itself at off.
func (d *decoder) literal(off int) {
	d.offs = append(d.offs, off)
	if c := d.src[off]; c != ' ' && c != '\t' {
		d.keep = len(d.offs)
	}
}

// emit records n decoded bytes that came from the text at off.
func (d *decoder) emit(off, n int) {
	for range n {
		d.offs = append(d.offs, off)
	}
	d.keep = len(d.offs)
}

// skipBreak returns the offset after the line break at pos.
func (d *decoder) skipBreak(pos int) int {
	if d.src[pos] == '\r' && pos+1 < len(d.src) && d.src[pos+1] == '\n' {
		return pos + 2
	}
	return pos + 1
}

func (d *decoder) skipBlanks(pos int) int {
	for pos < len(d.src) && (d.src[pos] == ' ' || d.src[pos] == '\t') {
		pos++
	}
	return pos
}

// fold decodes the line break at pos inside a flow scalar: it drops the
// whitespace before the break, turns the break into a space, or each empty line
// after it into a newline, and skips the next line's indentation. It returns
// the offset of the next character.
func (d *decoder) fold(pos int) int {
	d.offs = d.offs[:d.keep]
	first := pos
	empty := false
	for pos < len(d.src) {
		pos = d.skipBlanks(d.skipBreak(pos))
		if pos >= len(d.src) || !isBreak(d.src[pos]) {
			break
		}
		d.emit(pos, 1)
		empty = true
	}
	if !empty {
		d.emit(first, 1)
	}
	return pos
}

func (d *decoder) plain(pos int) error {
	// A plain value has no trailing whitespace, so it is complete once the
	// last byte that folding keeps is in.
	for d.keep < len(d.value) {
		if pos >= len(d.src) {
			return fmt.Errorf("source ends after %d of %d bytes", len(d.offs), len(d.value))
		}
		if isBreak(d.src[pos]) {
			pos = d.fold(pos)
			continue
		}
		d.literal(pos)
		pos++
	}
	d.offs = append(d.offs, pos)
	return nil
}

func (d *decoder) single(pos int) error {
	for pos++; pos < len(d.src); {
		switch c := d.src[pos]; {
		case c == '\'' && pos+1 < len(d.src) && d.src[pos+1] == '\'':
			d.emit(pos, 1)
			pos += 2
		case c == '\'':
			d.offs = append(d.offs, pos)
			return nil
		case isBreak(c):
			pos = d.fold(pos)
		default:
			d.literal(pos)
			pos++
		}
	}
	return errors.New("single-quoted scalar is not closed")
}

func (d *decoder) double(pos int) error {
	for pos++; pos < len(d.src); {
		switch c := d.src[pos]; {
		case c == '"':
			d.offs = append(d.offs, pos)
			return nil
		case isBreak(c):
			pos = d.fold(pos)
		case c == '\\':
			next, err := d.escape(pos)
			if err != nil {
				return err
			}
			pos = next
		default:
			d.literal(pos)
			pos++
		}
	}
	return errors.New("double-quoted scalar is not closed")
}

var simpleEscapes = map[byte]rune{
	'0': 0, 'a': 7, 'b': 8, 't': '\t', '\t': '\t', 'n': '\n', 'v': 11, 'f': 12, 'r': '\r',
	'e': 27, ' ': ' ', '"': '"', '/': '/', '\\': '\\', 'N': 0x85, '_': 0xA0, 'L': 0x2028, 'P': 0x2029,
}

// escape decodes the backslash sequence at pos and returns the offset after it.
func (d *decoder) escape(pos int) (int, error) {
	if pos+1 >= len(d.src) {
		return 0, fmt.Errorf("escape at offset %d is cut off", pos)
	}
	c := d.src[pos+1]
	if isBreak(c) {
		// An escaped break joins the lines; whitespace before it stays.
		d.keep = len(d.offs)
		next := d.skipBlanks(d.skipBreak(pos + 1))
		for next < len(d.src) && isBreak(d.src[next]) {
			d.emit(next, 1)
			next = d.skipBlanks(d.skipBreak(next))
		}
		return next, nil
	}
	r, ok := simpleEscapes[c]
	size := 2
	if !ok {
		digits := map[byte]int{'x': 2, 'u': 4, 'U': 8}[c]
		if digits == 0 || pos+2+digits > len(d.src) {
			return 0, fmt.Errorf("unknown escape at offset %d", pos)
		}
		code, err := strconv.ParseUint(string(d.src[pos+2:pos+2+digits]), 16, 32)
		if err != nil || code > math.MaxInt32 {
			return 0, fmt.Errorf("bad escape at offset %d", pos)
		}
		r, size = rune(code), 2+digits
	}
	d.emit(pos, utf8.RuneLen(r))
	return pos + size, nil
}

// line is one source line of a block scalar: its text spans [start, end) and
// brk is the offset of its line break, or -1 at the end of the file.
type line struct {
	start, end, brk int
}

func (l line) blank(src []byte) bool {
	for _, c := range src[l.start:l.end] {
		if c != ' ' {
			return false
		}
	}
	return true
}

func (l line) indent(src []byte) int {
	n := 0
	for n < l.end-l.start && src[l.start+n] == ' ' {
		n++
	}
	return n
}

// block decodes a literal or folded scalar whose header starts at pos.
func (d *decoder) block(pos int, folded bool) error {
	for pos < len(d.src) && !isBreak(d.src[pos]) {
		pos++
	}
	headerEnd := pos
	if pos < len(d.src) {
		pos = d.skipBreak(pos)
	}
	indent, err := d.blockIndent(pos)
	if err != nil {
		return err
	}
	lines := d.blockLines(pos, indent)

	text := len(d.value)
	for text > 0 && d.value[text-1] == '\n' {
		text--
	}
	trailing := len(d.value) - text

	var content []int // indexes of lines that hold text
	for i, l := range lines {
		if l.end-l.start > indent {
			content = append(content, i)
		}
	}
	if len(content) == 0 {
		if text > 0 || trailing > len(lines) {
			return fmt.Errorf("block scalar has no text, value has %d bytes", len(d.value))
		}
		end := headerEnd
		for _, l := range lines[:trailing] {
			d.emit(l.brk, 1)
			end = l.end
		}
		d.offs = append(d.offs, end)
		return nil
	}
	for _, l := range lines[:content[0]] {
		d.emit(l.brk, 1)
	}
	for k, i := range content {
		l := lines[i]
		for p := l.start + indent; p < l.end; p++ {
			d.offs = append(d.offs, p)
		}
		if k+1 < len(content) {
			j := content[k+1]
			d.blockSeparator(lines, i, j, indent, folded)
		}
	}
	last := content[len(content)-1]
	if trailing > len(lines)-last || (trailing > 0 && lines[last].brk < 0) {
		return fmt.Errorf("block scalar ends with %d line breaks, source has fewer", trailing)
	}
	for _, l := range lines[last : last+trailing] {
		d.emit(l.brk, 1)
	}
	d.offs = append(d.offs, lines[last+max(trailing-1, 0)].end)
	return nil
}

// blockSeparator records the newlines between content lines i and j.
func (d *decoder) blockSeparator(lines []line, i, j, indent int, folded bool) {
	if folded && d.text(lines[i], indent) && d.text(lines[j], indent) {
		if j == i+1 {
			d.emit(lines[i].brk, 1) // the break folds into a space
			return
		}
		i++ // the first break folds away; each empty line stays
	}
	for _, l := range lines[i:j] {
		d.emit(l.brk, 1)
	}
}

// text reports whether content line l starts with text, not whitespace, which
// is what lets a folded scalar fold it.
func (d *decoder) text(l line, indent int) bool {
	c := d.src[l.start+indent]
	return c != ' ' && c != '\t'
}

// blockIndent returns the indentation of the block scalar whose content starts
// at pos. The first line with text tells: the source has the indentation plus
// the leading spaces the value has. With no text, nothing is indented.
func (d *decoder) blockIndent(pos int) (int, error) {
	want := -1
	for rest := d.value; want < 0 && rest != ""; {
		var l string
		l, rest, _ = strings.Cut(rest, "\n")
		if t := strings.TrimLeft(l, " "); t != "" {
			want = len(l) - len(t)
		}
	}
	if want < 0 {
		return math.MaxInt, nil
	}
	for pos < len(d.src) {
		l := d.lineAt(pos)
		if !l.blank(d.src) {
			if indent := l.indent(d.src) - want; indent >= 0 {
				return indent, nil
			}
			break
		}
		pos = d.after(l)
	}
	return 0, errors.New("block scalar text not found in the source")
}

// lineAt returns the source line that starts at pos.
func (d *decoder) lineAt(pos int) line {
	end := pos
	for end < len(d.src) && !isBreak(d.src[end]) {
		end++
	}
	if end == len(d.src) {
		return line{start: pos, end: end, brk: -1}
	}
	return line{start: pos, end: end, brk: end}
}

// after returns the offset where the line after l starts.
func (d *decoder) after(l line) int {
	if l.brk < 0 {
		return len(d.src)
	}
	return d.skipBreak(l.brk)
}

// blockLines returns the lines of the block scalar content that starts at pos:
// all lines up to the first with text indented less than indent.
func (d *decoder) blockLines(pos, indent int) []line {
	var lines []line
	for pos < len(d.src) {
		l := d.lineAt(pos)
		if !l.blank(d.src) && l.indent(d.src) < indent {
			break
		}
		if indent == 0 && d.documentMarker(l) {
			break
		}
		lines = append(lines, l)
		pos = d.after(l)
	}
	return lines
}

// documentMarker reports whether l is a "---" or "..." line.
func (d *decoder) documentMarker(l line) bool {
	t := d.src[l.start:l.end]
	return len(t) >= 3 && (string(t[:3]) == "---" || string(t[:3]) == "...") && (len(t) == 3 || t[3] == ' ' || t[3] == '\t')
}
