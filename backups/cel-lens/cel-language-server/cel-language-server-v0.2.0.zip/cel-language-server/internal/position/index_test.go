package position

import (
	"errors"
	"testing"
)

func TestIndexPosition(t *testing.T) {
	t.Parallel()
	// é is 1 UTF-16 unit and 2 bytes; 日 is 1 and 3; 😀 is 2 and 4.
	const src = "é日 😀 x\r\nab\n\ncd\re"
	tests := []struct {
		name string
		off  int
		want Position
	}{
		{"start", 0, Position{0, 0}},
		{"after é", 2, Position{0, 1}},
		{"after 日", 5, Position{0, 2}},
		{"after emoji", 10, Position{0, 5}},
		{"inside é", 1, Position{0, 0}},
		{"inside emoji", 8, Position{0, 3}},
		{"end of line 0", 12, Position{0, 7}},
		{"start of line 1 after CRLF", 14, Position{1, 0}},
		{"second line", 15, Position{1, 1}},
		{"empty line", 17, Position{2, 0}},
		{"after lone CR", 21, Position{4, 0}},
		{"end of file", len(src), Position{4, 1}},
	}
	x := NewIndex([]byte(src))
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got, err := x.Position(tt.off)
			if err != nil || got != tt.want {
				t.Errorf("Position(%d) = %v, %v, want %v", tt.off, got, err, tt.want)
			}
		})
	}
}

func TestIndexOffset(t *testing.T) {
	t.Parallel()
	const src = "é日 😀 x\r\nab\n"
	tests := []struct {
		name string
		in   Position
		want int
	}{
		{"start", Position{0, 0}, 0},
		{"after é", Position{0, 1}, 2},
		{"after 日", Position{0, 2}, 5},
		{"after emoji", Position{0, 5}, 10},
		{"inside surrogate pair", Position{0, 4}, 6},
		{"past end of line", Position{0, 99}, 12},
		{"second line", Position{1, 1}, 15},
		{"last, empty line", Position{2, 0}, len(src)},
	}
	x := NewIndex([]byte(src))
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got, err := x.Offset(tt.in)
			if err != nil || got != tt.want {
				t.Errorf("Offset(%v) = %d, %v, want %d", tt.in, got, err, tt.want)
			}
		})
	}
}

func TestIndexOutOfRange(t *testing.T) {
	t.Parallel()
	x := NewIndex([]byte("a\n"))
	if _, err := x.Position(-1); !errors.Is(err, ErrOutOfRange) {
		t.Errorf("Position(-1) error = %v, want ErrOutOfRange", err)
	}
	if _, err := x.Position(3); !errors.Is(err, ErrOutOfRange) {
		t.Errorf("Position(3) error = %v, want ErrOutOfRange", err)
	}
	for _, p := range []Position{{3, 0}, {-1, 0}, {0, -1}} {
		if _, err := x.Offset(p); !errors.Is(err, ErrOutOfRange) {
			t.Errorf("Offset(%v) error = %v, want ErrOutOfRange", p, err)
		}
	}
}

func TestIndexEmpty(t *testing.T) {
	t.Parallel()
	x := NewIndex(nil)
	if got, err := x.Position(0); err != nil || got != (Position{}) {
		t.Errorf("Position(0) = %v, %v, want 0:0", got, err)
	}
	if got, err := x.Offset(Position{0, 5}); err != nil || got != 0 {
		t.Errorf("Offset(0:5) = %d, %v, want 0", got, err)
	}
}

func TestIndexRoundTrip(t *testing.T) {
	t.Parallel()
	const src = "a: é日 😀\n  b: \"x\"\r\n\nz\r"
	x := NewIndex([]byte(src))
	for off := range len(src) + 1 {
		// Skip offsets inside a character or a CRLF: they move to its start.
		if off < len(src) && src[off]&0xC0 == 0x80 || off > 0 && src[off-1] == '\r' && off < len(src) && src[off] == '\n' {
			continue
		}
		p, err := x.Position(off)
		if err != nil {
			t.Fatalf("Position(%d): %v", off, err)
		}
		got, err := x.Offset(p)
		if err != nil || got != off {
			t.Errorf("Offset(Position(%d) = %v) = %d, %v, want %d", off, p, got, err, off)
		}
	}
}
