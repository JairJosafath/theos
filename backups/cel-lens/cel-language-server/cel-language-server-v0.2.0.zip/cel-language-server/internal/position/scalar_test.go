package position

import (
	"fmt"
	"math/rand/v2"
	"slices"
	"strings"
	"testing"

	"go.yaml.in/yaml/v3"
)

// valueNode returns the node that is the value of the first key named k.
func valueNode(n *yaml.Node, k string) *yaml.Node {
	if n.Kind == yaml.MappingNode {
		for i := 0; i+1 < len(n.Content); i += 2 {
			if n.Content[i].Value == k {
				return n.Content[i+1]
			}
		}
	}
	for _, c := range n.Content {
		if v := valueNode(c, k); v != nil {
			return v
		}
	}
	return nil
}

func parse(tb testing.TB, src string) *yaml.Node {
	tb.Helper()
	var doc yaml.Node
	if err := yaml.Unmarshal([]byte(src), &doc); err != nil {
		tb.Fatalf("yaml.Unmarshal(%q): %v", src, err)
	}
	return &doc
}

// checkRoundTrip checks the mapping of the value of key k in src: every byte of
// the value is found in the file, except where YAML changed it.
func checkRoundTrip(t *testing.T, src string) {
	t.Helper()
	n := valueNode(parse(t, src), "k")
	if n == nil {
		t.Fatalf("no key k in %q", src)
	}
	offs, err := NewIndex([]byte(src)).Scalar(n)
	if err != nil {
		t.Fatalf("Scalar(%q) = %v", src, err)
	}
	if len(offs) != len(n.Value)+1 {
		t.Fatalf("Scalar(%q) has %d offsets, want %d", src, len(offs), len(n.Value)+1)
	}
	for i, off := range offs {
		if off < 0 || off > len(src) || (i > 0 && off < offs[i-1]) {
			t.Fatalf("Scalar(%q) offsets %v are not in order within the file", src, offs)
		}
		if i == len(n.Value) {
			break
		}
		got, want := src[off], n.Value[i]
		escape := got == '\\' && n.Style&yaml.DoubleQuotedStyle != 0
		folded := isBreak(got) && (want == ' ' || want == '\n')
		if got != want && !escape && !folded {
			t.Errorf("Scalar(%q): value[%d] = %q, file[%d] = %q", src, i, want, off, got)
		}
	}
}

var scalarCases = []struct {
	name string
	src  string
	want string // the decoded value
}{
	{"plain", "k: abc\n", "abc"},
	{"plain empty", "k:\nz: 1\n", ""},
	{"plain non-ASCII", "é日: é日😀 x\nk: é日😀 x\n", "é日😀 x"},
	{"plain multi-line", "k: a b\n  c d\nz: 1\n", "a b c d"},
	{"plain blank line", "k: a\n\n\n  b\n", "a\n\nb"},
	{"plain trailing spaces", "k: a  \t\n    b\n", "a b"},
	{"plain comment", "k: a b # c\n", "a b"},
	{"plain tag", "k: !!str abc\n", "abc"},
	{"plain anchor", "k: &a é\n", "é"},
	{"plain CRLF", "k: a\r\n  b\r\nz: 1\r\n", "a b"},
	{"plain in sequence", "- k: a\n    b\n", "a b"},
	{"single", "k: 'abc'\n", "abc"},
	{"single empty", "k: ''\n", ""},
	{"single quotes", "k: 'it''s ''x'''\n", "it's 'x'"},
	{"single non-ASCII", "é: 'é日😀'\nk: 'é日😀'\n", "é日😀"},
	{"single multi-line", "k: 'a\n  b  \n  c'\n", "a b c"},
	{"single blank line", "k: 'a\n\n  b'\n", "a\nb"},
	{"single tag", "k: !!str 'a'\n", "a"},
	{"double", "k: \"abc\"\n", "abc"},
	{"double escapes", `k: "a\"b\\c\nd\tef"` + "\n", "a\"b\\c\nd\tef"},
	{"double hex escapes", `k: "\x41\u00e9\u65e5\U0001F600!"` + "\n", "Aé日😀!"},
	{"double named escapes", `k: "\0\a\b\v\f\r\e\ \N\_\L\P"` + "\n", "\x00\a\b\v\f\r\x1b \u0085\u00a0\u2028\u2029"},
	{"double non-ASCII", "k: \"é日😀\\u00e9\"\n", "é日😀é"},
	{"double folded", "k: \"a\n  b  \n  c\"\n", "a b c"},
	{"double blank line", "k: \"a\n\n\n  b\"\n", "a\n\nb"},
	{"double escaped break", "k: \"a  \\\n    b\\\n\n  c\"\n", "a  b\nc"},
	{"double escaped space", "k: \"a\\ \n  b\"\n", "a  b"},
	{"double CRLF", "k: \"a\r\n  b\"\r\n", "a b"},
	{"literal", "k: |\n  a\n  b\n", "a\nb\n"},
	{"literal strip", "k: |-\n  a\n  b\n", "a\nb"},
	{"literal strip at end of file", "k: |-\n  a\n  b", "a\nb"},
	{"literal keep", "k: |+\n  a\n\n\nz: 1\n", "a\n\n\n"},
	{"literal keep only blanks", "k: |+\n\n\nz: 1\n", "\n\n"},
	{"literal clip drops blanks", "k: |\n  a\n\n\nz: 1\n", "a\n"},
	{"literal empty", "k: |\nz: 1\n", ""},
	{"literal blank lines inside", "k: |\n  a\n\n    \n  b\n", "a\n\n  \nb\n"},
	{"literal more indented", "k: |\n  a\n    b\n  c\n", "a\n  b\nc\n"},
	{"literal indentation indicator", "k: |2\n   a\n  b\n", " a\nb\n"},
	{"literal indicator and keep", "k: |+2\n   a\n\nz: 1\n", " a\n\n"},
	{"literal keep and indicator", "k: |2+\n   a\n\nz: 1\n", " a\n\n"},
	{"literal header comment", "k: |- # c\n  a\n", "a"},
	{"literal nested", "a:\n  b:\n    - k: |\n        x\n         y\n      z: 1\n", "x\n y\n"},
	{"literal non-ASCII", "k: |\n  é日\n  😀 x\n", "é日\n😀 x\n"},
	{"literal CRLF", "k: |\r\n  a\r\n\r\n  b\r\nz: 1\r\n", "a\n\nb\n"},
	{"literal tag", "k: !!str |\n  a\n", "a\n"},
	{"literal anchor", "k: &a |\n  a\n", "a\n"},
	{"literal comment ends it", "k: |\n  a\n# c\nz: 1\n", "a\n"},
	{"literal document marker", "k: |\n  a\n---\nz: 1\n", "a\n"},
	{"folded", "k: >\n  a\n  b\n", "a b\n"},
	{"folded strip", "k: >-\n  a\n  b\n", "a b"},
	{"folded blank lines", "k: >\n  a\n\n  b\n\n\n  c\n", "a\nb\n\nc\n"},
	{"folded leading blank lines", "k: >\n\n  a\n  b\n", "\na b\n"},
	{"folded more indented", "k: >\n  a\n    b\n    c\n  d\n", "a\n  b\n  c\nd\n"},
	{"folded more indented and blank", "k: >\n  a\n\n    b\n\n  c\n", "a\n\n  b\n\nc\n"},
	{"folded keep", "k: >+\n  a\n  b\n\n\nz: 1\n", "a b\n\n\n"},
	{"folded indentation indicator", "k: >2\n   a\n  b\n", " a\nb\n"},
	{"folded non-ASCII", "k: >-\n  é日\n  😀 x\n", "é日 😀 x"},
	{"folded nested", "a:\n  - k: >-\n      a\n      b\n    z: 1\n", "a b"},
	{"folded anchor", "k: &a >\n  a\n  b\n", "a b\n"},
}

func TestScalar(t *testing.T) {
	t.Parallel()
	for _, tt := range scalarCases {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := valueNode(parse(t, tt.src), "k").Value; got != tt.want {
				t.Fatalf("test input %q decodes to %q, want %q", tt.src, got, tt.want)
			}
			checkRoundTrip(t, tt.src)
		})
	}
}

func TestScalarOffsets(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		src  string
		want []int
	}{
		{"plain", "k: abc\n", []int{3, 4, 5, 6}},
		{"escape", `k: "a\nb"`, []int{4, 5, 7, 8}},
		{"unicode escape", `k: "\u00e9!"`, []int{4, 4, 10, 11}},
		{"doubled quote", "k: 'it''s'", []int{4, 5, 6, 8, 9}},
		{"literal", "k: |\n  ab\n  c\n", []int{7, 8, 9, 12, 13, 13}},
		{"folded", "k: >\n  a\n  b\n", []int{7, 8, 11, 12, 12}},
		{"folded plain", "k: a\n  b", []int{3, 4, 7, 8}},
		{"after tag", "k: !!str a", []int{9, 10}},
		{"empty literal", "k: |\n", []int{4}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got, err := NewIndex([]byte(tt.src)).Scalar(valueNode(parse(t, tt.src), "k"))
			if err != nil || !slices.Equal(got, tt.want) {
				t.Errorf("Scalar(%q) = %v, %v, want %v", tt.src, got, err, tt.want)
			}
		})
	}
}

func TestScalarErrors(t *testing.T) {
	t.Parallel()
	doc := parse(t, "k: abc\n")
	tests := []struct {
		name string
		x    *Index
		n    *yaml.Node
	}{
		{"mapping", NewIndex([]byte("k: abc\n")), doc.Content[0]},
		{"line past end", NewIndex([]byte("k:")), valueNode(doc, "k")},
		{"unclosed single", NewIndex([]byte("k: 'abc")), &yaml.Node{Kind: yaml.ScalarNode, Style: yaml.SingleQuotedStyle, Value: "abc", Line: 1, Column: 4}},
		{"unclosed double", NewIndex([]byte(`k: "abc`)), &yaml.Node{Kind: yaml.ScalarNode, Style: yaml.DoubleQuotedStyle, Value: "abc", Line: 1, Column: 4}},
		{"bad escape", NewIndex([]byte(`k: "\q"`)), &yaml.Node{Kind: yaml.ScalarNode, Style: yaml.DoubleQuotedStyle, Value: "q", Line: 1, Column: 4}},
		{"short escape", NewIndex([]byte(`k: "\u12`)), &yaml.Node{Kind: yaml.ScalarNode, Style: yaml.DoubleQuotedStyle, Value: "x", Line: 1, Column: 4}},
		{"block without text", NewIndex([]byte("k: |\n  a\n")), &yaml.Node{Kind: yaml.ScalarNode, Style: yaml.LiteralStyle, Value: "zz", Line: 1, Column: 4}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got, err := tt.x.Scalar(tt.n); err == nil {
				t.Errorf("Scalar = %v, nil, want an error", got)
			}
		})
	}
}

// exprGen builds random expressions: lines of words with the characters that
// are awkward in YAML.
type exprGen struct{ r *rand.Rand }

var words = []string{
	"object.spec.replicas", "<=", "5", "&&", "'x'", `"y"`, `\`, `\n`, "é", "日本", "😀", "a#b", "a:b",
	"[1,", "2]", "size(x)", "x ? y : z", "'", "''", `"`, "!", "&", "%", "@", "-", "?", "|", ">", "{", "}",
}

func (g exprGen) line() string {
	n := 1 + g.r.IntN(5)
	ws := make([]string, n)
	for i := range ws {
		ws[i] = words[g.r.IntN(len(words))]
	}
	return strings.Join(ws, " ")
}

func (g exprGen) lines() []string {
	ls := make([]string, 1+g.r.IntN(4))
	for i := range ls {
		ls[i] = g.line()
	}
	return ls
}

// styles write lines as the value of key k, nested at a random depth.
var styles = map[string]func(g exprGen, ls []string, ind string) string{
	"plain": func(g exprGen, ls []string, ind string) string {
		// Words that would not be plain are quoted by the double style.
		var b strings.Builder
		for i, l := range ls {
			if i > 0 {
				b.WriteString(g.breaks(ind + "  "))
			}
			b.WriteString(strings.Map(func(r rune) rune {
				if strings.ContainsRune(`#:'"\[{&!%@|>?-,]}`, r) {
					return 'x'
				}
				return r
			}, l))
		}
		return "k: a" + b.String() + "\n"
	},
	"single": func(g exprGen, ls []string, ind string) string {
		for i, l := range ls {
			ls[i] = strings.ReplaceAll(l, "'", "''")
		}
		return "k: '" + strings.Join(ls, g.breaks(ind+"  ")) + "'\n"
	},
	"double": func(g exprGen, ls []string, ind string) string {
		for i, l := range ls {
			l = strings.ReplaceAll(l, `\`, `\\`)
			l = strings.ReplaceAll(l, `"`, `\"`)
			if g.r.IntN(2) == 0 {
				l = strings.ReplaceAll(l, "é", `\u00e9`)
				l = strings.ReplaceAll(l, "日", `\u65e5`)
				l = strings.ReplaceAll(l, "😀", `\U0001F600`)
			}
			ls[i] = l
		}
		sep := func() string {
			if g.r.IntN(3) == 0 {
				return `\n`
			}
			if g.r.IntN(3) == 0 {
				return "\\\n" + ind + "  "
			}
			return g.breaks(ind + "  ")
		}
		var b strings.Builder
		b.WriteString("k: \"")
		for i, l := range ls {
			if i > 0 {
				b.WriteString(sep())
			}
			b.WriteString(l)
		}
		return b.String() + "\"\n"
	},
	"literal": func(g exprGen, ls []string, ind string) string {
		return block(g, "|", ls, ind, "\n")
	},
	"folded": func(g exprGen, ls []string, ind string) string {
		return block(g, ">", ls, ind, "\n")
	},
}

// breaks returns a line break, sometimes two or three, then ind.
func (g exprGen) breaks(ind string) string {
	return strings.Repeat("\n", 1+g.r.IntN(3)) + ind
}

func block(g exprGen, indicator string, ls []string, ind, brk string) string {
	chomp := []string{"", "-", "+"}[g.r.IntN(3)]
	var b strings.Builder
	b.WriteString("k: " + indicator + chomp + "\n")
	for i, l := range ls {
		if g.r.IntN(3) == 0 {
			b.WriteString(brk)
		}
		if i > 0 && g.r.IntN(4) == 0 {
			l = "  " + l // more indented
		}
		b.WriteString(ind + "  " + l + brk)
	}
	b.WriteString(strings.Repeat(brk, g.r.IntN(3)))
	return b.String()
}

func TestScalarRoundTripProperty(t *testing.T) {
	t.Parallel()
	for style, write := range styles {
		t.Run(style, func(t *testing.T) {
			t.Parallel()
			g := exprGen{rand.New(rand.NewPCG(1, 2))} //nolint:gosec // a fixed seed makes failures reproducible
			for range 500 {
				depth := g.r.IntN(3)
				ind := strings.Repeat("  ", depth)
				body := write(g, g.lines(), ind)
				var b strings.Builder
				for d := range depth {
					b.WriteString(strings.Repeat("  ", d) + "m:\n")
				}
				b.WriteString(ind + body)
				src := b.String()
				if depth == 0 {
					src += "z: 1\n"
				}
				checkRoundTripProp(t, src)
			}
		})
	}
}

// checkRoundTripProp is checkRoundTrip for generated input, which must be valid.
func checkRoundTripProp(t *testing.T, src string) {
	t.Helper()
	var doc yaml.Node
	if yaml.Unmarshal([]byte(src), &doc) != nil {
		t.Fatalf("generated invalid YAML %q", src)
	}
	if valueNode(&doc, "k") == nil {
		t.Fatalf("no key k in %q", src)
	}
	checkRoundTrip(t, src)
}

func FuzzScalar(f *testing.F) {
	for _, tt := range scalarCases {
		f.Add([]byte(tt.src))
	}
	f.Fuzz(func(t *testing.T, src []byte) {
		var doc yaml.Node
		if yaml.Unmarshal(src, &doc) != nil {
			return
		}
		x := NewIndex(src)
		var walk func(n *yaml.Node)
		walk = func(n *yaml.Node) {
			if n.Kind == yaml.ScalarNode {
				offs, err := x.Scalar(n)
				if err != nil {
					return
				}
				for _, off := range offs {
					if off < 0 || off > len(src) {
						t.Fatalf("Scalar(%q) offset %d is outside the file", src, off)
					}
				}
			}
			for _, c := range n.Content {
				walk(c)
			}
		}
		walk(&doc)
	})
}

// benchSource is a literal scalar of n lines of CEL, as a policy would have.
func benchSource(n int, style string) []byte {
	var b strings.Builder
	b.WriteString("a:\n  b:\n    k: " + style + "\n")
	for i := range n {
		fmt.Fprintf(&b, "      object.spec.items[%d].name.startsWith('é日😀') && size(object.spec.items) <= %d &&\n", i, i)
	}
	b.WriteString("z: 1\n")
	return []byte(b.String())
}

func BenchmarkScalar(b *testing.B) {
	for _, style := range []string{"|", ">"} {
		src := benchSource(1000, style)
		n := valueNode(parse(b, string(src)), "k")
		x := NewIndex(src)
		b.Run("1000 lines "+style, func(b *testing.B) {
			b.SetBytes(int64(len(src)))
			for b.Loop() {
				if _, err := x.Scalar(n); err != nil {
					b.Fatal(err)
				}
			}
		})
	}
}
