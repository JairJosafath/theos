// Package position maps places in a decoded YAML scalar back to the file, and
// file offsets to editor positions. CEL reports an error at an offset in the
// expression text; the editor needs a line and character in the file.
package position

import (
	"errors"
	"fmt"
	"slices"
	"unicode/utf8"
)

// ErrOutOfRange is returned for an offset or position outside the file.
var ErrOutOfRange = errors.New("out of range")

// Position is a place in a file as LSP 3.17 counts it.
type Position struct {
	// Line is the zero-based line.
	Line int
	// Character is the zero-based offset in UTF-16 code units from the start
	// of the line.
	Character int
}

// Index finds lines in a file. Build it once per file with [NewIndex]; it is
// read-only afterwards, so it is safe for concurrent use. Lines end at "\n",
// "\r\n" or "\r".
type Index struct {
	src    []byte
	starts []int // starts[i] is the byte offset where line i begins
}

// NewIndex indexes src, which it does not copy: do not change src while the
// Index is in use. An empty src has one empty line.
func NewIndex(src []byte) *Index {
	starts := []int{0}
	for i := 0; i < len(src); i++ {
		switch src[i] {
		case '\r':
			if i+1 < len(src) && src[i+1] == '\n' {
				i++
			}
			starts = append(starts, i+1)
		case '\n':
			starts = append(starts, i+1)
		}
	}
	return &Index{src: src, starts: starts}
}

// Position returns the position of byte offset off, which may equal the length
// of the file. An offset inside a multi-byte character is placed at the start
// of that character. It returns [ErrOutOfRange] for any other offset.
func (x *Index) Position(off int) (Position, error) {
	if off < 0 || off > len(x.src) {
		return Position{}, fmt.Errorf("position of offset %d in %d bytes: %w", off, len(x.src), ErrOutOfRange)
	}
	line, _ := slices.BinarySearch(x.starts, off+1)
	line--
	units := 0
	for p := x.starts[line]; p < off; {
		r, w := utf8.DecodeRune(x.src[p:])
		if p+w > off {
			break
		}
		units += utf16Len(r)
		p += w
	}
	return Position{Line: line, Character: units}, nil
}

// Offset returns the byte offset of p. A character past the end of its line
// gives the end of the line, as LSP requires; one inside a surrogate pair gives
// the start of that character. It returns [ErrOutOfRange] for a negative
// character or a line the file does not have.
func (x *Index) Offset(p Position) (int, error) {
	if p.Line < 0 || p.Line >= len(x.starts) || p.Character < 0 {
		return 0, fmt.Errorf("offset of line %d, character %d in %d lines: %w", p.Line, p.Character, len(x.starts), ErrOutOfRange)
	}
	off, end := x.starts[p.Line], x.lineEnd(p.Line)
	for units := 0; off < end && units < p.Character; {
		r, w := utf8.DecodeRune(x.src[off:end])
		n := utf16Len(r)
		if units+n > p.Character {
			break
		}
		units += n
		off += w
	}
	return off, nil
}

// lineEnd returns the offset of line i's line break, or the end of the file.
func (x *Index) lineEnd(i int) int {
	if i+1 == len(x.starts) {
		return len(x.src)
	}
	end := x.starts[i+1] - 1
	if x.src[end] == '\n' && end > x.starts[i] && x.src[end-1] == '\r' {
		end--
	}
	return end
}

func utf16Len(r rune) int {
	if r >= 0x10000 {
		return 2
	}
	return 1
}
