package check

import (
	"bytes"
	"context"
	"errors"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"testing"

	"c4factory.local/cel-lens/cel-language-server/internal/analysis"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

const badPolicy = "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: \"1 +\"\n"

func TestFilesSearch(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	for _, name := range []string{"b.yaml", "a.yml", "sub/c.YAML", "skip.txt", "sub/skip.json"} {
		path := filepath.Join(dir, name)
		if err := os.MkdirAll(filepath.Dir(path), 0o750); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(badPolicy), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	odd := filepath.Join(dir, "skip.txt")

	findings, err := Files(context.Background(), []string{dir, odd, dir})
	if err != nil {
		t.Fatal(err)
	}
	var got []string
	for _, f := range findings {
		got = append(got, strings.TrimPrefix(f.Path, dir+string(filepath.Separator)))
	}
	want := "a.yml b.yaml skip.txt sub/c.YAML"
	if strings.Join(got, " ") != want {
		t.Errorf("Files paths = %q, want %q", got, want)
	}
}

func TestFilesErrors(t *testing.T) {
	t.Parallel()
	if _, err := Files(context.Background(), []string{"nope.yaml"}); !errors.Is(err, os.ErrNotExist) {
		t.Errorf("Files(missing) error = %v, want os.ErrNotExist", err)
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Files(ctx, []string{t.TempDir()}); !errors.Is(err, context.Canceled) {
		t.Errorf("Files(cancelled) error = %v, want context.Canceled", err)
	}
}

func TestHasErrors(t *testing.T) {
	t.Parallel()
	at := func(s analysis.Severity) Finding { return Finding{Diagnostic: analysis.Diagnostic{Severity: s}} }
	tests := []struct {
		name string
		in   []Finding
		want bool
	}{
		{"none", nil, false},
		{"warnings only", []Finding{at(2), at(3), at(4)}, false},
		{"error among warnings", []Finding{at(2), at(analysis.Error)}, true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := HasErrors(tt.in); got != tt.want {
				t.Errorf("HasErrors(%s) = %v, want %v", tt.name, got, tt.want)
			}
		})
	}
}

func TestWrite(t *testing.T) {
	t.Parallel()
	f := []Finding{{Path: "p.yaml", Diagnostic: analysis.Diagnostic{
		Range: analysis.Range{
			Start: position.Position{Line: 4, Character: 2},
			End:   position.Position{Line: 4, Character: 6},
		},
		Severity: 2,
		Message:  "careful",
	}}}
	var text, js bytes.Buffer
	if err := WriteText(&text, f); err != nil {
		t.Fatal(err)
	}
	if want := "p.yaml:5:3: warning: careful\n"; text.String() != want {
		t.Errorf("WriteText = %q, want %q", text.String(), want)
	}
	if err := WriteJSON(&js, f); err != nil {
		t.Fatal(err)
	}
	want := `[
  {
    "path": "p.yaml",
    "range": {
      "start": {
        "line": 5,
        "column": 3
      },
      "end": {
        "line": 5,
        "column": 7
      }
    },
    "severity": "warning",
    "message": "careful"
  }
]
`
	if js.String() != want {
		t.Errorf("WriteJSON = %q, want %q", js.String(), want)
	}
}

func TestFilesKeepGoing(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	locked := filepath.Join(dir, "a-locked.yaml")
	good := filepath.Join(dir, "b-good.yaml")
	if err := os.WriteFile(locked, []byte(badPolicy), 0o000); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(good, []byte(badPolicy), 0o600); err != nil {
		t.Fatal(err)
	}
	if f, err := os.Open(locked); err == nil {
		_ = f.Close()
		t.Skip("file permissions are not enforced for this user")
	}
	missing := filepath.Join(dir, "missing.yaml")

	findings, err := Files(context.Background(), []string{missing, dir})
	if !errors.Is(err, os.ErrPermission) || !errors.Is(err, os.ErrNotExist) {
		t.Errorf("Files error = %v, want permission and not-exist errors", err)
	}
	if len(findings) == 0 {
		t.Fatal("Files findings = none, want those of the readable file")
	}
	for _, f := range findings {
		if f.Path != good {
			t.Errorf("Files finding path = %q, want %q", f.Path, good)
		}
	}
}

func TestFilesDanglingSymlink(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	broken := filepath.Join(dir, "a-broken.yaml")
	good := filepath.Join(dir, "b-good.yaml")
	if err := os.Symlink(filepath.Join(dir, "nowhere"), broken); err != nil {
		t.Skipf("symlinks unavailable: %v", err)
	}
	if err := os.WriteFile(good, []byte(badPolicy), 0o600); err != nil {
		t.Fatal(err)
	}

	findings, err := Files(context.Background(), []string{dir})
	if !errors.Is(err, os.ErrNotExist) || !strings.Contains(err.Error(), broken) {
		t.Errorf("Files error = %v, want a not-exist error naming %s", err, broken)
	}
	if len(findings) == 0 {
		t.Fatal("Files findings = none, want those of the readable file")
	}
	for _, f := range findings {
		if f.Path != good {
			t.Errorf("Files finding path = %q, want %q", f.Path, good)
		}
	}
}

func TestFilesUnreadableSubdirectory(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	private := filepath.Join(dir, "private")
	good := filepath.Join(dir, "good.yaml")
	if err := os.Mkdir(private, 0o000); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(good, []byte(badPolicy), 0o600); err != nil {
		t.Fatal(err)
	}
	if _, err := os.ReadDir(private); err == nil {
		t.Skip("directory permissions are not enforced for this user")
	}

	findings, err := Files(context.Background(), []string{dir})
	if !errors.Is(err, os.ErrPermission) || !strings.Contains(err.Error(), private) {
		t.Errorf("Files error = %v, want a permission error naming %s", err, private)
	}
	if len(findings) == 0 {
		t.Fatal("Files findings = none, want those of the readable file")
	}
}

func TestFilesSkipsVCSAndDependencies(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	for _, name := range []string{".git/a.yaml", "node_modules/b.yaml", "sub/node_modules/c.yaml", "sub/.git/d.yaml", "ok.yaml"} {
		path := filepath.Join(dir, name)
		if err := os.MkdirAll(filepath.Dir(path), 0o750); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(path, []byte(badPolicy), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	findings, err := Files(context.Background(), []string{dir})
	if err != nil {
		t.Fatal(err)
	}
	var got []string
	for _, f := range findings {
		got = append(got, strings.TrimPrefix(f.Path, dir+string(filepath.Separator)))
	}
	if want := "ok.yaml"; strings.Join(got, " ") != want {
		t.Errorf("Files paths = %q, want %q", got, want)
	}
}

func TestFilesSizeCap(t *testing.T) {
	t.Parallel()
	dir := t.TempDir()
	pad := func(n int) []byte {
		return append([]byte(badPolicy), bytes.Repeat([]byte("#"), n-len(badPolicy))...)
	}
	for name, size := range map[string]int{"under.yaml": maxFileSize, "over.yaml": maxFileSize + 1} {
		if err := os.WriteFile(filepath.Join(dir, name), pad(size), 0o600); err != nil {
			t.Fatal(err)
		}
	}
	findings, err := Files(context.Background(), []string{dir})
	if err != nil {
		t.Fatal(err)
	}
	if len(findings) != 2 {
		t.Fatalf("Files = %d findings, want 2: %v", len(findings), findings)
	}
	over, under := findings[0], findings[1]
	if filepath.Base(over.Path) != "over.yaml" || over.Diagnostic.Severity != analysis.Error ||
		!strings.Contains(over.Diagnostic.Message, "over.yaml") || !strings.Contains(over.Diagnostic.Message, strconv.Itoa(maxFileSize)) {
		t.Errorf("over-cap finding = %+v, want an error naming over.yaml and %d", over, maxFileSize)
	}
	if filepath.Base(under.Path) != "under.yaml" {
		t.Errorf("second finding path = %q, want under.yaml", under.Path)
	}
	if strings.Contains(under.Diagnostic.Message, "larger than") {
		t.Errorf("under-cap file reported as too large: %+v", under)
	}
}
