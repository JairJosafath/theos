package check

import (
	"encoding/json"
	"fmt"
	"io"
)

// WriteText writes one line per finding, path:line:col: severity: message,
// counting lines and columns from 1. Columns count UTF-16 code units, as
// editors do. The findings keep their order.
func WriteText(w io.Writer, findings []Finding) error {
	for _, f := range findings {
		start := f.Diagnostic.Range.Start
		if _, err := fmt.Fprintf(w, "%s:%d:%d: %s: %s\n", f.Path, start.Line+1, start.Character+1,
			f.Diagnostic.Severity, f.Diagnostic.Message); err != nil {
			return fmt.Errorf("write findings: %w", err)
		}
	}
	return nil
}

type jsonPosition struct {
	Line   int `json:"line"`
	Column int `json:"column"`
}

type jsonRange struct {
	Start jsonPosition `json:"start"`
	End   jsonPosition `json:"end"`
}

type jsonFinding struct {
	Path     string    `json:"path"`
	Range    jsonRange `json:"range"`
	Severity string    `json:"severity"`
	Message  string    `json:"message"`
}

// WriteJSON writes the findings as an indented JSON array, which is [] when
// there are none. Lines and columns count from 1, as in [WriteText]; the end
// of a range is exclusive.
func WriteJSON(w io.Writer, findings []Finding) error {
	out := make([]jsonFinding, 0, len(findings))
	for _, f := range findings {
		r := f.Diagnostic.Range
		out = append(out, jsonFinding{
			Path: f.Path,
			Range: jsonRange{
				Start: jsonPosition{Line: r.Start.Line + 1, Column: r.Start.Character + 1},
				End:   jsonPosition{Line: r.End.Line + 1, Column: r.End.Character + 1},
			},
			Severity: f.Diagnostic.Severity.String(),
			Message:  f.Diagnostic.Message,
		})
	}
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	if err := enc.Encode(out); err != nil {
		return fmt.Errorf("write findings: %w", err)
	}
	return nil
}
