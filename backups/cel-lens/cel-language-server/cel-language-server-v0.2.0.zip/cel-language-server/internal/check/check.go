// Package check runs the analysis over files and directories, for the
// command line: it finds the YAML files, collects their diagnostics and
// writes them as text or JSON.
package check

import (
	"context"
	"errors"
	"fmt"
	"io"
	"io/fs"
	"os"
	"path/filepath"
	"slices"
	"strings"

	"c4factory.local/cel-lens/cel-language-server/internal/analysis"
)

// maxFileSize is the largest file, in bytes, that Files reads.
const maxFileSize = 10 << 20

var errTooLarge = errors.New("file too large")

// skippedDirs are the directory names a search does not enter.
var skippedDirs = []string{".git", ".hg", ".svn", "node_modules"}

// Finding is one diagnostic in one file.
type Finding struct {
	// Path is the file, as the caller named it or as found below a directory
	// the caller named.
	Path string
	// Diagnostic is the problem, with 0-based LSP positions.
	Diagnostic analysis.Diagnostic
}

// Files checks every path and returns the findings sorted by path and
// position. A path is a file, checked whatever its name, or a directory,
// searched recursively for *.yaml and *.yml files, without entering .git,
// .hg, .svn or node_modules. A file over 10 MiB is not read; it gives an
// error finding that names it and the limit. No findings give nil.
// A path or file that cannot be read does not stop the rest: Files checks
// the others and returns their findings together with an error that joins
// one error per unreadable path, each naming it. When ctx is cancelled it
// returns nil and ctx.Err().
func Files(ctx context.Context, paths []string) ([]Finding, error) {
	var files []string
	var errs []error
	for _, p := range paths {
		found, err := expand(ctx, p)
		if err != nil {
			if ctxErr := ctx.Err(); ctxErr != nil {
				return nil, ctxErr
			}
			errs = append(errs, err)
		}
		files = append(files, found...)
	}
	slices.Sort(files)
	files = slices.Compact(files)

	var out []Finding
	var an analysis.Analyzer
	for _, file := range files {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		src, err := readCapped(file)
		if errors.Is(err, errTooLarge) {
			out = append(out, Finding{Path: file, Diagnostic: analysis.Diagnostic{
				Severity: analysis.Error,
				Message:  fmt.Sprintf("%s is larger than the %d-byte limit and was not checked", file, maxFileSize),
				Source:   analysis.Source,
			}})
			continue
		}
		if err != nil {
			errs = append(errs, fmt.Errorf("check %s: %w", file, err))
			continue
		}
		found, err := an.Diagnose(ctx, file, src)
		if err != nil {
			return nil, err
		}
		for _, d := range found {
			out = append(out, Finding{Path: file, Diagnostic: d})
		}
	}
	return out, errors.Join(errs...)
}

// HasErrors reports whether any finding is an error.
func HasErrors(findings []Finding) bool {
	return slices.ContainsFunc(findings, func(f Finding) bool {
		return f.Diagnostic.Severity == analysis.Error
	})
}

// expand lists the files a path stands for.
func expand(ctx context.Context, path string) ([]string, error) {
	info, err := os.Stat(path)
	if err != nil {
		return nil, fmt.Errorf("check %s: %w", path, err)
	}
	if !info.IsDir() {
		return []string{path}, nil
	}
	var files []string
	var errs []error
	err = filepath.WalkDir(path, func(p string, d fs.DirEntry, err error) error {
		if ctxErr := ctx.Err(); ctxErr != nil {
			return ctxErr
		}
		if err != nil {
			errs = append(errs, fmt.Errorf("search %s: %w", p, err))
			if d != nil && d.IsDir() {
				return fs.SkipDir
			}
			return nil
		}
		if d.IsDir() && p != path && slices.Contains(skippedDirs, d.Name()) {
			return fs.SkipDir
		}
		if !d.IsDir() && isYAML(p) {
			files = append(files, p)
		}
		return nil
	})
	if err != nil {
		errs = append(errs, fmt.Errorf("search %s: %w", path, err))
	}
	return files, errors.Join(errs...)
}

// readCapped reads a file of at most maxFileSize bytes; a larger one gives
// errTooLarge after at most maxFileSize+1 bytes have been read.
func readCapped(path string) (src []byte, err error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer func() { err = errors.Join(err, f.Close()) }()
	src, err = io.ReadAll(io.LimitReader(f, maxFileSize+1))
	if err != nil {
		return nil, err
	}
	if len(src) > maxFileSize {
		return nil, errTooLarge
	}
	return src, nil
}

func isYAML(path string) bool {
	ext := strings.ToLower(filepath.Ext(path))
	return ext == ".yaml" || ext == ".yml"
}
