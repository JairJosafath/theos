package server

import (
	"bufio"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"math"
	"slices"
	"strings"
	"testing"
	"time"

	"c4factory.local/cel-lens/cel-language-server/internal/jsonrpc"
	"c4factory.local/cel-lens/cel-language-server/internal/lsp"
)

// client drives a Server over in-memory pipes.
type client struct {
	t    testing.TB
	to   io.WriteCloser
	from *bufio.Reader
	done chan error
	logs *strings.Builder
}

// start runs a server with the given debounce and returns its client. The
// server stops when the test ends.
func start(tb testing.TB, debounce time.Duration) *client {
	tb.Helper()
	inR, inW := io.Pipe()
	outR, outW := io.Pipe()
	logs := &strings.Builder{}
	s := New("1.2.3", slog.New(slog.NewTextHandler(logs, nil)))
	s.Debounce = debounce
	c := &client{t: tb, to: inW, from: bufio.NewReader(outR), done: make(chan error, 1), logs: logs}
	go func() {
		err := s.Run(tb.Context(), inR, outW)
		_ = outW.Close()
		c.done <- err
	}()
	tb.Cleanup(func() {
		_ = inW.Close()
		_ = outR.Close()
	})
	return c
}

func (c *client) sendRaw(s string) {
	c.t.Helper()
	if _, err := io.WriteString(c.to, s); err != nil {
		c.t.Fatalf("write: %v", err)
	}
}

func (c *client) send(v any) {
	c.t.Helper()
	body, err := json.Marshal(v)
	if err != nil {
		c.t.Fatal(err)
	}
	c.sendRaw(fmt.Sprintf("Content-Length: %d\r\n\r\n%s", len(body), body))
}

type obj = map[string]any

func (c *client) request(id int, method string, params any) {
	c.send(obj{"jsonrpc": "2.0", "id": id, "method": method, "params": params})
}

func (c *client) notify(method string, params any) {
	c.send(obj{"jsonrpc": "2.0", "method": method, "params": params})
}

// recv reads the next message from the server.
func (c *client) recv() json.RawMessage {
	c.t.Helper()
	var length int
	for {
		line, err := c.from.ReadString('\n')
		if err != nil {
			c.t.Fatalf("read header: %v", err)
		}
		if line == "\r\n" {
			break
		}
		_, _ = fmt.Sscanf(line, "Content-Length: %d", &length)
	}
	body := make([]byte, length)
	if _, err := io.ReadFull(c.from, body); err != nil {
		c.t.Fatalf("read body: %v", err)
	}
	return body
}

type reply struct {
	ID     int             `json:"id"`
	Result json.RawMessage `json:"result"`
	Error  *jsonrpc.Error  `json:"error"`
}

func (c *client) reply() reply {
	c.t.Helper()
	var r reply
	if err := json.Unmarshal(c.recv(), &r); err != nil {
		c.t.Fatal(err)
	}
	return r
}

func (c *client) published() (lsp.PublishDiagnosticsParams, time.Time) {
	c.t.Helper()
	var m struct {
		Method string                       `json:"method"`
		Params lsp.PublishDiagnosticsParams `json:"params"`
	}
	raw := c.recv()
	at := time.Now()
	if err := json.Unmarshal(raw, &m); err != nil || m.Method != lsp.MethodPublishDiagnostic {
		c.t.Fatalf("got %s, want publishDiagnostics (%v)", raw, err)
	}
	return m.Params, at
}

func (c *client) initialize() {
	c.t.Helper()
	c.request(1, "initialize", obj{})
	if r := c.reply(); r.Error != nil {
		c.t.Fatalf("initialize: %v", r.Error)
	}
	c.notify("initialized", obj{})
}

func (c *client) open(uri, lang, text string) {
	c.notify("textDocument/didOpen", obj{"textDocument": obj{"uri": uri, "languageId": lang, "version": 1, "text": text}})
}

func (c *client) change(uri string, version int, text string) {
	c.notify("textDocument/didChange", obj{
		"textDocument":   obj{"uri": uri, "version": version},
		"contentChanges": []obj{{"text": text}},
	})
}

func (c *client) wait() error {
	c.t.Helper()
	select {
	case err := <-c.done:
		return err
	case <-time.After(10 * time.Second):
		c.t.Fatal("server did not stop")
		return nil
	}
}

const policyHead = `apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingAdmissionPolicy
metadata:
  name: demo
spec:
  matchConstraints:
    resourceRules:
      - apiGroups: ["apps"]
        apiVersions: ["v1"]
        operations: ["CREATE"]
        resources: ["deployments"]
  validations:
`

func TestDiagnosticsLifecycle(t *testing.T) {
	t.Parallel()
	c := start(t, time.Millisecond)
	c.initialize()

	const uri = "file:///policy.yaml"
	c.open(uri, "yaml", policyHead+"    - expression: object.spec.replicas <\n")
	got, _ := c.published()
	if got.URI != uri || got.Version == nil || *got.Version != 1 || len(got.Diagnostics) != 1 {
		t.Fatalf("after open: published %+v, want one diagnostic for %s at version 1", got, uri)
	}
	d := got.Diagnostics[0]
	wantStart := lsp.Position{Line: 12, Character: 40}
	if d.Range.Start != wantStart || d.Source != "cel" || d.Severity != lsp.SeverityError {
		t.Errorf("diagnostic = %+v, want start %+v, source cel, severity error", d, wantStart)
	}

	c.change(uri, 2, policyHead+"    - expression: object.spec.replicas < 3\n")
	got, _ = c.published()
	if got.Diagnostics == nil || len(got.Diagnostics) != 0 {
		t.Fatalf("after fix: diagnostics = %#v, want an empty list", got.Diagnostics)
	}

	c.change(uri, 3, policyHead+"    - expression: 1 +\n")
	if got, _ = c.published(); len(got.Diagnostics) != 1 {
		t.Fatalf("after break: %+v, want one diagnostic", got)
	}
	c.notify("textDocument/didClose", obj{"textDocument": obj{"uri": uri}})
	got, _ = c.published()
	if got.URI != uri || got.Diagnostics == nil || len(got.Diagnostics) != 0 {
		t.Errorf("after close: published %+v, want an empty list", got)
	}

	c.request(2, "shutdown", nil)
	if r := c.reply(); r.ID != 2 || r.Error != nil || string(r.Result) != "null" {
		t.Errorf("shutdown reply = %+v, want null result", r)
	}
	c.notify("exit", nil)
	if err := c.wait(); err != nil {
		t.Errorf("Run after shutdown and exit = %v, want nil", err)
	}
}

func TestInitialize(t *testing.T) {
	t.Parallel()
	c := start(t, time.Millisecond)
	c.request(1, "initialize", obj{})
	r := c.reply()
	var got lsp.InitializeResult
	if err := json.Unmarshal(r.Result, &got); err != nil {
		t.Fatal(err)
	}
	if got.Capabilities.TextDocumentSync.Change != lsp.SyncFull || got.ServerInfo.Name != Name || got.ServerInfo.Version != "1.2.3" ||
		len(got.Capabilities.CompletionProvider.TriggerCharacters) != 1 || got.Capabilities.CompletionProvider.TriggerCharacters[0] != "." {
		t.Errorf("initialize = %s, want full sync, completion on a dot and server info %s 1.2.3", r.Result, Name)
	}
}

func TestExitStatus(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		run  func(c *client)
		want error
	}{
		{"exit without shutdown", func(c *client) { c.initialize(); c.notify("exit", nil) }, ErrNoShutdown},
		{"stream ends without shutdown", func(c *client) { c.initialize(); _ = c.to.Close() }, ErrNoShutdown},
		{"stream ends after shutdown", func(c *client) {
			c.initialize()
			c.request(2, "shutdown", nil)
			c.reply()
			_ = c.to.Close()
		}, nil},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			c := start(t, time.Millisecond)
			tt.run(c)
			if err := c.wait(); !errors.Is(err, tt.want) {
				t.Errorf("Run = %v, want %v", err, tt.want)
			}
		})
	}
}

func TestRobustness(t *testing.T) {
	t.Parallel()
	c := start(t, time.Millisecond)
	c.sendRaw("Content-Length: 5\r\n\r\n{nope")
	c.sendRaw("Content-Length: x\r\n\r\n")
	c.initialize()
	c.notify("$/cancelRequest", obj{"id": 7})
	c.notify("$/unknown", obj{})
	c.request(5, "textDocument/definition", obj{})
	r := c.reply()
	if r.ID != 5 || r.Error == nil || r.Error.Code != jsonrpc.CodeMethodNotFound {
		t.Errorf("unknown request reply = %+v, want MethodNotFound", r)
	}
	c.notify("textDocument/didOpen", "not an object")
	c.request(6, "shutdown", nil)
	if r := c.reply(); r.ID != 6 || r.Error != nil {
		t.Errorf("shutdown after bad input = %+v, want success", r)
	}
	if !strings.Contains(c.logs.String(), "skip message") {
		t.Errorf("logs = %q, want the skipped message", c.logs.String())
	}
}

func TestRequestBeforeInitialize(t *testing.T) {
	t.Parallel()
	c := start(t, time.Millisecond)
	c.request(1, "shutdown", nil)
	if r := c.reply(); r.Error == nil || r.Error.Code != jsonrpc.CodeServerNotInitialized {
		t.Errorf("shutdown before initialize = %+v, want ServerNotInitialized", r)
	}
}

func TestOnlyYAMLIsChecked(t *testing.T) {
	t.Parallel()
	c := start(t, time.Millisecond)
	c.initialize()
	c.open("file:///a.json", "json", policyHead+"    - expression: 1 +\n")
	c.open("file:///b.yaml", "yaml", "a: b\n")
	if got, _ := c.published(); got.URI != "file:///b.yaml" {
		t.Errorf("first publication is for %s, want b.yaml only", got.URI)
	}
}

func TestDebounce(t *testing.T) {
	t.Parallel()
	c := start(t, 50*time.Millisecond)
	c.initialize()
	const uri = "file:///d.yaml"
	c.open(uri, "yaml", "a: b\n")
	for v := 2; v <= 5; v++ {
		c.change(uri, v, "a: b\n")
	}
	got, _ := c.published()
	if got.Version == nil || *got.Version != 5 {
		t.Fatalf("published version %v, want only the last, 5", got.Version)
	}
	c.request(2, "shutdown", nil)
	if r := c.reply(); r.ID != 2 {
		t.Errorf("next message after one publication = %+v, want the shutdown reply", r)
	}
}

func TestCloseCancelsPending(t *testing.T) {
	t.Parallel()
	c := start(t, 20*time.Millisecond)
	c.initialize()
	const uri = "file:///c.yaml"
	c.open(uri, "yaml", "a: b\n")
	c.notify("textDocument/didClose", obj{"textDocument": obj{"uri": uri}})
	if got, _ := c.published(); len(got.Diagnostics) != 0 {
		t.Fatalf("close published %+v, want an empty list", got)
	}
	c.request(2, "shutdown", nil)
	if r := c.reply(); r.ID != 2 {
		t.Errorf("message after close = %+v, want the shutdown reply and no stale diagnostics", r)
	}
}

func TestRunStopsWithContext(t *testing.T) {
	t.Parallel()
	inR, inW := io.Pipe()
	ctx, cancel := context.WithCancel(t.Context())
	s := New("dev", slog.New(slog.NewTextHandler(io.Discard, nil)))
	done := make(chan error, 1)
	go func() { done <- s.Run(ctx, inR, io.Discard) }()
	cancel()
	go func() { _, _ = inW.Write([]byte("Content-Length: 2\r\n\r\n{}")) }() // wakes a blocked read
	err := <-done
	_ = inR.Close() // releases the writer if Run never read
	if !errors.Is(err, context.Canceled) {
		t.Errorf("Run after cancel = %v, want context.Canceled", err)
	}
}

// bigPolicy is a file of about 1,000 lines with 50 CEL expressions.
func bigPolicy(bad bool) string {
	var b strings.Builder
	b.WriteString(policyHead)
	for i := range 50 {
		expr := fmt.Sprintf("object.spec.replicas <= %d && object.metadata.name.startsWith('a')", i+1)
		if bad && i == 49 {
			expr = "object.spec.replicas <="
		}
		fmt.Fprintf(&b, "    - expression: %q\n      message: too many replicas\n", expr)
		for range 17 {
			b.WriteString("      # padding\n")
		}
	}
	return b.String()
}

// budget is the time allowed from a change to its diagnostics: the 200 ms of
// the system's needs.
const budget = 200 * time.Millisecond

// completionBudget is the time allowed for one completion: the 50 ms of the issue.
const completionBudget = 50 * time.Millisecond

// openBig starts a server with the debounce of a session, opens a file of
// about 1,000 lines in it and waits for its diagnostics, which warms the
// schema caches. It returns the client and the file's URI.
func openBig(tb testing.TB) (*client, string) {
	tb.Helper()
	c := start(tb, DefaultDebounce)
	c.initialize()
	const uri = "file:///big.yaml"
	good := bigPolicy(false)
	if n := strings.Count(good, "\n"); n < 900 || n > 1100 {
		tb.Fatalf("test file has %d lines, want about 1,000", n)
	}
	c.open(uri, "yaml", good)
	c.published()
	return c, uri
}

// changeBig changes the file to its good text for an odd version and its bad
// text for an even one, and returns how long the diagnostics took to arrive.
func changeBig(c *client, uri string, version int) time.Duration {
	c.t.Helper()
	text, want := bigPolicy(true), 1
	if version%2 == 1 {
		text, want = bigPolicy(false), 0
	}
	start := time.Now()
	c.change(uri, version, text)
	got, at := c.published()
	if len(got.Diagnostics) != want {
		c.t.Fatalf("diagnostics for version %d = %+v, want %d", version, got.Diagnostics, want)
	}
	return at.Sub(start)
}

// TestLargeFileLatency bounds the time from a change to its diagnostics by
// bound, five times what it takes on an idle machine. The fastest of several
// changes is the cost of the work; a single change also measures whatever
// else the machine was doing.
func TestLargeFileLatency(t *testing.T) {
	c, uri := openBig(t)
	took := time.Duration(math.MaxInt64)
	for version := 2; version < 12; version++ {
		took = min(took, changeBig(c, uri, version))
	}
	if took > bound {
		t.Errorf("diagnostics arrived %v after the change, want within %v", took, bound)
	} else {
		t.Logf("diagnostics arrived %v after the change, bound %v", took, bound)
	}
}

// BenchmarkLargeFileLatency fails when diagnostics take longer than budget to
// arrive after a change to a file of about 1,000 lines.
func BenchmarkLargeFileLatency(b *testing.B) {
	c, uri := openBig(b)
	version := 1
	var total time.Duration
	for b.Loop() {
		version++
		total += changeBig(c, uri, version)
	}
	if got := total / time.Duration(b.N); got > budget {
		b.Errorf("diagnostics arrived %v after the change, want within %v", got, budget)
	}
}

// completion asks for the completions at the | in text, which is open as uri.
func (c *client) completion(id int, uri, text string) (json.RawMessage, time.Duration) {
	c.t.Helper()
	i := strings.IndexByte(text, '|')
	before := text[:i]
	c.open(uri, "yaml", before+text[i+1:])
	start := time.Now()
	c.request(id, "textDocument/completion", obj{
		"textDocument": obj{"uri": uri},
		"position":     obj{"line": strings.Count(before, "\n"), "character": len(before) - strings.LastIndexByte(before, '\n') - 1},
	})
	r := c.reply()
	took := time.Since(start)
	if r.ID != id || r.Error != nil {
		c.t.Fatalf("completion reply = %+v, want a result", r)
	}
	return r.Result, took
}

// completionWant is the expected completion item, with its documentation as
// the Markdown text.
type completionWant struct {
	Label            string
	Kind             int
	Detail           string
	Documentation    string
	InsertText       string
	InsertTextFormat int
}

func TestCompletion(t *testing.T) {
	t.Parallel()
	const crd = `apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: widgets.example.com
spec:
  versions:
    - name: v1
      schema:
        openAPIV3Schema:
          type: object
          properties:
            spec:
              type: object
              properties:
                count:
                  type: integer
                  description: How many.
              x-kubernetes-validations:
                - rule: self.|
`
	tests := []struct {
		name  string
		text  string
		label string
		want  completionWant
		// anyDocs skips the documentation check of an item whose text is not the test's concern.
		anyDocs bool
	}{
		{"fields of a kind", policyHead + "    - expression: object.spec.|\n", "replicas", completionWant{
			Label: "replicas", Kind: lsp.KindField, Detail: "int",
			Documentation: "Number of desired pods. This is a pointer to distinguish between explicit zero and not specified. Defaults to 1.",
		}, false},
		{"variables of a place", policyHead + "    - expression: |\n", "oldObject", completionWant{
			Label: "oldObject", Kind: lsp.KindVariable, Detail: "Deployment", Documentation: "The existing object. It is null for CREATE requests.",
		}, false},
		{"functions", policyHead + "    - expression: |\n", "size", completionWant{
			Label: "size", Kind: lsp.KindFunction, Detail: "size(bytes) -> int (+7 overloads)",
		}, true},
		{"function examples keep their backticks", policyHead + "    - expression: object.metadata.name.|\n", "startsWith", completionWant{
			Label: "startsWith", Kind: lsp.KindFunction, Detail: "string.startsWith(string) -> bool",
			Documentation: "test whether a string starts with a substring prefix\n\nExamples:\n- `'kubernetes'.startsWith('kube')`",
		}, false},
		{"macros", policyHead + "    - expression: object.spec.template.spec.containers.|\n", "all", completionWant{
			Label: "all", Kind: lsp.KindKeyword, Detail: "macro", InsertText: "all(${1:x}, ${2})", InsertTextFormat: lsp.InsertTextFormatSnippet,
		}, true},
		{"policy variables", strings.Replace(policyHead, "  validations:\n", "  variables:\n    - name: replicas\n      expression: object.spec.replicas\n  validations:\n", 1) + "    - expression: variables.|\n", "replicas", completionWant{
			Label: "replicas", Kind: lsp.KindField, Detail: "int",
		}, false},
		{"iteration variable", policyHead + "    - expression: object.spec.template.spec.containers.all(c, c.|\n", "image", completionWant{
			Label: "image", Kind: lsp.KindField, Detail: "string",
		}, true},
		{"self of a CRD rule", crd, "count", completionWant{
			Label: "count", Kind: lsp.KindField, Detail: "int", Documentation: "How many.",
		}, false},
	}
	c := start(t, time.Hour)
	c.initialize()
	for i, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c.t = t
			raw, _ := c.completion(10+i, fmt.Sprintf("file:///c%d.yaml", i), tt.text)
			var items []lsp.CompletionItem
			if err := json.Unmarshal(raw, &items); err != nil {
				t.Fatalf("items %s: %v", raw, err)
			}
			for _, item := range items {
				if item.Label != tt.label || item.Kind != tt.want.Kind {
					continue
				}
				it := completionWant{Label: item.Label, Kind: item.Kind, Detail: item.Detail, InsertText: item.InsertText, InsertTextFormat: item.InsertTextFormat}
				if d := item.Documentation; d != nil {
					if d.Kind != lsp.MarkupKindMarkdown {
						t.Errorf("item %s documentation kind = %q, want %q", tt.label, d.Kind, lsp.MarkupKindMarkdown)
					}
					it.Documentation = d.Value
				}
				if tt.anyDocs {
					it.Documentation = ""
				} else if tt.want.Documentation == "" && item.Documentation != nil {
					t.Errorf("item %s has documentation %+v, want the field left out", tt.label, item.Documentation)
				}
				if it != tt.want {
					t.Errorf("item %s = %+v, want %+v", tt.label, it, tt.want)
				}
				return
			}
			t.Errorf("%d items, none is %s of kind %d", len(items), tt.label, tt.want.Kind)
		})
	}
}

func TestCompletionOutsideCEL(t *testing.T) {
	t.Parallel()
	c := start(t, time.Hour)
	c.initialize()
	tests := []struct {
		name, uri, lang, text string
	}{
		{"yaml key", "file:///a.yaml", "yaml", policyHead + "    - |\n"},
		{"string in an expression", "file:///b.yaml", "yaml", policyHead + "    - expression: \"object.name == 'a.|'\"\n"},
		{"not yaml", "file:///c.json", "json", policyHead + "    - expression: object.spec.|\n"},
	}
	for i, tt := range tests {
		cut := strings.IndexByte(tt.text, '|')
		before := tt.text[:cut]
		c.notify("textDocument/didOpen", obj{"textDocument": obj{"uri": tt.uri, "languageId": tt.lang, "version": 1, "text": before + tt.text[cut+1:]}})
		c.request(20+i, "textDocument/completion", obj{
			"textDocument": obj{"uri": tt.uri},
			"position":     obj{"line": strings.Count(before, "\n"), "character": len(before) - strings.LastIndexByte(before, '\n') - 1},
		})
		for {
			var m struct {
				ID     *int            `json:"id"`
				Result json.RawMessage `json:"result"`
			}
			if err := json.Unmarshal(c.recv(), &m); err != nil {
				t.Fatal(err)
			}
			if m.ID == nil {
				continue // diagnostics
			}
			if string(m.Result) != "[]" {
				t.Errorf("%s: completion = %s, want []", tt.name, m.Result)
			}
			break
		}
	}
}

// bigCompletion is a file of about 1,000 lines with a completion at the |.
func bigCompletion(tb testing.TB) string {
	tb.Helper()
	text := bigPolicy(false) + "    - expression: object.spec.|\n"
	if n := strings.Count(text, "\n"); n < 900 || n > 1100 {
		tb.Fatalf("test file has %d lines, want about 1,000", n)
	}
	return text
}

// TestCompletionLatency bounds one completion by completionBound, five times
// what it takes on an idle machine. The fastest of several asks is the cost of
// the work; a single ask also measures whatever else the machine was doing.
func TestCompletionLatency(t *testing.T) {
	c := start(t, time.Hour)
	c.initialize()
	text := bigCompletion(t)
	c.completion(2, "file:///big.yaml", text) // warms the schema caches, as a session does
	took := time.Duration(math.MaxInt64)
	for id := 3; id < 8; id++ {
		raw, d := c.completion(id, "file:///big.yaml", text)
		if !strings.Contains(string(raw), `"replicas"`) {
			t.Fatalf("completion = %.200s, want the fields of spec", raw)
		}
		took = min(took, d)
	}
	if took > completionBound {
		t.Errorf("completion took %v, want within %v", took, completionBound)
	} else {
		t.Logf("completion took %v, bound %v", took, completionBound)
	}
}

// BenchmarkCompletionLatency fails when a completion in a file of about 1,000
// lines takes longer than completionBudget.
func BenchmarkCompletionLatency(b *testing.B) {
	c := start(b, time.Hour)
	c.initialize()
	text := bigCompletion(b)
	c.completion(2, "file:///big.yaml", text) // warms the schema caches, as a session does
	var total time.Duration
	id := 2
	for b.Loop() {
		id++
		_, d := c.completion(id, "file:///big.yaml", text)
		total += d
	}
	if got := total / time.Duration(b.N); got > completionBudget {
		b.Errorf("completion took %v, want within %v", got, completionBudget)
	}
}

// hover asks for the hover at the | in text, which is open as uri.
func (c *client) hover(id int, uri, lang, text string) json.RawMessage {
	c.t.Helper()
	i := strings.IndexByte(text, '|')
	before := text[:i]
	c.open(uri, lang, before+text[i+1:])
	c.request(id, "textDocument/hover", obj{
		"textDocument": obj{"uri": uri},
		"position":     obj{"line": strings.Count(before, "\n"), "character": len(before) - strings.LastIndexByte(before, '\n') - 1},
	})
	r := c.reply()
	if r.ID != id || r.Error != nil {
		c.t.Fatalf("hover reply = %+v, want a result", r)
	}
	return r.Result
}

const hoverCRD = `apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: widgets.example.com
spec:
  versions:
    - name: v1
      schema:
        openAPIV3Schema:
          type: object
          properties:
            spec:
              type: object
              properties:
                count:
                  type: integer
                  description: How many.
                tags:
                  type: array
                  items:
                    type: object
                    properties:
                      key:
                        type: string
              x-kubernetes-validations:
                - rule: %s
`

func TestHover(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name  string
		text  string
		lines []string // the lines of the Markdown value, in order
		start int      // the character where the range starts
		end   int
	}{
		{
			"variable in a policy", policyHead + "    - expression: ob|ject.spec.replicas > 0\n",
			[]string{"```cel", "object: Deployment", "```", "", "The object of the request. It is null for DELETE requests."},
			18, 24,
		},
		{
			"field in a policy", policyHead + "    - expression: object.spec.repl|icas > 0\n",
			[]string{"```cel", "replicas: int", "```", "", "Number of desired pods. This is a pointer to distinguish between explicit zero and not specified. Defaults to 1."},
			30, 38,
		},
		{
			"function in a policy", policyHead + "    - expression: si|ze(object.metadata.name) > 0\n",
			[]string{"```cel", "size(bytes) -> int", "size(list(<A>)) -> int", "size(map(<A>, <B>)) -> int", "size(string) -> int", "```", "", "compute the size of a list or map, the number of characters in a string,", "or the number of bytes in a sequence", "", "Examples:", "- `size('abc')`", "- `size([1, 2])`", "- `size({'a': 1})`"},
			18, 22,
		},
		{
			"variable in a CRD rule", fmt.Sprintf(hoverCRD, "se|lf.count > 0"),
			[]string{"```cel", "self: object", "```", "", "The value of the schema node the rule is on."},
			24, 28,
		},
		{
			"field in a CRD rule", fmt.Sprintf(hoverCRD, "self.co|unt > 0"),
			[]string{"```cel", "count: int", "```", "", "How many."},
			29, 34,
		},
		{
			"function in a CRD rule", fmt.Sprintf(hoverCRD, "self.tags.si|ze() > 0"),
			[]string{"```cel", "list(<A>).size() -> int", "```", "", "compute the size of a list or map, the number of characters in a string,", "or the number of bytes in a sequence", "", "Examples:", "- `size('abc')`", "- `size([1, 2])`", "- `size({'a': 1})`"},
			34, 38,
		},
		{
			"macro in a CRD rule", fmt.Sprintf(hoverCRD, "self.tags.al|l(t, t.key != '')"),
			[]string{"```cel", "macro all(var, predicate)", "macro all(var1, var2, predicate)", "```", "", "Tests that a predicate holds for every element of a list, or every key of a map; it is true for an empty one. With two variables, as Kubernetes enables, the predicate sees the index and the element of a list, or the key and the value of a map.", "", "Examples:", "- `[1, 2, 3].all(x, x > 0)`", "- `{'a': 1, 'b': 2}.all(k, v, v > 0)`", "- `['a', 'b'].all(i, v, v != '')`"},
			34, 37,
		},
	}
	c := start(t, time.Hour)
	c.initialize()
	for i, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c.t = t
			var h lsp.Hover
			raw := c.hover(10+i, fmt.Sprintf("file:///h%d.yaml", i), "yaml", tt.text)
			if err := json.Unmarshal(raw, &h); err != nil {
				t.Fatalf("hover %s: %v", raw, err)
			}
			if h.Contents.Kind != lsp.MarkupKindMarkdown {
				t.Errorf("hover kind = %q, want markdown", h.Contents.Kind)
			}
			if got := strings.Split(h.Contents.Value, "\n"); !slices.Equal(got, tt.lines) {
				t.Errorf("hover value = %q, want lines %q", got, tt.lines)
			}
			if h.Range.Start.Character != tt.start || h.Range.End.Character != tt.end || h.Range.Start.Line != h.Range.End.Line {
				t.Errorf("hover range = %+v, want characters %d to %d", h.Range, tt.start, tt.end)
			}
		})
	}
}

func TestHoverOutsideCEL(t *testing.T) {
	t.Parallel()
	c := start(t, time.Hour)
	c.initialize()
	tests := []struct {
		name, lang, text string
	}{
		{"yaml key", "yaml", policyHead + "    - expr|ession: object.spec.replicas > 0\n"},
		{"string in an expression", "yaml", policyHead + "    - expression: \"object.name == 'ob|ject'\"\n"},
		{"not yaml", "json", policyHead + "    - expression: ob|ject.spec.replicas > 0\n"},
	}
	for i, tt := range tests {
		if got := string(c.hover(30+i, fmt.Sprintf("file:///o%d.yaml", i), tt.lang, tt.text)); got != "null" {
			t.Errorf("%s: hover = %s, want null", tt.name, got)
		}
	}
}
