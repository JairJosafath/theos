//go:build race

package server

import "time"

// bound is the longest the fastest diagnostics may take after a change: five
// times the 255 ms it takes on an idle machine with the race detector.
const bound = 1300 * time.Millisecond

// completionBound is the longest the fastest completion may take: five times
// the 130 ms it takes on an idle machine with the race detector.
const completionBound = 650 * time.Millisecond
