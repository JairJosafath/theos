//go:build !race

package server

import "time"

// bound is the longest the fastest diagnostics may take after a change: five
// times the 120 ms it takes on an idle machine.
const bound = 600 * time.Millisecond

// completionBound is the longest the fastest completion may take: five times
// the 18 ms it takes on an idle machine.
const completionBound = 90 * time.Millisecond
