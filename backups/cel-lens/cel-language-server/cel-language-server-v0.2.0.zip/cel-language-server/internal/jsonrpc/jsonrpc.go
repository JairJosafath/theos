// Package jsonrpc reads and writes JSON-RPC 2.0 messages with the
// Content-Length framing of the Language Server Protocol. It knows nothing
// about the methods the messages carry.
package jsonrpc

import (
	"bufio"
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/textproto"
	"strconv"
	"strings"
	"sync"
)

// The error codes of JSON-RPC 2.0 and LSP 3.17 that the server uses.
const (
	// CodeInvalidRequest means the message is not a valid request.
	CodeInvalidRequest = -32600
	// CodeMethodNotFound means the server does not know the method.
	CodeMethodNotFound = -32601
	// CodeInvalidParams means the parameters of the method are wrong.
	CodeInvalidParams = -32602
	// CodeServerNotInitialized means the client sent a request before initialize.
	CodeServerNotInitialized = -32002
)

// maxBody is the largest message body Read accepts, in bytes.
const maxBody = 64 << 20

// ErrMalformed marks a message that could not be read but did not break the
// stream: the next call to [Conn.Read] reads the message after it.
var ErrMalformed = errors.New("malformed message")

// Error is the error object of a response. It is also an error, so handlers
// return it to choose the code of the reply.
type Error struct {
	// Code says what kind of error it is.
	Code int `json:"code"`
	// Message describes the error for people.
	Message string `json:"message"`
}

// Error implements error.
func (e *Error) Error() string { return fmt.Sprintf("jsonrpc error %d: %s", e.Code, e.Message) }

// Message is a request or a notification received from the peer.
type Message struct {
	// ID is the raw request id; it is empty for a notification.
	ID json.RawMessage `json:"id,omitempty"`
	// Method names what the peer asks for.
	Method string `json:"method"`
	// Params is the raw parameters, empty when the peer sent none.
	Params json.RawMessage `json:"params,omitempty"`
}

// IsNotification reports whether m wants no reply.
func (m *Message) IsNotification() bool { return len(m.ID) == 0 }

type response struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Result  any             `json:"result"`
}

type errorResponse struct {
	JSONRPC string          `json:"jsonrpc"`
	ID      json.RawMessage `json:"id"`
	Error   *Error          `json:"error"`
}

type notification struct {
	JSONRPC string `json:"jsonrpc"`
	Method  string `json:"method"`
	Params  any    `json:"params"`
}

// Conn is one end of a JSON-RPC connection. One goroutine at a time may call
// Read; Reply, ReplyError and Notify are safe for concurrent use and never
// interleave their frames. Conn does not close its reader or writer.
type Conn struct {
	r *bufio.Reader

	mu sync.Mutex // guards w
	w  io.Writer
}

// NewConn returns a Conn that reads messages from r and writes them to w.
func NewConn(r io.Reader, w io.Writer) *Conn {
	return &Conn{r: bufio.NewReader(r), w: w}
}

// Read returns the next message. It returns an error wrapping [ErrMalformed]
// for a frame with a bad header, a body that is too large or a body that is not
// a JSON-RPC message; the frame is skipped and Read may be called again. It
// returns [io.EOF] when the stream ends between messages and any other error
// when the stream breaks.
func (c *Conn) Read() (*Message, error) {
	length, err := c.readHeader()
	if err != nil {
		return nil, err
	}
	if length > maxBody {
		if _, err := io.CopyN(io.Discard, c.r, int64(length)); err != nil {
			return nil, fmt.Errorf("skip body: %w", unexpected(err))
		}
		return nil, fmt.Errorf("%w: body of %d bytes exceeds %d", ErrMalformed, length, maxBody)
	}
	body := make([]byte, length)
	if _, err := io.ReadFull(c.r, body); err != nil {
		return nil, fmt.Errorf("read body: %w", unexpected(err))
	}
	var m Message
	if err := json.Unmarshal(body, &m); err != nil {
		return nil, fmt.Errorf("%w: %w", ErrMalformed, err)
	}
	if m.Method == "" {
		return nil, fmt.Errorf("%w: no method", ErrMalformed)
	}
	return &m, nil
}

// readHeader reads the header block and returns the Content-Length.
func (c *Conn) readHeader() (int, error) {
	length := -1
	var bad error
	for first := true; ; first = false {
		line, err := c.r.ReadString('\n')
		if err != nil {
			if first && line == "" && errors.Is(err, io.EOF) {
				return 0, io.EOF
			}
			return 0, fmt.Errorf("read header: %w", unexpected(err))
		}
		line = strings.TrimRight(line, "\r\n")
		if line == "" {
			break
		}
		key, value, ok := strings.Cut(line, ":")
		if !ok {
			bad = fmt.Errorf("%w: header line %q has no colon", ErrMalformed, line)
			continue
		}
		if textproto.CanonicalMIMEHeaderKey(strings.TrimSpace(key)) != "Content-Length" {
			continue
		}
		n, err := strconv.Atoi(strings.TrimSpace(value))
		if err != nil || n < 0 {
			bad = fmt.Errorf("%w: Content-Length %q is not a size", ErrMalformed, strings.TrimSpace(value))
			continue
		}
		length = n
	}
	if bad != nil {
		// With a known length, skip the body so the next frame stays in step.
		if length >= 0 {
			if _, err := io.CopyN(io.Discard, c.r, int64(length)); err != nil {
				return 0, fmt.Errorf("skip body: %w", unexpected(err))
			}
		}
		return 0, bad
	}
	if length < 0 {
		return 0, fmt.Errorf("%w: no Content-Length header", ErrMalformed)
	}
	return length, nil
}

// unexpected turns an EOF inside a message into io.ErrUnexpectedEOF.
func unexpected(err error) error {
	if errors.Is(err, io.EOF) {
		return io.ErrUnexpectedEOF
	}
	return err
}

// Reply answers the request with the given id. A nil result is sent as null.
func (c *Conn) Reply(id json.RawMessage, result any) error {
	return c.write(response{JSONRPC: "2.0", ID: id, Result: result})
}

// ReplyError answers the request with the given id with an error.
func (c *Conn) ReplyError(id json.RawMessage, e *Error) error {
	return c.write(errorResponse{JSONRPC: "2.0", ID: id, Error: e})
}

// Notify sends a notification.
func (c *Conn) Notify(method string, params any) error {
	return c.write(notification{JSONRPC: "2.0", Method: method, Params: params})
}

func (c *Conn) write(v any) error {
	body, err := json.Marshal(v)
	if err != nil {
		return fmt.Errorf("encode message: %w", err)
	}
	var frame bytes.Buffer
	fmt.Fprintf(&frame, "Content-Length: %d\r\n\r\n", len(body))
	frame.Write(body)
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, err := c.w.Write(frame.Bytes()); err != nil {
		return fmt.Errorf("write message: %w", err)
	}
	return nil
}
