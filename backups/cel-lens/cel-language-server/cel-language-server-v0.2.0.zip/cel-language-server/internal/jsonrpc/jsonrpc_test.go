package jsonrpc

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"strconv"
	"strings"
	"testing"
)

func frame(body string) string { return fmt.Sprintf("Content-Length: %d\r\n\r\n%s", len(body), body) }

func TestRead(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name       string
		in         string
		wantMethod string
		wantNote   bool
		wantErr    error
	}{
		{"request", frame(`{"jsonrpc":"2.0","id":1,"method":"a","params":{"x":1}}`), "a", false, nil},
		{"notification", frame(`{"jsonrpc":"2.0","method":"b"}`), "b", true, nil},
		{"extra header and lower case", "content-length: 30\r\nContent-Type: x\r\n\r\n" + `{"jsonrpc":"2.0","method":"c"}`, "c", true, nil},
		{"empty stream", "", "", false, io.EOF},
		{"truncated header", "Content-Len", "", false, io.ErrUnexpectedEOF},
		{"truncated body", "Content-Length: 10\r\n\r\n{}", "", false, io.ErrUnexpectedEOF},
		{"no length", "X: y\r\n\r\n", "", false, ErrMalformed},
		{"bad length", "Content-Length: -3\r\n\r\n", "", false, ErrMalformed},
		{"header without colon", "nonsense\r\n\r\n", "", false, ErrMalformed},
		{"bad json", frame(`{"method":`), "", false, ErrMalformed},
		{"no method", frame(`{"id":1}`), "", false, ErrMalformed},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			m, err := NewConn(strings.NewReader(tt.in), io.Discard).Read()
			if !errors.Is(err, tt.wantErr) {
				t.Fatalf("Read(%q) error = %v, want %v", tt.in, err, tt.wantErr)
			}
			if err == nil && (m.Method != tt.wantMethod || m.IsNotification() != tt.wantNote) {
				t.Errorf("Read(%q) = %+v, want method %s, notification %v", tt.in, m, tt.wantMethod, tt.wantNote)
			}
		})
	}
}

func TestReadSkipsMalformed(t *testing.T) {
	t.Parallel()
	c := NewConn(strings.NewReader(frame("{bad")+frame(`{"method":"ok"}`)), io.Discard)
	if _, err := c.Read(); !errors.Is(err, ErrMalformed) {
		t.Fatalf("first Read error = %v, want ErrMalformed", err)
	}
	if m, err := c.Read(); err != nil || m.Method != "ok" {
		t.Errorf("second Read = %+v, %v, want method ok", m, err)
	}
}

func TestReadSkipsBadHeaderLine(t *testing.T) {
	t.Parallel()
	body := `{"method":"lost"}`
	in := "Content-Length: " + strconv.Itoa(len(body)) + "\r\nnonsense\r\n\r\n" + body + frame(`{"method":"ok"}`)
	c := NewConn(strings.NewReader(in), io.Discard)
	if _, err := c.Read(); !errors.Is(err, ErrMalformed) {
		t.Fatalf("first Read error = %v, want ErrMalformed", err)
	}
	if m, err := c.Read(); err != nil || m.Method != "ok" {
		t.Errorf("second Read = %+v, %v, want method ok", m, err)
	}
}

func TestWrite(t *testing.T) {
	t.Parallel()
	var out bytes.Buffer
	c := NewConn(strings.NewReader(""), &out)
	if err := c.Reply(json.RawMessage(`7`), nil); err != nil {
		t.Fatal(err)
	}
	if err := c.ReplyError(json.RawMessage(`"x"`), &Error{Code: CodeMethodNotFound, Message: "no"}); err != nil {
		t.Fatal(err)
	}
	if err := c.Notify("n", map[string]int{"a": 1}); err != nil {
		t.Fatal(err)
	}
	want := frame(`{"jsonrpc":"2.0","id":7,"result":null}`) +
		frame(`{"jsonrpc":"2.0","id":"x","error":{"code":-32601,"message":"no"}}`) +
		frame(`{"jsonrpc":"2.0","method":"n","params":{"a":1}}`)
	if out.String() != want {
		t.Errorf("wrote %q, want %q", out.String(), want)
	}
}

func FuzzRead(f *testing.F) {
	f.Add(frame(`{"jsonrpc":"2.0","id":1,"method":"a"}`))
	f.Add("Content-Length: 99999999999\r\n\r\n")
	f.Fuzz(func(_ *testing.T, in string) {
		c := NewConn(strings.NewReader(in), io.Discard)
		for range len(in) + 1 {
			if _, err := c.Read(); err != nil && !errors.Is(err, ErrMalformed) {
				return
			}
		}
	})
}
