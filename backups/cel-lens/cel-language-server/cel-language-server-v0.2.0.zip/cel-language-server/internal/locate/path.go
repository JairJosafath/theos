package locate

import (
	"strconv"
	"strings"
)

// Step is one move of an [Expression] path: into the mapping value under Key,
// or, when List is set, into the item at Index of a sequence.
type Step struct {
	Key   string
	Index int
	List  bool
}

// Key returns path extended by the mapping key key. A '.', '[', ']' or '\' in
// key is escaped with a backslash, so any key can be told from the separators.
// The empty path is the root.
func Key(path, key string) string {
	var b strings.Builder
	b.WriteString(path)
	if path != "" {
		b.WriteByte('.')
	}
	for _, r := range key {
		if strings.ContainsRune(`.[]\`, r) {
			b.WriteByte('\\')
		}
		b.WriteRune(r)
	}
	return b.String()
}

// Item returns path extended by the sequence index i.
func Item(path string, i int) string {
	return path + "[" + strconv.Itoa(i) + "]"
}

// Steps splits a path built with [Key] and [Item] into its steps. It returns
// nil when the path is malformed: an unterminated or non-numeric index, or a
// trailing escape.
func Steps(path string) []Step {
	var steps []Step
	var key strings.Builder
	inKey := false
	for i := 0; i < len(path); i++ {
		switch ch := path[i]; ch {
		case '\\':
			i++
			if i == len(path) {
				return nil
			}
			key.WriteByte(path[i])
			inKey = true
		case '.':
			if inKey {
				steps = append(steps, Step{Key: key.String()})
				key.Reset()
			}
			inKey = true
		case '[':
			if inKey {
				steps = append(steps, Step{Key: key.String()})
				key.Reset()
				inKey = false
			}
			end := strings.IndexByte(path[i:], ']')
			if end < 0 {
				return nil
			}
			n, err := strconv.Atoi(path[i+1 : i+end])
			if err != nil {
				return nil
			}
			steps = append(steps, Step{Index: n, List: true})
			i += end
		default:
			key.WriteByte(ch)
			inKey = true
		}
	}
	if inKey {
		steps = append(steps, Step{Key: key.String()})
	}
	return steps
}
