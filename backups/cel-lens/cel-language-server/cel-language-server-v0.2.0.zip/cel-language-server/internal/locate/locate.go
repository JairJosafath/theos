// Package locate finds the CEL expressions in Kubernetes YAML. A document's
// apiVersion and kind say which fields hold CEL, so authors never mark it.
package locate

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"regexp"
	"strconv"
	"strings"

	"go.yaml.in/yaml/v3"
)

// Kind is the kind of place a CEL expression is in. Each kind has its own CEL
// environment. The zero value is not a valid kind.
type Kind int

// The kinds of place that hold CEL.
const (
	// MatchCondition is a matchConditions[].expression of a policy or webhook.
	MatchCondition Kind = iota + 1
	// Variable is a spec.variables[].expression of a ValidatingAdmissionPolicy.
	Variable
	// Validation is a spec.validations[].expression.
	Validation
	// MessageExpression is a spec.validations[].messageExpression.
	MessageExpression
	// AuditAnnotation is a spec.auditAnnotations[].valueExpression.
	AuditAnnotation
	// CRDRule is an x-kubernetes-validations[].rule of a CRD schema.
	CRDRule
	// CRDMessageExpression is an x-kubernetes-validations[].messageExpression.
	CRDMessageExpression
)

var kindNames = map[Kind]string{
	MatchCondition:       "matchCondition",
	Variable:             "variable",
	Validation:           "validation",
	MessageExpression:    "messageExpression",
	AuditAnnotation:      "auditAnnotation",
	CRDRule:              "crdRule",
	CRDMessageExpression: "crdMessageExpression",
}

// String returns the kind's name, such as "validation".
func (k Kind) String() string {
	if s, ok := kindNames[k]; ok {
		return s
	}
	return "Kind(" + strconv.Itoa(int(k)) + ")"
}

// MarshalText encodes k as its name, so JSON shows names, not numbers.
func (k Kind) MarshalText() ([]byte, error) { return []byte(k.String()), nil }

// Expression is one CEL expression found in a document.
type Expression struct {
	// Text is the decoded scalar value.
	Text string `json:"text"`
	// Kind is the kind of place the expression is in.
	Kind Kind `json:"kind"`
	// Doc is the index of the YAML document, counting from 0, empty ones included.
	Doc int `json:"doc"`
	// Path is the YAML path, such as spec.validations[1].messageExpression;
	// [Steps] splits it, since a key may hold escaped dots and brackets.
	Path string `json:"path"`
	// Line and Column are the 1-based position of the scalar's start in the file.
	// Column counts characters, not bytes.
	Line   int `json:"line"`
	Column int `json:"column"`
}

// Document is one non-empty YAML document of a file.
type Document struct {
	// Index is the document's index in the file, counting from 0.
	Index int `json:"index"`
	// APIVersion and Kind are the document's top-level fields; either may be
	// empty when the document has none.
	APIVersion string `json:"apiVersion"`
	Kind       string `json:"kind"`
	// Node is the decoded document, for later checks. It is not part of
	// the JSON form.
	Node *yaml.Node `json:"-"`
	// Expressions are the CEL expressions in the document, in a fixed order;
	// empty for kinds that hold none.
	Expressions []Expression `json:"expressions"`
}

// SyntaxError is a YAML syntax error with its position in the file.
type SyntaxError struct {
	// Line and Column are 1-based and point at the line with the problem and
	// its first non-space character, not at where the construct began. Column
	// counts characters, not bytes.
	Line, Column int
	// Msg says what was wrong.
	Msg string
}

func (e *SyntaxError) Error() string {
	return fmt.Sprintf("%d:%d: %s", e.Line, e.Column, e.Msg)
}

// errLine picks the message out of yaml.v3 errors, which have no typed form.
var errLine = regexp.MustCompile(`^yaml: (?:line (\d+): )?(.*)$`)

// syntaxError locates err, which parsing src returned. yaml.v3 reports the line
// where the failed construct started and no column, so it finds the first line
// after which the file fails with the same message, and puts the error at that
// line's indentation.
func syntaxError(src []byte, err error) *SyntaxError {
	m := errLine.FindStringSubmatch(err.Error())
	if m == nil {
		return &SyntaxError{Line: 1, Column: 1, Msg: err.Error()}
	}
	reported, _ := strconv.Atoi(m[1])
	reported = max(reported, 1)
	starts := lineStarts(src)
	lo, hi := reported, max(len(starts), reported)
	for lo < hi {
		mid := lo + (hi-lo)/2
		if mid >= len(starts) || failsWith(src[:starts[mid]], err.Error()) {
			hi = mid
		} else {
			lo = mid + 1
		}
	}
	return &SyntaxError{Line: lo, Column: indent(src, starts, lo) + 1, Msg: m[2]}
}

// failsWith reports whether parsing src fails with the message msg.
func failsWith(src []byte, msg string) bool {
	err := parseAll(src)
	return err != nil && err.Error() == msg
}

// parseAll decodes every document of src and returns the first error.
func parseAll(src []byte) error {
	dec := yaml.NewDecoder(bytes.NewReader(src))
	for {
		var root yaml.Node
		if err := dec.Decode(&root); err != nil {
			if errors.Is(err, io.EOF) {
				return nil
			}
			return err
		}
	}
}

// lineStarts returns the offset where each line of src starts. The first line
// starts at 0.
func lineStarts(src []byte) []int {
	starts := []int{0}
	for i, c := range src {
		if c == '\n' && i+1 < len(src) {
			starts = append(starts, i+1)
		}
	}
	return starts
}

// indent returns the number of spaces that start the 1-based line of src.
func indent(src []byte, starts []int, line int) int {
	if line > len(starts) {
		return 0
	}
	n := 0
	for i := starts[line-1]; i < len(src) && src[i] == ' '; i++ {
		n++
	}
	return n
}

// Find returns the non-empty documents of the YAML file src with the CEL
// expressions in each. Documents of kinds that hold no CEL come back with no
// expressions; empty documents and comments are skipped. Empty src yields no
// documents. A document with a syntax error yields no expressions, but the
// documents around it still do: Find resumes at the next "---" line, and
// returns the documents it found together with the first syntax error as a
// *SyntaxError. Find returns no documents and ctx.Err() when ctx is cancelled.
// It is safe for concurrent use.
func Find(ctx context.Context, src []byte) ([]Document, error) {
	var docs []Document
	var first error
	index, start := 0, 0
	for {
		dec := yaml.NewDecoder(bytes.NewReader(src))
		var err error
		pass := len(docs)
		docs, index, err = decodeAll(ctx, src, dec, docs, index)
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		if err == nil {
			return docs, first
		}
		se := syntaxError(src, err)
		if len(docs) == pass {
			docs, index = salvage(ctx, src, docs, index, start, se.Line)
		}
		if first == nil {
			first = se
		}
		index++
		var ok bool
		if src, start, ok = resume(src, start, se.Line); !ok {
			return docs, first
		}
	}
}

// decodeAll appends the documents dec yields to docs, numbering them from
// index. It returns the next index and the error that stopped it, nil at the
// end of the input.
func decodeAll(ctx context.Context, src []byte, dec *yaml.Decoder, docs []Document, index int) ([]Document, int, error) {
	for ; ; index++ {
		if err := ctx.Err(); err != nil {
			return docs, index, err
		}
		var root yaml.Node
		err := dec.Decode(&root)
		if errors.Is(err, io.EOF) {
			return docs, index, nil
		}
		if err != nil {
			return docs, index, err
		}
		body := &root
		if root.Kind == yaml.DocumentNode && len(root.Content) == 1 {
			body = root.Content[0]
		}
		if body.Kind == 0 || (body.Kind == yaml.ScalarNode && body.Tag == "!!null") {
			continue
		}
		doc := Document{Index: index, Node: &root, Expressions: []Expression{}}
		if body.Kind == yaml.MappingNode {
			doc.APIVersion = scalar(child(body, "apiVersion"))
			doc.Kind = scalar(child(body, "kind"))
			doc.Expressions = collect(src, index, doc.APIVersion, doc.Kind, body)
		}
		docs = append(docs, doc)
	}
}

// salvage decodes the documents of src that come before the one with the
// error at errLine, for when the decoder failed before it yielded any, as it
// does for a bad character in the input. start is the line where the pass began.
// It appends the documents to docs, numbering them from index, and returns the
// index of the broken document. The earlier documents are the part of src
// before the last "---" line that is after start and before errLine.
func salvage(ctx context.Context, src []byte, docs []Document, index, start, errLine int) ([]Document, int) {
	end, line, off := 0, 1, 0
	for off < len(src) && line < errLine {
		rest := src[off:]
		n := bytes.IndexByte(rest, '\n')
		if n < 0 {
			n = len(rest)
		}
		if line > start && isMarker(rest[:n]) {
			end = off
		}
		line++
		off += n + 1
	}
	if end == 0 {
		return docs, index
	}
	docs, index, _ = decodeAll(ctx, src[:end], yaml.NewDecoder(bytes.NewReader(src[:end])), docs, index)
	return docs, index
}

// resume returns the part of src from the first "---" line that is after the
// line start, where the failed pass began, and not before errLine, with blank
// lines in front so that line numbers stay those of the whole file. It returns
// that line too, and reports false when there is no such line. The marker may
// be on errLine itself, as yaml.v3 can report an error there; the line must
// pass start so that every pass moves forward.
func resume(src []byte, start, errLine int) ([]byte, int, bool) {
	line, off := 1, 0
	for off < len(src) {
		rest := src[off:]
		end := bytes.IndexByte(rest, '\n')
		if end < 0 {
			end = len(rest)
		}
		if line > start && line >= errLine && isMarker(rest[:end]) {
			return append(bytes.Repeat([]byte{'\n'}, line-1), rest...), line, true
		}
		line++
		off += end + 1
	}
	return nil, 0, false
}

// isMarker reports whether line is a document start marker.
func isMarker(line []byte) bool {
	if !bytes.HasPrefix(line, []byte("---")) {
		return false
	}
	rest := line[3:]
	return len(rest) == 0 || rest[0] == ' ' || rest[0] == '\t' || rest[0] == '\r'
}

// field names a scalar field of a list item and the kind of place it is.
type field struct {
	key  string
	kind Kind
}

// list names a sequence of mappings under path whose fields hold CEL.
type list struct {
	path   []string
	fields []field
}

var policyLists = []list{
	{[]string{"spec", "matchConditions"}, []field{{"expression", MatchCondition}}},
	{[]string{"spec", "variables"}, []field{{"expression", Variable}}},
	{[]string{"spec", "validations"}, []field{{"expression", Validation}, {"messageExpression", MessageExpression}}},
	{[]string{"spec", "auditAnnotations"}, []field{{"valueExpression", AuditAnnotation}}},
}

func collect(src []byte, doc int, apiVersion, kind string, body *yaml.Node) []Expression {
	c := &collector{src: src, doc: doc, out: []Expression{}}
	switch {
	case kind == "ValidatingAdmissionPolicy" && (apiVersion == "admissionregistration.k8s.io/v1" || apiVersion == "admissionregistration.k8s.io/v1beta1"):
		for _, l := range policyLists {
			c.list(body, l)
		}
	case (kind == "ValidatingWebhookConfiguration" || kind == "MutatingWebhookConfiguration") && apiVersion == "admissionregistration.k8s.io/v1":
		c.webhooks(body)
	case kind == "CustomResourceDefinition" && apiVersion == "apiextensions.k8s.io/v1":
		c.versions(body)
	}
	return c.out
}

type collector struct {
	src []byte
	doc int
	out []Expression
}

func (c *collector) add(n *yaml.Node, kind Kind, path string) {
	if n == nil || n.Kind != yaml.ScalarNode || n.Tag == "!!null" {
		return
	}
	line, col := n.Line, n.Column
	if n.Style&(yaml.LiteralStyle|yaml.FoldedStyle) != 0 {
		line, col = blockText(c.src, n)
	}
	c.out = append(c.out, Expression{Text: n.Value, Kind: kind, Doc: c.doc, Path: path, Line: line, Column: col})
}

// blockText returns the position of the first line of text of the block scalar
// n, which yaml.v3 places at the indicator. A block scalar with no text stays at
// the indicator.
func blockText(src []byte, n *yaml.Node) (line, col int) {
	if strings.Trim(n.Value, " \n") == "" {
		return n.Line, n.Column
	}
	starts := lineStarts(src)
	for l := n.Line + 1; l <= len(starts); l++ {
		i := indent(src, starts, l)
		if at := starts[l-1] + i; at < len(src) && src[at] != '\n' && src[at] != '\r' {
			return l, i + 1
		}
	}
	return n.Line, n.Column
}

// list adds the fields of every item of the sequence at l.path below n.
func (c *collector) list(n *yaml.Node, l list) {
	path := ""
	for _, k := range l.path {
		path = Key(path, k)
	}
	c.items(descendNode(n, l.path...), path, l.fields)
}

func (c *collector) items(seq *yaml.Node, path string, fields []field) {
	if seq == nil || seq.Kind != yaml.SequenceNode {
		return
	}
	for i, item := range seq.Content {
		if item.Kind != yaml.MappingNode {
			continue
		}
		p := Item(path, i)
		for _, f := range fields {
			c.add(child(item, f.key), f.kind, Key(p, f.key))
		}
	}
}

func (c *collector) webhooks(body *yaml.Node) {
	seq := child(body, "webhooks")
	if seq == nil || seq.Kind != yaml.SequenceNode {
		return
	}
	for i, hook := range seq.Content {
		if hook.Kind != yaml.MappingNode {
			continue
		}
		c.items(child(hook, "matchConditions"), Key(Item("webhooks", i), "matchConditions"),
			[]field{{"expression", MatchCondition}})
	}
}

func (c *collector) versions(body *yaml.Node) {
	seq := descendNode(body, "spec", "versions")
	if seq == nil || seq.Kind != yaml.SequenceNode {
		return
	}
	for i, v := range seq.Content {
		schema := descendNode(v, "schema", "openAPIV3Schema")
		c.schema(schema, Key(Key(Item("spec.versions", i), "schema"), "openAPIV3Schema"))
	}
}

// schema adds the x-kubernetes-validations of the schema n and of every
// schema nested in it.
func (c *collector) schema(n *yaml.Node, path string) {
	if n == nil || n.Kind != yaml.MappingNode {
		return
	}
	c.items(child(n, "x-kubernetes-validations"), Key(path, "x-kubernetes-validations"),
		[]field{{"rule", CRDRule}, {"messageExpression", CRDMessageExpression}})
	if props := child(n, "properties"); props != nil && props.Kind == yaml.MappingNode {
		for i := 0; i+1 < len(props.Content); i += 2 {
			c.schema(props.Content[i+1], Key(Key(path, "properties"), props.Content[i].Value))
		}
	}
	for _, key := range []string{"items", "additionalProperties", "not"} {
		c.schema(child(n, key), Key(path, key))
	}
	for _, key := range []string{"allOf", "anyOf", "oneOf"} {
		if seq := child(n, key); seq != nil && seq.Kind == yaml.SequenceNode {
			for i, s := range seq.Content {
				c.schema(s, Item(Key(path, key), i))
			}
		}
	}
}

func descendNode(n *yaml.Node, keys ...string) *yaml.Node {
	for _, k := range keys {
		n = child(n, k)
	}
	return n
}

// child returns the value of key in mapping n, or nil.
func child(n *yaml.Node, key string) *yaml.Node {
	if n == nil || n.Kind != yaml.MappingNode {
		return nil
	}
	for i := 0; i+1 < len(n.Content); i += 2 {
		if n.Content[i].Value == key {
			return n.Content[i+1]
		}
	}
	return nil
}

// scalar returns the value of scalar node n, or "" for anything else.
func scalar(n *yaml.Node) string {
	if n == nil || n.Kind != yaml.ScalarNode {
		return ""
	}
	return n.Value
}
