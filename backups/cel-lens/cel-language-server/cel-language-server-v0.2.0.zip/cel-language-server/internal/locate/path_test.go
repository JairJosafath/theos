package locate

import (
	"reflect"
	"testing"
)

func TestStepsRoundTrip(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		path string
		want []Step
	}{
		{
			"plain", Key(Item(Key("spec", "validations"), 1), "rule"),
			[]Step{{Key: "spec"}, {Key: "validations"}, {Index: 1, List: true}, {Key: "rule"}},
		},
		{
			"escaped key", Key(Key("properties", "a.b[0]\\"), "x"),
			[]Step{{Key: "properties"}, {Key: "a.b[0]\\"}, {Key: "x"}},
		},
		{"digit key", Key("properties", "1"), []Step{{Key: "properties"}, {Key: "1"}}},
		{"empty", "", nil},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := Steps(tt.path); !reflect.DeepEqual(got, tt.want) {
				t.Errorf("Steps(%q) = %v, want %v", tt.path, got, tt.want)
			}
		})
	}
}

func TestStepsMalformed(t *testing.T) {
	t.Parallel()
	for _, path := range []string{`a\`, "a[1", "a[x]"} {
		if got := Steps(path); got != nil {
			t.Errorf("Steps(%q) = %v, want nil", path, got)
		}
	}
}
