package locate

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"testing"
	"time"
)

var update = flag.Bool("update", false, "rewrite the golden files")

const testdata = "../../testdata/locate"

func TestFindGolden(t *testing.T) {
	t.Parallel()
	files, err := filepath.Glob(filepath.Join(testdata, "*.yaml"))
	if err != nil || len(files) == 0 {
		t.Fatalf("no testdata: %v", err)
	}
	for _, file := range files {
		t.Run(strings.TrimSuffix(filepath.Base(file), ".yaml"), func(t *testing.T) {
			t.Parallel()
			src, err := os.ReadFile(file)
			if err != nil {
				t.Fatal(err)
			}
			docs, err := Find(context.Background(), src)
			if err != nil {
				t.Fatalf("Find(%s) error: %v", file, err)
			}
			var buf bytes.Buffer
			enc := json.NewEncoder(&buf)
			enc.SetEscapeHTML(false)
			enc.SetIndent("", "  ")
			if err := enc.Encode(docs); err != nil {
				t.Fatal(err)
			}
			got := buf.Bytes()
			golden := strings.TrimSuffix(file, ".yaml") + ".golden.json"
			if *update {
				if err := os.WriteFile(golden, got, 0o600); err != nil {
					t.Fatal(err)
				}
			}
			want, err := os.ReadFile(golden)
			if err != nil {
				t.Fatal(err)
			}
			if !bytes.Equal(got, want) {
				t.Errorf("Find(%s) = %s, want %s", file, got, want)
			}
		})
	}
}

func TestFindDocuments(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name      string
		src       string
		wantDocs  int
		wantExprs int
	}{
		{"empty", "", 0, 0},
		{"comment only", "# nothing\n", 0, 0},
		{"separators only", "---\n---\n", 0, 0},
		{"other kind", "apiVersion: v1\nkind: Pod\n", 1, 0},
		{"scalar document", "just text\n", 1, 0},
		{"null expression", "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression:\n", 1, 0},
		{"wrong shapes", "apiVersion: apiextensions.k8s.io/v1\nkind: CustomResourceDefinition\nspec:\n  versions: 3\n", 1, 0},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			docs, err := Find(context.Background(), []byte(tt.src))
			if err != nil {
				t.Fatalf("Find(%q) error: %v", tt.src, err)
			}
			n := 0
			for _, d := range docs {
				n += len(d.Expressions)
			}
			if len(docs) != tt.wantDocs || n != tt.wantExprs {
				t.Errorf("Find(%q) = %d docs, %d expressions, want %d, %d", tt.src, len(docs), n, tt.wantDocs, tt.wantExprs)
			}
		})
	}
}

func TestFindSyntaxError(t *testing.T) {
	t.Parallel()
	const good = "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n    - expression: \"true\"\n"
	tests := []struct {
		name     string
		src      string
		line     int
		col      int
		wantDocs []int // indexes of the documents returned
	}{
		{"single document", "a: 1\n\tb: 2\n", 2, 1, nil},
		{"broken then good", "a: 1\n\tb: 2\n---\n" + good, 2, 1, []int{1}},
		{"good then broken", good + "---\nc: 3\n\td: 4\n", 8, 1, []int{0}},
		{"good around broken", good + "---\nc: 3\n\td: 4\n---\n" + good, 8, 1, []int{0, 2}},
		{"later document", "a: 1\n---\nb: 2\n---\nc: 3\n\td: 4\n", 6, 1, []int{0, 1}},
		{"sibling of a sequence item", "a:\n  - x\n  y: 1", 3, 3, nil},
		{"bad indent after a mapping", "a: 1\n  b: 2\n", 2, 3, nil},
		{"missing colon", "a: 1\nb\nc: 2\n", 2, 1, nil},
		{"unterminated flow", "a: [\n", 1, 1, nil},
		{"control character", "a: 1\n---\nb: \x01\n", 3, 1, []int{0}},
		{"invalid UTF-8 then good", "a: 1\n---\nb: \xff\xfe\n---\n" + good, 3, 1, []int{0, 2}},
		{"unclosed quote before good", "a: 1\n---\nb: \"abc\n---\n" + good, 4, 1, []int{0, 2}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			docs, err := Find(ctx, []byte(tt.src))
			var se *SyntaxError
			if !errors.As(err, &se) {
				t.Fatalf("Find(%q) error = %v, want *SyntaxError", tt.src, err)
			}
			if se.Line != tt.line || se.Column != tt.col {
				t.Errorf("Find(%q) error at %d:%d, want %d:%d", tt.src, se.Line, se.Column, tt.line, tt.col)
			}
			var got []int
			for _, d := range docs {
				got = append(got, d.Index)
			}
			if !slices.Equal(got, tt.wantDocs) {
				t.Errorf("Find(%q) = documents %v, want %v", tt.src, got, tt.wantDocs)
			}
		})
	}
}

func TestFindBlockScalarPosition(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name      string
		indicator string
	}{
		{"literal", "|"},
		{"folded", ">"},
		{"literal keep", "|+"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			src := "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n" +
				"    - expression: " + tt.indicator + "\n\n        object.a ==\n          1\n"
			docs, err := Find(context.Background(), []byte(src))
			if err != nil || len(docs) != 1 || len(docs[0].Expressions) != 1 {
				t.Fatalf("Find(%q) = %v, %v, want one expression", src, docs, err)
			}
			if e := docs[0].Expressions[0]; e.Line != 7 || e.Column != 9 {
				t.Errorf("Find(%q) expression at %d:%d, want 7:9", src, e.Line, e.Column)
			}
		})
	}
}

func TestFindCancelled(t *testing.T) {
	t.Parallel()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Find(ctx, []byte("a: 1\n")); !errors.Is(err, context.Canceled) {
		t.Errorf("Find(cancelled) error = %v, want context.Canceled", err)
	}
}

func TestKindString(t *testing.T) {
	t.Parallel()
	if got, want := Kind(0).String(), "Kind(0)"; got != want {
		t.Errorf("Kind(0).String() = %q, want %q", got, want)
	}
	if got, want := CRDRule.String(), "crdRule"; got != want {
		t.Errorf("CRDRule.String() = %q, want %q", got, want)
	}
}

func seeds(tb testing.TB) [][]byte {
	tb.Helper()
	files, err := filepath.Glob(filepath.Join(testdata, "*.yaml"))
	if err != nil {
		tb.Fatal(err)
	}
	var out [][]byte
	for _, f := range files {
		src, err := os.ReadFile(f)
		if err != nil {
			tb.Fatal(err)
		}
		out = append(out, src)
	}
	return out
}

func FuzzFind(f *testing.F) {
	for _, src := range seeds(f) {
		f.Add(src)
	}
	f.Fuzz(func(t *testing.T, src []byte) {
		docs, err := Find(context.Background(), src)
		if err != nil {
			var se *SyntaxError
			if !errors.As(err, &se) || se.Line < 1 || se.Column < 1 {
				t.Fatalf("Find error = %v, want *SyntaxError with a position", err)
			}
			return
		}
		for _, d := range docs {
			for _, e := range d.Expressions {
				if e.Line < 1 || e.Column < 1 {
					t.Fatalf("expression %q at %d:%d, want a position", e.Path, e.Line, e.Column)
				}
			}
		}
	})
}

// findBudget is the time allowed to locate 50 expressions in a file of 1,000
// lines: the 5 ms of the issue.
const findBudget = 5 * time.Millisecond

// brokenBudget is the time allowed to locate the expressions of a broken file.
const brokenBudget = 100 * time.Millisecond

// BenchmarkFind fails when it takes longer than findBudget. It locates 50 expressions in a CRD of more than 1,000 lines of
// nested schema, with the expressions spread through it.
func BenchmarkFind(b *testing.B) {
	var sb strings.Builder
	sb.WriteString(`apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: widgets.example.com
spec:
  group: example.com
  names:
    kind: Widget
    plural: widgets
  scope: Namespaced
  versions:
    - name: v1
      served: true
      storage: true
      schema:
        openAPIV3Schema:
          type: object
          properties:
            spec:
              type: object
              properties:
`)
	for i := range 50 {
		fmt.Fprintf(&sb, `                field%[1]d:
                  type: object
                  description: field number %[1]d of the widget
                  required:
                    - name
                    - size
                  properties:
                    name:
                      type: string
                      maxLength: 63
                    size:
                      type: integer
                      minimum: 0
                      maximum: 100
                    tags:
                      type: array
                      items:
                        type: string
                  x-kubernetes-validations:
                    - rule: self.size <= 100
                      message: size is too large
`, i)
	}
	src := []byte(sb.String())
	if n := bytes.Count(src, []byte("\n")); n < 1000 {
		b.Fatalf("input has %d lines, want at least 1000", n)
	}
	ctx := context.Background()
	for b.Loop() {
		docs, err := Find(ctx, src)
		if err != nil || len(docs) != 1 || len(docs[0].Expressions) != 50 {
			b.Fatalf("Find: %v, %d docs", err, len(docs))
		}
	}
	if got := b.Elapsed() / time.Duration(b.N); got > findBudget {
		b.Errorf("Find took %v, want within %v", got, findBudget)
	}
}

// BenchmarkFindSyntaxError measures a file of more than 1,000 lines whose
// second of three documents has a syntax error, so Find decodes it again after
// the error, and locating the error decodes prefixes of the file. It is held to
// brokenBudget, half of the 200 ms an editor allows for an answer.
func BenchmarkFindSyntaxError(b *testing.B) {
	var sb strings.Builder
	doc := "apiVersion: admissionregistration.k8s.io/v1\nkind: ValidatingAdmissionPolicy\nspec:\n  validations:\n"
	for i := range 250 {
		fmt.Fprintf(&sb, "    - expression: object.a == %d\n      message: check number %d\n", i, i)
	}
	body := doc + sb.String()
	src := []byte(body + "---\na: 1\n\tb: 2\n---\n" + body)
	if n := bytes.Count(src, []byte("\n")); n < 1000 {
		b.Fatalf("input has %d lines, want at least 1000", n)
	}
	ctx := context.Background()
	for b.Loop() {
		docs, err := Find(ctx, src)
		var se *SyntaxError
		if !errors.As(err, &se) || len(docs) != 2 {
			b.Fatalf("Find: %v, %d docs", err, len(docs))
		}
	}
	if got := b.Elapsed() / time.Duration(b.N); got > brokenBudget {
		b.Errorf("Find took %v, want within %v", got, brokenBudget)
	}
}
