// Package k8sschema serves Kubernetes' own OpenAPI v3 schemas from copies
// embedded in the binary, so that kinds resolve with no cluster and no network.
// [Resolver] returns the schema of a kind and [NewRESTMapper] maps resources to
// kinds and scopes, both from the files of one Kubernetes release.
package k8sschema

//go:generate go run ./gen

import (
	"bytes"
	"compress/gzip"
	"embed"
	"encoding/json"
	"fmt"
	"strings"
	"sync"

	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apiserver/pkg/cel/openapi/resolver"
	"k8s.io/kube-openapi/pkg/validation/spec"
)

//go:embed data
var data embed.FS

const (
	refPrefix = "#/components/schemas/"
	extGVK    = "x-kubernetes-group-version-kind"
)

var _ resolver.SchemaResolver = (*Resolver)(nil)

// Resolver resolves kinds to their schemas, each with every $ref populated.
// The zero value is ready to use. A group version's file is decompressed and
// parsed the first time one of its kinds is asked for, then kept. It is safe
// for concurrent use.
type Resolver struct {
	mu     sync.Mutex
	groups map[schema.GroupVersion]*groupVersion
}

// groupVersion is the components of one file. Each schema stays raw JSON until
// a kind refers to it, as a kind uses a small part of its file.
type groupVersion struct {
	mu      sync.Mutex
	raw     map[string]json.RawMessage
	parsed  map[string]*spec.Schema
	byGVK   map[schema.GroupVersionKind]string
	nameErr error
}

// schemaOf returns the schema that ref names.
func (g *groupVersion) schemaOf(ref string) (*spec.Schema, bool) {
	name := strings.TrimPrefix(ref, refPrefix)
	g.mu.Lock()
	defer g.mu.Unlock()
	if s, ok := g.parsed[name]; ok {
		return s, true
	}
	raw, ok := g.raw[name]
	if !ok {
		return nil, false
	}
	s := new(spec.Schema)
	if err := json.Unmarshal(raw, s); err != nil {
		g.nameErr = fmt.Errorf("parse schema %s: %w", name, err)
		return nil, false
	}
	g.parsed[name] = s
	return s, true
}

// ResolveSchema returns the schema of gvk with every $ref populated. The
// result shares unchanged parts with the embedded copy, so treat it as read-only. When the group version or the kind is not in
// the embedded files the error wraps [resolver.ErrSchemaNotFound].
func (r *Resolver) ResolveSchema(gvk schema.GroupVersionKind) (*spec.Schema, error) {
	gv, err := r.load(gvk.GroupVersion())
	if err != nil {
		return nil, err
	}
	ref, ok := gv.byGVK[gvk]
	if !ok {
		return nil, fmt.Errorf("resolve %s: %w", gvk, resolver.ErrSchemaNotFound)
	}
	s, err := resolver.PopulateRefs(gv.schemaOf, ref)
	if err != nil {
		if gv.nameErr != nil {
			err = gv.nameErr
		}
		return nil, fmt.Errorf("resolve %s: %w", gvk, err)
	}
	return s, nil
}

func (r *Resolver) load(gv schema.GroupVersion) (*groupVersion, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if g, ok := r.groups[gv]; ok {
		return g, nil
	}
	g, err := parse(gv)
	if err != nil {
		return nil, err
	}
	if r.groups == nil {
		r.groups = map[schema.GroupVersion]*groupVersion{}
	}
	r.groups[gv] = g
	return g, nil
}

func fileName(gv schema.GroupVersion) string {
	name := "api__" + gv.Version
	if gv.Group != "" {
		name = "apis__" + gv.Group + "__" + gv.Version
	}
	return "data/" + name + ".json.gz"
}

func parse(gv schema.GroupVersion) (*groupVersion, error) {
	name := fileName(gv)
	b, err := data.ReadFile(name)
	if err != nil {
		return nil, fmt.Errorf("resolve group version %q: %w", gv, resolver.ErrSchemaNotFound)
	}
	zr, err := gzip.NewReader(bytes.NewReader(b))
	if err != nil {
		return nil, fmt.Errorf("read %s: %w", name, err)
	}
	var doc struct {
		Components struct {
			Schemas map[string]json.RawMessage `json:"schemas"`
		} `json:"components"`
	}
	if err := json.NewDecoder(zr).Decode(&doc); err != nil {
		return nil, fmt.Errorf("parse %s: %w", name, err)
	}
	g := &groupVersion{
		raw:    doc.Components.Schemas,
		parsed: map[string]*spec.Schema{},
		byGVK:  map[schema.GroupVersionKind]string{},
	}
	for ref, raw := range g.raw {
		var s struct {
			GVKs []schema.GroupVersionKind `json:"x-kubernetes-group-version-kind"`
		}
		if err := json.Unmarshal(raw, &s); err != nil {
			return nil, fmt.Errorf("parse %s: %s of %s: %w", name, extGVK, ref, err)
		}
		for _, k := range s.GVKs {
			g.byGVK[k] = ref
		}
	}
	return g, nil
}

// readIndex returns the embedded index of the resources every file serves.
func readIndex() ([]indexEntry, error) {
	b, err := data.ReadFile("data/resources.json")
	if err != nil {
		return nil, err
	}
	var index []indexEntry
	if err := json.Unmarshal(b, &index); err != nil {
		return nil, fmt.Errorf("parse resources.json: %w", err)
	}
	return index, nil
}

type indexEntry struct {
	Group      string `json:"group"`
	Version    string `json:"version"`
	Resource   string `json:"resource"`
	Kind       string `json:"kind"`
	Namespaced bool   `json:"namespaced"`
}
