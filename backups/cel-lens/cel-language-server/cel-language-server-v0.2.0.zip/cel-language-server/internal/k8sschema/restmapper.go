package k8sschema

import (
	"fmt"
	"slices"
	"strings"

	"k8s.io/apimachinery/pkg/api/meta"
	"k8s.io/apimachinery/pkg/runtime/schema"
)

var _ meta.RESTMapper = (*RESTMapper)(nil)

// RESTMapper maps the resources of the embedded Kubernetes release to kinds
// and scopes. It follows [meta.DefaultRESTMapper], and in addition a resource
// of "*" stands for every kind of the group and version, as it does in a
// policy's matchConstraints. It is read-only and safe for concurrent use.
type RESTMapper struct {
	*meta.DefaultRESTMapper
	kinds map[schema.GroupVersion][]schema.GroupVersionKind
}

// NewRESTMapper returns the mapper built from the embedded files. Its error
// reports a damaged index, which a test of this package would catch first.
func NewRESTMapper() (*RESTMapper, error) {
	index, err := readIndex()
	if err != nil {
		return nil, fmt.Errorf("read resource index: %w", err)
	}
	var gvs []schema.GroupVersion
	for _, e := range index {
		gv := schema.GroupVersion{Group: e.Group, Version: e.Version}
		if !slices.Contains(gvs, gv) {
			gvs = append(gvs, gv)
		}
	}
	m := &RESTMapper{
		DefaultRESTMapper: meta.NewDefaultRESTMapper(gvs),
		kinds:             map[schema.GroupVersion][]schema.GroupVersionKind{},
	}
	for _, e := range index {
		gv := schema.GroupVersion{Group: e.Group, Version: e.Version}
		gvk := gv.WithKind(e.Kind)
		scope := meta.RESTScopeRoot
		if e.Namespaced {
			scope = meta.RESTScopeNamespace
		}
		m.AddSpecific(gvk, gv.WithResource(e.Resource), gv.WithResource(strings.ToLower(e.Kind)), scope)
		m.kinds[gv] = append(m.kinds[gv], gvk)
	}
	return m, nil
}

// KindsFor is [meta.DefaultRESTMapper.KindsFor], and for a resource of "*"
// returns every kind of the group and version, in the order of the files.
// With no version it returns the kinds of every version of the group.
func (m *RESTMapper) KindsFor(input schema.GroupVersionResource) ([]schema.GroupVersionKind, error) {
	if input.Resource != "*" {
		return m.DefaultRESTMapper.KindsFor(input)
	}
	var out []schema.GroupVersionKind
	for gv, kinds := range m.kinds {
		if gv.Group == input.Group && (input.Version == "" || gv.Version == input.Version) {
			out = append(out, kinds...)
		}
	}
	if len(out) == 0 {
		return nil, &meta.NoResourceMatchError{PartialResource: input}
	}
	slices.SortFunc(out, func(a, b schema.GroupVersionKind) int {
		return strings.Compare(a.String(), b.String())
	})
	return out, nil
}

// KindFor is [meta.DefaultRESTMapper.KindFor], with the "*" of [RESTMapper.KindsFor].
func (m *RESTMapper) KindFor(resource schema.GroupVersionResource) (schema.GroupVersionKind, error) {
	kinds, err := m.KindsFor(resource)
	if err != nil {
		return schema.GroupVersionKind{}, err
	}
	if len(kinds) != 1 {
		return schema.GroupVersionKind{}, &meta.AmbiguousResourceError{PartialResource: resource, MatchingKinds: kinds}
	}
	return kinds[0], nil
}
