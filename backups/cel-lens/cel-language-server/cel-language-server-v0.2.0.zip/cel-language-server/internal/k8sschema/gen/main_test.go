package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

const appsDoc = `{"components":{"schemas":{"a":{"type":"object"}}},"paths":{
 "/apis/apps/v1/deployments":{"get":{"x-kubernetes-group-version-kind":{"group":"apps","version":"v1","kind":"Deployment"}}},
 "/apis/apps/v1/namespaces/{namespace}/deployments":{"parameters":[],"get":{"x-kubernetes-group-version-kind":{"group":"apps","version":"v1","kind":"Deployment"}}},
 "/apis/apps/v1/namespaces/{namespace}/deployments/{name}/scale":{"get":{"x-kubernetes-group-version-kind":{"group":"autoscaling","version":"v1","kind":"Scale"}}},
 "/apis/apps/v1/":{"get":{}}
}}`

func server(t *testing.T, files map[string]string) *httptest.Server {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		name := r.URL.Path[strings.LastIndex(r.URL.Path, "/")+1:]
		body, ok := files[name]
		if !ok {
			http.NotFound(w, r)
			return
		}
		_, _ = io.WriteString(w, body)
	}))
	t.Cleanup(srv.Close)
	return srv
}

func setup(t *testing.T, srv *httptest.Server, sum string) []string {
	t.Helper()
	dir := t.TempDir()
	sums := filepath.Join(dir, "sums.txt")
	if err := os.WriteFile(sums, []byte(sum+"  apis__apps__v1_openapi.json\n"), 0o600); err != nil {
		t.Fatal(err)
	}
	return []string{"-raw-url", srv.URL, "-sums", sums, "-out", filepath.Join(dir, "data")}
}

func TestRunGenerates(t *testing.T) {
	t.Parallel()
	srv := server(t, map[string]string{"apis__apps__v1_openapi.json": appsDoc})
	args := setup(t, srv, fmt.Sprintf("%x", sha256.Sum256([]byte(appsDoc))))
	if err := run(context.Background(), args); err != nil {
		t.Fatal(err)
	}
	out := args[5]
	zf, err := os.ReadFile(filepath.Join(out, "apis__apps__v1.json.gz"))
	if err != nil {
		t.Fatal(err)
	}
	zr, err := gzip.NewReader(bytes.NewReader(zf))
	if err != nil {
		t.Fatal(err)
	}
	if got, _ := io.ReadAll(zr); string(got) != `{"components":{"schemas":{"a":{"type":"object"}}}}` {
		t.Errorf("stored file decompresses to %q, want the components of the download", got)
	}
	index, err := os.ReadFile(filepath.Join(out, indexFile))
	if err != nil {
		t.Fatal(err)
	}
	if !strings.Contains(string(index), `"kind": "Deployment"`) || !strings.Contains(string(index), `"namespaced": true`) || strings.Contains(string(index), "Scale") {
		t.Errorf("index = %s, want namespaced Deployment only", index)
	}

	// A second run changes nothing, not even modification times.
	before := stat(t, out)
	if err := run(context.Background(), args); err != nil {
		t.Fatal(err)
	}
	if after := stat(t, out); after != before {
		t.Errorf("second run changed the output:\n%s\nwant\n%s", after, before)
	}
}

func stat(t *testing.T, dir string) string {
	t.Helper()
	entries, err := os.ReadDir(dir)
	if err != nil {
		t.Fatal(err)
	}
	var sb strings.Builder
	for _, e := range entries {
		info, err := e.Info()
		if err != nil {
			t.Fatal(err)
		}
		fmt.Fprintf(&sb, "%s %d %v\n", e.Name(), info.Size(), info.ModTime())
	}
	return sb.String()
}

func TestRunRejectsWrongSum(t *testing.T) {
	t.Parallel()
	srv := server(t, map[string]string{"apis__apps__v1_openapi.json": appsDoc})
	args := setup(t, srv, strings.Repeat("0", 64))
	err := run(context.Background(), args)
	if err == nil || !strings.Contains(err.Error(), "sha256") {
		t.Errorf("run with a wrong sum error = %v, want a sha256 mismatch", err)
	}
	if _, err := os.Stat(filepath.Join(args[5], "apis__apps__v1.json.gz")); err == nil {
		t.Error("a file that failed its sum was stored")
	}
}

func TestRunDownloadFails(t *testing.T) {
	t.Parallel()
	srv := server(t, nil)
	args := setup(t, srv, strings.Repeat("0", 64))
	if err := run(context.Background(), args); err == nil || !strings.Contains(err.Error(), "404") {
		t.Errorf("run with a missing file error = %v, want 404", err)
	}
}

func TestRunUpdateSums(t *testing.T) {
	t.Parallel()
	srv := server(t, map[string]string{
		"apis__apps__v1_openapi.json": appsDoc,
		"v3":                          `[{"name":"apis__apps__v1_openapi.json"},{"name":"apis__apps_openapi.json"},{"name":"version_openapi.json"}]`,
	})
	args := setup(t, srv, "")
	args = append(args, "-update-sums", "-list-url", srv.URL)
	if err := run(context.Background(), args); err != nil {
		t.Fatal(err)
	}
	got, err := os.ReadFile(args[3])
	if err != nil {
		t.Fatal(err)
	}
	want := fmt.Sprintf("%x  apis__apps__v1_openapi.json\n", sha256.Sum256([]byte(appsDoc)))
	if string(got) != want {
		t.Errorf("sums = %q, want %q", got, want)
	}
}

func TestGroupVersionFile(t *testing.T) {
	t.Parallel()
	tests := map[string]bool{
		"api__v1_openapi.json":                        true,
		"apis__apps__v1_openapi.json":                 true,
		"apis__resource.k8s.io__v1beta2_openapi.json": true,
		"apis__apps_openapi.json":                     false,
		"api_openapi.json":                            false,
		"openid__v1__jwks_openapi.json":               false,
		"version_openapi.json":                        false,
	}
	for name, want := range tests {
		t.Run(name, func(t *testing.T) {
			t.Parallel()
			if got := groupVersionFile.MatchString(name); got != want {
				t.Errorf("groupVersionFile(%q) = %v, want %v", name, got, want)
			}
		})
	}
}

func TestRunCancelled(t *testing.T) {
	t.Parallel()
	srv := server(t, map[string]string{"apis__apps__v1_openapi.json": appsDoc})
	args := setup(t, srv, strings.Repeat("0", 64))
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if err := run(ctx, args); err == nil {
		t.Error("run with a cancelled context succeeded")
	}
}
