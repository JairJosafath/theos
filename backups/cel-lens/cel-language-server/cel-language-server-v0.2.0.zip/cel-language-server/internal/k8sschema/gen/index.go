package main

import (
	"encoding/json"
	"fmt"
	"slices"
	"strings"
)

const indexFile = "resources.json"

// resource is one entry of the index; package k8sschema reads the same shape.
type resource struct {
	Group      string `json:"group"`
	Version    string `json:"version"`
	Resource   string `json:"resource"`
	Kind       string `json:"kind"`
	Namespaced bool   `json:"namespaced"`
}

// components returns doc cut down to its components, the part package
// k8sschema reads; the paths, three quarters of a file, are only needed for
// the index. The result is compact JSON.
func components(name string, doc []byte) ([]byte, error) {
	var spec struct {
		Components json.RawMessage `json:"components"`
	}
	if err := json.Unmarshal(doc, &spec); err != nil {
		return nil, fmt.Errorf("parse %s: %w", name, err)
	}
	if len(spec.Components) == 0 {
		return nil, fmt.Errorf("%s: no components", name)
	}
	return json.Marshal(spec)
}

var operations = []string{"get", "post", "put", "patch", "delete"}

// indexResources lists the resources a group version file serves, found in its
// paths: a collection is /<prefix>/<plural>, or
// /<prefix>/namespaces/{namespace}/<plural> when the resource is namespaced.
// The operations name the kind in x-kubernetes-group-version-kind.
func indexResources(name string, doc []byte) ([]resource, error) {
	var spec struct {
		Paths map[string]map[string]json.RawMessage `json:"paths"`
	}
	if err := json.Unmarshal(doc, &spec); err != nil {
		return nil, fmt.Errorf("parse %s: %w", name, err)
	}
	found := map[string]resource{}
	for path, item := range spec.Paths {
		plural, namespaced := collection(path)
		if plural == "" {
			continue
		}
		for _, op := range operations {
			raw, ok := item[op]
			if !ok {
				continue
			}
			var o struct {
				GVK *struct{ Group, Version, Kind string } `json:"x-kubernetes-group-version-kind"`
			}
			if err := json.Unmarshal(raw, &o); err != nil {
				return nil, fmt.Errorf("parse %s %s %s: %w", name, op, path, err)
			}
			if o.GVK == nil {
				continue
			}
			r := found[plural]
			r.Group, r.Version, r.Kind, r.Resource = o.GVK.Group, o.GVK.Version, o.GVK.Kind, plural
			r.Namespaced = r.Namespaced || namespaced
			found[plural] = r
			break
		}
	}
	if len(found) == 0 {
		return nil, fmt.Errorf("%s: no resources found", name)
	}
	out := make([]resource, 0, len(found))
	for _, r := range found {
		out = append(out, r)
	}
	slices.SortFunc(out, func(a, b resource) int {
		return strings.Compare(a.Resource, b.Resource)
	})
	return out, nil
}

// collection returns the plural of a path that lists a resource, and whether
// the path is inside a namespace. Other paths return "".
func collection(path string) (plural string, namespaced bool) {
	segs := strings.Split(strings.Trim(path, "/"), "/")
	// Drop the api/v1 or apis/<group>/<version> prefix.
	switch {
	case len(segs) >= 2 && segs[0] == "api":
		segs = segs[2:]
	case len(segs) >= 3 && segs[0] == "apis":
		segs = segs[3:]
	default:
		return "", false
	}
	switch {
	case len(segs) == 1:
		return segs[0], false
	case len(segs) == 3 && segs[0] == "namespaces" && segs[1] == "{namespace}":
		return segs[2], true
	}
	return "", false
}
