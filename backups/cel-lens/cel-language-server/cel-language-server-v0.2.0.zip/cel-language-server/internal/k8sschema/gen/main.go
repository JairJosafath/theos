// Command gen downloads Kubernetes' OpenAPI v3 files, checks them against the
// SHA-256 sums kept in the repository and writes the compressed copies that
// package k8sschema embeds, with an index of the resources they serve.
//
// Run it with go generate in the k8sschema directory. With -update-sums it
// instead lists the files of the tagged release and rewrites the sums file;
// see the README of package k8sschema.
package main

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/signal"
	"path/filepath"
	"regexp"
	"slices"
	"strings"

	"golang.org/x/sync/errgroup"
)

const (
	defaultVersion = "v1.37.0"
	downloadLimit  = 8
	// maxFileSize bounds a download; the largest v3 file is about 2 MB.
	maxFileSize = 64 << 20
)

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	err := run(ctx, os.Args[1:])
	stop()
	switch {
	case err == nil:
	case errors.Is(err, flag.ErrHelp):
		os.Exit(2)
	default:
		fmt.Fprintln(os.Stderr, "gen:", err)
		os.Exit(1)
	}
}

type config struct {
	version    string
	rawURL     string
	listURL    string
	sums       string
	out        string
	updateSums bool
}

func run(ctx context.Context, args []string) error {
	var c config
	fs := flag.NewFlagSet("gen", flag.ContinueOnError)
	fs.StringVar(&c.version, "version", defaultVersion, "Kubernetes release tag")
	fs.StringVar(&c.rawURL, "raw-url", "https://raw.githubusercontent.com/kubernetes/kubernetes", "base URL of the raw files; the tag and path are appended")
	fs.StringVar(&c.listURL, "list-url", "https://api.github.com/repos/kubernetes/kubernetes/contents", "base URL of the directory listing, used with -update-sums")
	fs.StringVar(&c.sums, "sums", "sums.txt", "file of SHA-256 sums, one `hash  name` per line")
	fs.StringVar(&c.out, "out", "data", "directory for the compressed files and the index")
	fs.BoolVar(&c.updateSums, "update-sums", false, "list the release's files and rewrite the sums file")
	if err := fs.Parse(args); err != nil {
		return err
	}
	client := http.DefaultClient
	if c.updateSums {
		return updateSums(ctx, client, c)
	}
	return generate(ctx, client, c)
}

const specDir = "api/openapi-spec/v3/"

// groupVersionFile matches the files of one group version, such as
// apis__apps__v1_openapi.json, and not the discovery documents of a group.
var groupVersionFile = regexp.MustCompile(`^apis?__(.+__)?v\d[a-z0-9]*_openapi\.json$`)

func fileURL(c config, name string) string {
	return c.rawURL + "/" + c.version + "/" + specDir + name
}

func fetch(ctx context.Context, client *http.Client, url string) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, http.NoBody)
	if err != nil {
		return nil, fmt.Errorf("fetch %s: %w", url, err)
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("fetch %s: %w", url, err)
	}
	defer func() { _ = resp.Body.Close() }()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("fetch %s: %s", url, resp.Status)
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, maxFileSize))
	if err != nil {
		return nil, fmt.Errorf("fetch %s: %w", url, err)
	}
	return b, nil
}

// fetchAll downloads the named files, a few at a time, in the order of names.
func fetchAll(ctx context.Context, client *http.Client, c config, names []string) ([][]byte, error) {
	files := make([][]byte, len(names))
	g, ctx := errgroup.WithContext(ctx)
	g.SetLimit(downloadLimit)
	for i, name := range names {
		g.Go(func() error {
			b, err := fetch(ctx, client, fileURL(c, name))
			files[i] = b
			return err
		})
	}
	if err := g.Wait(); err != nil {
		return nil, err
	}
	return files, nil
}

func updateSums(ctx context.Context, client *http.Client, c config) error {
	listing, err := fetch(ctx, client, c.listURL+"/"+strings.TrimSuffix(specDir, "/")+"?ref="+c.version)
	if err != nil {
		return err
	}
	var entries []struct {
		Name string `json:"name"`
	}
	if err := json.Unmarshal(listing, &entries); err != nil {
		return fmt.Errorf("parse listing of %s: %w", specDir, err)
	}
	var names []string
	for _, e := range entries {
		if groupVersionFile.MatchString(e.Name) {
			names = append(names, e.Name)
		}
	}
	if len(names) == 0 {
		return fmt.Errorf("listing of %s at %s has no group version files", specDir, c.version)
	}
	slices.Sort(names)
	files, err := fetchAll(ctx, client, c, names)
	if err != nil {
		return err
	}
	var buf bytes.Buffer
	for i, name := range names {
		fmt.Fprintf(&buf, "%x  %s\n", sha256.Sum256(files[i]), name)
	}
	return writeIfChanged(c.sums, buf.Bytes())
}

func readSums(path string) (names []string, sums map[string]string, err error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, nil, err
	}
	sums = map[string]string{}
	sc := bufio.NewScanner(bytes.NewReader(b))
	for line := 1; sc.Scan(); line++ {
		fields := strings.Fields(sc.Text())
		if len(fields) == 0 {
			continue
		}
		if len(fields) != 2 || len(fields[0]) != 2*sha256.Size {
			return nil, nil, fmt.Errorf("%s:%d: want `sha256  name`", path, line)
		}
		names = append(names, fields[1])
		sums[fields[1]] = fields[0]
	}
	if err := sc.Err(); err != nil {
		return nil, nil, fmt.Errorf("read %s: %w", path, err)
	}
	if len(names) == 0 {
		return nil, nil, fmt.Errorf("%s lists no files", path)
	}
	return names, sums, nil
}

func generate(ctx context.Context, client *http.Client, c config) error {
	names, sums, err := readSums(c.sums)
	if err != nil {
		return err
	}
	files, err := fetchAll(ctx, client, c, names)
	if err != nil {
		return err
	}
	if err := os.MkdirAll(c.out, 0o750); err != nil {
		return err
	}
	var index []resource
	want := map[string]bool{indexFile: true}
	for i, name := range names {
		if got := hex.EncodeToString(sha256Sum(files[i])); got != sums[name] {
			return fmt.Errorf("%s: sha256 is %s, %s lists %s", name, got, c.sums, sums[name])
		}
		res, err := indexResources(name, files[i])
		if err != nil {
			return err
		}
		index = append(index, res...)
		stored, err := components(name, files[i])
		if err != nil {
			return err
		}
		out := strings.TrimSuffix(name, "_openapi.json") + ".json.gz"
		want[out] = true
		if err := writeCompressed(filepath.Join(c.out, out), stored); err != nil {
			return err
		}
	}
	b, err := json.MarshalIndent(index, "", " ")
	if err != nil {
		return err
	}
	if err := writeIfChanged(filepath.Join(c.out, indexFile), append(b, '\n')); err != nil {
		return err
	}
	return removeStale(c.out, want)
}

func sha256Sum(b []byte) []byte {
	sum := sha256.Sum256(b)
	return sum[:]
}

// writeCompressed gzips content into path, leaving the file alone when it
// already decompresses to content, so that a second run changes nothing even
// if the compressor's output changed between Go releases.
func writeCompressed(path string, content []byte) error {
	if old, err := readGzip(path); err == nil && bytes.Equal(old, content) {
		return nil
	}
	var buf bytes.Buffer
	zw, err := gzip.NewWriterLevel(&buf, gzip.BestCompression)
	if err != nil {
		return err
	}
	if _, err := zw.Write(content); err != nil {
		return err
	}
	if err := zw.Close(); err != nil {
		return err
	}
	return os.WriteFile(path, buf.Bytes(), 0o600)
}

func readGzip(path string) ([]byte, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	zr, err := gzip.NewReader(bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	return io.ReadAll(zr)
}

func writeIfChanged(path string, content []byte) error {
	if old, err := os.ReadFile(path); err == nil && bytes.Equal(old, content) {
		return nil
	}
	return os.WriteFile(path, content, 0o600)
}

// removeStale deletes the files of dir that are not in want, such as those of
// a group the previous release served.
func removeStale(dir string, want map[string]bool) error {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return err
	}
	for _, e := range entries {
		if !want[e.Name()] {
			if err := os.Remove(filepath.Join(dir, e.Name())); err != nil {
				return err
			}
		}
	}
	return nil
}
