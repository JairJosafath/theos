package k8sschema

import (
	"errors"
	"fmt"
	"io/fs"
	"math"
	"os"
	"strings"
	"sync"
	"testing"
	"time"

	"k8s.io/apimachinery/pkg/api/meta"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apiserver/pkg/cel/openapi/resolver"
	"k8s.io/kube-openapi/pkg/validation/spec"
)

func TestResolverResolveSchema(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		gvk  schema.GroupVersionKind
	}{
		{"Pod", schema.GroupVersionKind{Version: "v1", Kind: "Pod"}},
		{"ConfigMap", schema.GroupVersionKind{Version: "v1", Kind: "ConfigMap"}},
		{"Namespace", schema.GroupVersionKind{Version: "v1", Kind: "Namespace"}},
		{"Service", schema.GroupVersionKind{Version: "v1", Kind: "Service"}},
		{"Deployment", schema.GroupVersionKind{Group: "apps", Version: "v1", Kind: "Deployment"}},
		{"StatefulSet", schema.GroupVersionKind{Group: "apps", Version: "v1", Kind: "StatefulSet"}},
		{"Job", schema.GroupVersionKind{Group: "batch", Version: "v1", Kind: "Job"}},
		{"Ingress", schema.GroupVersionKind{Group: "networking.k8s.io", Version: "v1", Kind: "Ingress"}},
	}
	var r Resolver
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			s, err := r.ResolveSchema(tt.gvk)
			if err != nil {
				t.Fatalf("ResolveSchema(%v) error: %v", tt.gvk, err)
			}
			if s.Properties["metadata"].Properties["name"].Type == nil {
				t.Errorf("ResolveSchema(%v): metadata.name has no type, $ref not populated", tt.gvk)
			}
			if left := refs(s); left != "" {
				t.Errorf("ResolveSchema(%v) leaves $ref %s", tt.gvk, left)
			}
		})
	}
}

// refs returns the first $ref left in s, or "".
func refs(s *spec.Schema) string {
	if s.Ref.GetURL() != nil {
		return s.Ref.String()
	}
	for _, p := range s.Properties {
		if r := refs(&p); r != "" {
			return r
		}
	}
	if s.Items != nil && s.Items.Schema != nil {
		return refs(s.Items.Schema)
	}
	if s.AdditionalProperties != nil && s.AdditionalProperties.Schema != nil {
		return refs(s.AdditionalProperties.Schema)
	}
	return ""
}

func TestResolverResolveSchemaDeployment(t *testing.T) {
	t.Parallel()
	var r Resolver
	s, err := r.ResolveSchema(schema.GroupVersionKind{Group: "apps", Version: "v1", Kind: "Deployment"})
	if err != nil {
		t.Fatal(err)
	}
	replicas := s.Properties["spec"].Properties["replicas"]
	if len(replicas.Type) != 1 || replicas.Type[0] != "integer" {
		t.Errorf("Deployment spec.replicas type = %v, want [integer]", replicas.Type)
	}
	containers := s.Properties["spec"].Properties["template"].Properties["spec"].Properties["containers"]
	if containers.Items == nil || containers.Items.Schema.Properties["image"].Type == nil {
		t.Error("Deployment spec.template.spec.containers[].image is not populated")
	}
}

func TestResolverResolveSchemaNotFound(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		gvk  schema.GroupVersionKind
	}{
		{"unknown kind", schema.GroupVersionKind{Group: "apps", Version: "v1", Kind: "Widget"}},
		{"unknown version", schema.GroupVersionKind{Group: "apps", Version: "v9", Kind: "Deployment"}},
		{"unknown group", schema.GroupVersionKind{Group: "example.com", Version: "v1", Kind: "Pod"}},
		{"zero", schema.GroupVersionKind{}},
	}
	var r Resolver
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			_, err := r.ResolveSchema(tt.gvk)
			if !errors.Is(err, resolver.ErrSchemaNotFound) {
				t.Errorf("ResolveSchema(%v) error = %v, want %v", tt.gvk, err, resolver.ErrSchemaNotFound)
			}
		})
	}
}

func TestResolverConcurrent(t *testing.T) {
	t.Parallel()
	var r Resolver
	var wg sync.WaitGroup
	for range 8 {
		wg.Go(func() {
			if _, err := r.ResolveSchema(schema.GroupVersionKind{Version: "v1", Kind: "Pod"}); err != nil {
				t.Error(err)
			}
		})
	}
	wg.Wait()
}

// TestResolverFirstLoadIsFast bounds the first load by firstLoadBound, five
// times what it takes on an idle machine. The fastest of several loads is the
// cost of the work; one load also measures whatever else the machine was doing.
func TestResolverFirstLoadIsFast(t *testing.T) {
	// Not parallel: other tests would compete for the CPU.
	gvk := schema.GroupVersionKind{Version: "v1", Kind: "Pod"}
	// The core file is the largest, so it is the slowest first load.
	took := time.Duration(math.MaxInt64)
	for range 5 {
		var r Resolver
		start := time.Now()
		if _, err := r.ResolveSchema(gvk); err != nil {
			t.Fatal(err)
		}
		took = min(took, time.Since(start))
	}
	if took > firstLoadBound {
		t.Errorf("first ResolveSchema(v1 Pod) took %v, want under %v", took, firstLoadBound)
	} else {
		t.Logf("first ResolveSchema(v1 Pod) took %v, bound %v", took, firstLoadBound)
	}
}

// firstLoadBudget is the time allowed for the first load of a schema: the 50 ms
// of the issue.
const firstLoadBudget = 50 * time.Millisecond

// BenchmarkResolverFirstLoad fails when the first load takes longer than
// firstLoadBudget.
func BenchmarkResolverFirstLoad(b *testing.B) {
	gvk := schema.GroupVersionKind{Version: "v1", Kind: "Pod"}
	for b.Loop() {
		var r Resolver
		if _, err := r.ResolveSchema(gvk); err != nil {
			b.Fatal(err)
		}
	}
	if got := b.Elapsed() / time.Duration(b.N); got > firstLoadBudget {
		b.Errorf("first ResolveSchema(v1 Pod) took %v, want within %v", got, firstLoadBudget)
	}
}

func TestRESTMapperRESTMapping(t *testing.T) {
	t.Parallel()
	m, err := NewRESTMapper()
	if err != nil {
		t.Fatal(err)
	}
	tests := []struct {
		name     string
		resource schema.GroupVersionResource
		kind     schema.GroupVersionKind
		scope    meta.RESTScopeName
	}{
		{
			"deployments",
			schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "deployments"},
			schema.GroupVersionKind{Group: "apps", Version: "v1", Kind: "Deployment"},
			meta.RESTScopeNameNamespace,
		},
		{
			"pods",
			schema.GroupVersionResource{Version: "v1", Resource: "pods"},
			schema.GroupVersionKind{Version: "v1", Kind: "Pod"},
			meta.RESTScopeNameNamespace,
		},
		{
			"namespaces",
			schema.GroupVersionResource{Version: "v1", Resource: "namespaces"},
			schema.GroupVersionKind{Version: "v1", Kind: "Namespace"},
			meta.RESTScopeNameRoot,
		},
		{
			"nodes",
			schema.GroupVersionResource{Version: "v1", Resource: "nodes"},
			schema.GroupVersionKind{Version: "v1", Kind: "Node"},
			meta.RESTScopeNameRoot,
		},
		{
			"ingresses",
			schema.GroupVersionResource{Group: "networking.k8s.io", Version: "v1", Resource: "ingresses"},
			schema.GroupVersionKind{Group: "networking.k8s.io", Version: "v1", Kind: "Ingress"},
			meta.RESTScopeNameNamespace,
		},
		{
			"storageclasses",
			schema.GroupVersionResource{Group: "storage.k8s.io", Version: "v1", Resource: "storageclasses"},
			schema.GroupVersionKind{Group: "storage.k8s.io", Version: "v1", Kind: "StorageClass"},
			meta.RESTScopeNameRoot,
		},
		{
			"policies",
			schema.GroupVersionResource{Group: "admissionregistration.k8s.io", Version: "v1", Resource: "validatingadmissionpolicies"},
			schema.GroupVersionKind{Group: "admissionregistration.k8s.io", Version: "v1", Kind: "ValidatingAdmissionPolicy"},
			meta.RESTScopeNameRoot,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			gvk, err := m.KindFor(tt.resource)
			if err != nil || gvk != tt.kind {
				t.Errorf("KindFor(%v) = %v, %v, want %v", tt.resource, gvk, err, tt.kind)
			}
			mapping, err := m.RESTMapping(tt.kind.GroupKind(), tt.kind.Version)
			if err != nil {
				t.Fatalf("RESTMapping(%v) error: %v", tt.kind, err)
			}
			if mapping.Resource != tt.resource || mapping.Scope.Name() != tt.scope {
				t.Errorf("RESTMapping(%v) = %v in %s, want %v in %s", tt.kind, mapping.Resource, mapping.Scope.Name(), tt.resource, tt.scope)
			}
		})
	}
}

func TestRESTMapperKindsForWildcard(t *testing.T) {
	t.Parallel()
	m, err := NewRESTMapper()
	if err != nil {
		t.Fatal(err)
	}
	tests := []struct {
		name     string
		resource schema.GroupVersionResource
		want     []string
		wantErr  bool
	}{
		{
			"apps/v1",
			schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "*"},
			[]string{"apps/v1, Kind=ControllerRevision", "apps/v1, Kind=DaemonSet", "apps/v1, Kind=Deployment", "apps/v1, Kind=ReplicaSet", "apps/v1, Kind=StatefulSet"},
			false,
		},
		{"unknown group", schema.GroupVersionResource{Group: "example.com", Version: "v1", Resource: "*"}, nil, true},
		{"unknown version", schema.GroupVersionResource{Group: "apps", Version: "v9", Resource: "*"}, nil, true},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			kinds, err := m.KindsFor(tt.resource)
			if (err != nil) != tt.wantErr {
				t.Fatalf("KindsFor(%v) error = %v, want error %v", tt.resource, err, tt.wantErr)
			}
			var got []string
			for _, k := range kinds {
				got = append(got, k.String())
			}
			if fmt.Sprint(got) != fmt.Sprint(tt.want) {
				t.Errorf("KindsFor(%v) = %v, want %v", tt.resource, got, tt.want)
			}
		})
	}
	if _, err := m.KindFor(schema.GroupVersionResource{Group: "apps", Version: "v1", Resource: "*"}); err == nil {
		t.Error("KindFor(apps/v1 *) succeeded, want an ambiguity error")
	}
}

func TestEmbeddedFilesMatchSums(t *testing.T) {
	t.Parallel()
	b, err := os.ReadFile("sums.txt")
	if err != nil {
		t.Fatal(err)
	}
	lines := strings.Fields(string(b))
	if len(lines) == 0 {
		t.Fatal("sums.txt lists no files")
	}
	for i := 1; i < len(lines); i += 2 {
		name := lines[i]
		file := "data/" + strings.TrimSuffix(name, "_openapi.json") + ".json.gz"
		if _, err := fs.Stat(data, file); err != nil {
			t.Errorf("sums.txt lists %s, but %s is not embedded: %v", name, file, err)
		}
	}
}
