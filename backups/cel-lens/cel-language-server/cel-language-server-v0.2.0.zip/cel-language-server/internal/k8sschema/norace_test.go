//go:build !race

package k8sschema

import "time"

// firstLoadBound is the longest the first load may take: five times the 20 ms
// it takes on an idle machine.
const firstLoadBound = 100 * time.Millisecond
