# k8sschema

Kubernetes v1.37.0's OpenAPI v3 schemas, embedded in the binary, so kinds
resolve with no cluster and no network.

- `Resolver` is a `resolver.SchemaResolver`: `ResolveSchema` returns a kind's
  schema with every `$ref` populated, or an error wrapping
  `resolver.ErrSchemaNotFound`.
- `NewRESTMapper` returns a `meta.RESTMapper` that maps resources to kinds and
  scopes (`deployments` in `apps/v1` to `Deployment`, namespaced). A resource of
  `*` stands for every kind of the group and version.

## What is embedded

`data/` holds, for each group version the release serves, the `components` of
its OpenAPI v3 file, gzipped (`api__v1.json.gz`, `apis__apps__v1.json.gz`, ...),
and `resources.json`, an index of resources, kinds and scopes read from the
files' paths. `sums.txt` lists the SHA-256 of each file as Kubernetes publishes
it. The embedded data is 0.68 MB; a schema's first load takes about 17 ms
(`go test -bench . ./internal/k8sschema`).

## Regenerate

```sh
go generate ./internal/k8sschema
```

downloads the files named in `sums.txt` from
`https://raw.githubusercontent.com/kubernetes/kubernetes/<tag>/api/openapi-spec/v3/`,
fails if one does not match its sum, and rewrites `data/`. Running it again
changes nothing.

## Move to a new Kubernetes version

1. Set `defaultVersion` in `gen/main.go` to the new tag, such as `v1.38.0`.
2. `cd internal/k8sschema && go run ./gen -update-sums` lists the release's group version files through the
   GitHub API and rewrites `sums.txt`. Review the diff: new and dropped groups
   show there.
3. `go generate ./internal/k8sschema` rewrites `data/` and removes files of
   dropped groups.
4. Update the version in this README, then take the matching
   `k8s.io/apiserver`, `k8s.io/apimachinery` modules (`go get`, `go mod tidy`)
   so the CEL libraries and the schemas come from the same release.
5. `make check`.
