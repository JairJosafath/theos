//go:build race

package k8sschema

import "time"

// firstLoadBound is the longest the first load may take: five times the
// 120 ms it takes on an idle machine with the race detector.
const firstLoadBound = 600 * time.Millisecond
