package analysis

import (
	"fmt"
	"slices"
	"strings"
	"testing"

	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

const policyHead = `apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingAdmissionPolicy
metadata:
  name: demo
spec:
  matchConstraints:
    resourceRules:
      - apiGroups: ["apps"]
        apiVersions: ["v1"]
        operations: ["CREATE", "UPDATE"]
        resources: ["deployments"]
  matchConditions:
    - name: mc
      expression: %s
  variables:
    - name: replicas
      expression: object.spec.replicas
    - name: containers
      expression: object.spec.template.spec.containers
    - name: current
      expression: %s
  validations:
    - expression: %s
`

// policy puts expr, where | marks the cursor, in the validation of a policy;
// the other places hold "true".
func policy(expr string) string { return fmt.Sprintf(policyHead, "true", "1", expr) }

const crd = `apiVersion: apiextensions.k8s.io/v1
kind: CustomResourceDefinition
metadata:
  name: widgets.example.com
spec:
  group: example.com
  scope: Namespaced
  names:
    plural: widgets
    singular: widget
    kind: Widget
  versions:
    - name: v1
      served: true
      storage: true
      schema:
        openAPIV3Schema:
          type: object
          properties:
            spec:
              type: object
              description: The widget spec.
              properties:
                count:
                  type: integer
                  description: How many.
                tags:
                  type: array
                  items:
                    type: object
                    properties:
                      key:
                        type: string
                    x-kubernetes-validations:
                      - rule: %s
              x-kubernetes-validations:
                - rule: %s
`

// complete returns the items at the | in src.
func complete(t *testing.T, src string) []Item {
	t.Helper()
	i := strings.IndexByte(src, '|')
	if i < 0 {
		t.Fatal("no | in the source")
	}
	before := src[:i]
	pos := position.Position{Line: strings.Count(before, "\n"), Character: len(before) - strings.LastIndexByte(before, '\n') - 1}
	return Complete("test.yaml", []byte(before+src[i+1:]), pos)
}

func find(items []Item, label string) (Item, bool) {
	for _, it := range items {
		if it.Label == label {
			return it, true
		}
	}
	return Item{}, false
}

func labels(items []Item) []string {
	out := make([]string, len(items))
	for i, it := range items {
		out[i] = it.Label
	}
	return out
}

func TestCompleteItems(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		src  string
		want []Item // each must be among the items, in full
	}{
		{"field with type and description", policy("object.spec.|"), []Item{
			{Label: "replicas", Kind: Field, Detail: "int", Documentation: "Number of desired pods. This is a pointer to distinguish between explicit zero and not specified. Defaults to 1."},
			{Label: "template", Kind: Field, Detail: "Deployment.spec.template", Documentation: "PodTemplateSpec describes the data a pod should have when created from a template"},
		}},
		{"field prefix", policy("object.spec.rep|"), []Item{{Label: "replicas", Kind: Field, Detail: "int"}}},
		{"after a call", policy("object.spec.template.spec.containers.filter(c, true)[0].|"), []Item{{Label: "image", Kind: Field}}},
		{"iteration variable", policy("object.spec.template.spec.containers.all(c, c.|"), []Item{
			{Label: "image", Kind: Field, Detail: "string"}, {Label: "name", Kind: Field, Detail: "string"},
		}},
		{"iteration variable after other arguments", policy("object.spec.template.spec.containers.map(c, c.name, c.|"), []Item{{Label: "image", Kind: Field}}},
		{"nested macros", policy("object.spec.template.spec.containers.exists(c, c.ports.all(p, p.|))"), []Item{{Label: "containerPort", Kind: Field, Detail: "int"}}},
		{"policy variables", policy("variables.|"), []Item{
			{Label: "replicas", Kind: Field, Detail: "int"},
			{Label: "containers", Kind: Field, Detail: "list(Deployment.spec.template.spec.containers.@idx)"},
		}},
		{"macro on a list", policy("object.spec.template.spec.containers.|"), []Item{
			{Label: "all", Kind: Keyword, Detail: "macro", Snippet: "all(${1:x}, ${2})"},
			{Label: "exists", Kind: Keyword, Detail: "macro", Snippet: "exists(${1:x}, ${2})"},
			{Label: "map", Kind: Keyword, Detail: "macro", Snippet: "map(${1:x}, ${2})"},
		}},
		{"functions on a string", policy("object.metadata.name.|"), []Item{{Label: "startsWith", Kind: Function, Detail: "string.startsWith(string) -> bool"}}},
		{"start: variables", policy("|"), []Item{
			{Label: "object", Kind: Variable, Detail: "Deployment", Documentation: variableDocs["object"]},
			{Label: "oldObject", Kind: Variable, Detail: "Deployment", Documentation: variableDocs["oldObject"]},
			{Label: "request", Kind: Variable, Detail: "kubernetes.AdmissionRequest", Documentation: variableDocs["request"]},
			{Label: "params", Kind: Variable, Detail: "dyn", Documentation: variableDocs["params"]},
			{Label: "namespaceObject", Kind: Variable, Detail: "kubernetes.Namespace", Documentation: variableDocs["namespaceObject"]},
			{Label: "variables", Kind: Variable, Documentation: variableDocs["variables"]},
		}},
		{"start: functions and macros", policy("size(object.metadata.name) > 1 && |"), []Item{
			{Label: "size", Kind: Function},
			{Label: "has", Kind: Keyword, Detail: "macro", Snippet: "has(${1})"},
		}},
		{"start: iteration variable", policy("object.spec.template.spec.containers.all(c, c.name != '' && |"), []Item{{Label: "c", Kind: Variable}}},
		{"crd self", fmt.Sprintf(crd, "true", "self.|"), []Item{
			{Label: "count", Kind: Field, Detail: "int", Documentation: "How many."},
			{Label: "tags", Kind: Field},
		}},
		{"crd self in a list item", fmt.Sprintf(crd, "self.|", "true"), []Item{{Label: "key", Kind: Field, Detail: "string"}}},
		{"crd start", fmt.Sprintf(crd, "true", "|"), []Item{
			{Label: "self", Kind: Variable, Documentation: variableDocs["self"]},
			{Label: "oldSelf", Kind: Variable, Documentation: variableDocs["oldSelf"]},
		}},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			got := complete(t, tt.src)
			for _, want := range tt.want {
				it, ok := find(got, want.Label)
				if want.Kind == Keyword && want.Label == "map" {
					it, ok = findSnippet(got, want.Snippet)
				}
				switch {
				case !ok:
					t.Errorf("Complete(%q) has no %q, want it; got %v", tt.name, want.Label, labels(got))
				case it.Kind != want.Kind || (want.Detail != "" && it.Detail != want.Detail) ||
					(want.Documentation != "" && it.Documentation != want.Documentation) || it.Snippet != want.Snippet:
					t.Errorf("Complete(%q) item %s = %+v, want %+v", tt.name, want.Label, it, want)
				}
			}
		})
	}
}

func findSnippet(items []Item, snippet string) (Item, bool) {
	for _, it := range items {
		if it.Snippet == snippet {
			return it, true
		}
	}
	return Item{}, false
}

func TestCompleteScope(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name    string
		src     string
		want    []string // variables, by name, and only these
		exclude string   // a label that must not be among the items
	}{
		{"validation", policy("|"), []string{"authorizer", "namespaceObject", "object", "oldObject", "params", "request", "variables"}, "all"},
		{"match condition", fmt.Sprintf(policyHead, "|", "1", "true"), []string{"authorizer", "namespaceObject", "object", "oldObject", "request"}, "variables"},
		{"crd rule in a list", fmt.Sprintf(crd, "|", "true"), []string{"self"}, "oldSelf"},
		{"webhook", `apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingWebhookConfiguration
metadata:
  name: hook
webhooks:
  - name: a.example.com
    matchConditions:
      - name: mc
        expression: |
`, []string{"authorizer", "namespaceObject", "object", "oldObject", "request"}, "params"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			var got []string
			items := complete(t, tt.src)
			for _, it := range items {
				if it.Kind == Variable {
					got = append(got, it.Label)
				}
			}
			if strings.Join(got, " ") != strings.Join(tt.want, " ") {
				t.Errorf("variables = %v, want %v", got, tt.want)
			}
			if _, ok := find(items, tt.exclude); ok {
				t.Errorf("items have %q, want none", tt.exclude)
			}
		})
	}
}

func TestCompleteNothing(t *testing.T) {
	t.Parallel()
	tests := []struct {
		name string
		src  string
	}{
		{"outside CEL", policy("true") + "    # |\n"},
		{"in metadata", strings.Replace(policy("true"), "name: demo", "name: de|mo", 1)},
		{"in a string", policy("object.spec.replicas == 'a.|'")},
		{"in a comment", policy("object.spec.replicas == 1 // see object.|")},
		{"unknown receiver", policy("object.nothing.|")},
		{"unknown variable", policy("nothing.|")},
		{"a dot alone", policy(".|")},
		{"yaml syntax error", policy("object.|") + "  : [\n"},
		{"a file that is not Kubernetes", "a: object.|\n"},
		{"empty", "|"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			t.Parallel()
			if got := complete(t, tt.src); len(got) != 0 {
				t.Errorf("Complete = %v, want no items", labels(got))
			}
		})
	}
}

func TestCompleteBadPosition(t *testing.T) {
	t.Parallel()
	if got := Complete("x.yaml", []byte(policy("true")), position.Position{Line: 999}); got != nil {
		t.Errorf("Complete past the end = %v, want nil", labels(got))
	}
}

func TestCompleteQuotedExpression(t *testing.T) {
	t.Parallel()
	src := strings.Replace(policy("|"), "    - expression: |", `    - expression: "object.spec.|"`, 1)
	if _, ok := find(complete(t, src), "replicas"); !ok {
		t.Error("no replicas after object.spec. in a quoted expression")
	}
	src = strings.Replace(policy("|"), "    - expression: |", "    - expression: >-\n        object.spec.\n        |", 1)
	if got := complete(t, src); len(got) != 0 {
		t.Errorf("after a folded line break, got %v, want none", labels(got))
	}
}

// BenchmarkComplete completes in a policy of about 1,000 lines.
func BenchmarkComplete(b *testing.B) {
	var pad strings.Builder
	for i := range 50 {
		fmt.Fprintf(&pad, "    - expression: object.spec.replicas <= %d && object.metadata.name.startsWith('a')\n", i)
		pad.WriteString(strings.Repeat("      # padding\n", 17))
	}
	src := policy("object.spec.|") + pad.String()
	i := strings.IndexByte(src, '|')
	text := []byte(src[:i] + src[i+1:])
	pos := position.Position{Line: strings.Count(src[:i], "\n"), Character: len("    - expression: object.spec.")}
	for b.Loop() {
		Complete("bench.yaml", text, pos)
	}
}

func TestCompleteIterationOverPolicyVariable(t *testing.T) {
	t.Parallel()
	want := labels(complete(t, policy("object.spec.template.spec.containers.all(c, c.|")))
	got := labels(complete(t, policy("variables.containers.all(x, x.|")))
	if !slices.Equal(got, want) {
		t.Errorf("Complete(variables.containers.all(x, x.) = %v, want the fields of the full path %v", got, want)
	}
	for _, f := range []string{"args", "command", "env", "image"} {
		if !slices.Contains(got, f) {
			t.Errorf("Complete(variables.containers.all(x, x.) has no %q, want it; got %v", f, got)
		}
	}
}

func TestCompleteNoInternalNames(t *testing.T) {
	t.Parallel()
	items := complete(t, policy("|"))
	for _, it := range items {
		if strings.HasPrefix(it.Label, "_") {
			t.Errorf("Complete(start of expression) has %q, want no name starting with _", it.Label)
		}
	}
	for _, name := range []string{"authorizer", "namespaceObject", "object", "oldObject", "request", "bool"} {
		if _, ok := find(items, name); !ok {
			t.Errorf("Complete(start of expression) has no %q, want it", name)
		}
	}
}
