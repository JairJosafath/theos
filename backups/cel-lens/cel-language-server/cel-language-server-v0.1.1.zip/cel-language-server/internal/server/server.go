// Package server is the language server: it speaks LSP over a
// [jsonrpc.Conn], keeps the open documents in memory and publishes the CEL
// diagnostics of [analysis.Analyzer.Diagnose] for the YAML ones. It also answers
// completion requests with [analysis.Complete] and hover requests with
// [analysis.Explain].
package server

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log/slog"
	"sync"
	"time"

	"c4factory.local/cel-lens/cel-language-server/internal/analysis"
	"c4factory.local/cel-lens/cel-language-server/internal/jsonrpc"
	"c4factory.local/cel-lens/cel-language-server/internal/lsp"
	"c4factory.local/cel-lens/cel-language-server/internal/position"
)

// Name is the server's name in the initialize reply.
const Name = "cel-language-server"

// DefaultDebounce is how long a document must stay unchanged before its
// diagnostics are published.
const DefaultDebounce = 100 * time.Millisecond

// ErrNoShutdown is what [Server.Run] returns when the client exits, or the
// stream ends, without a shutdown request first. The spec makes that exit code 1.
var ErrNoShutdown = errors.New("exit without shutdown")

// Server serves one client. Make it with [New]; it serves one [Server.Run].
type Server struct {
	// Debounce is how long a document must stay unchanged before its
	// diagnostics are published. Set it before Run.
	Debounce time.Duration

	version string
	log     *slog.Logger
	conn    *jsonrpc.Conn

	// Run's goroutine only.
	initialized bool
	shutdown    bool

	analyzer analysis.Analyzer // keeps the CEL environments between checks

	mu      sync.Mutex // guards the fields below and orders publishing
	docs    map[string]*document
	closed  bool
	running sync.WaitGroup // publish calls past their closed check
}

// document is an open document. gen counts its changes, so a timer that fires
// for an older text knows it is stale.
type document struct {
	languageID string
	version    int
	text       string
	gen        int
	timer      *time.Timer
}

// New returns a Server that reports version in its server info and logs to log.
func New(version string, log *slog.Logger) *Server {
	return &Server{Debounce: DefaultDebounce, version: version, log: log, docs: map[string]*document{}}
}

// Run serves the client over r and w until it exits. It returns nil after
// shutdown and exit, [ErrNoShutdown] when the client exits or the stream ends
// before shutdown, and the error that broke the stream or ctx.Err() otherwise.
// A malformed message is logged and skipped. Cancelling ctx stops Run after the
// message being read; to stop a blocked read, close r. When Run returns, no
// goroutine it started is left, and it writes nothing more to w.
func (s *Server) Run(ctx context.Context, r io.Reader, w io.Writer) error {
	s.conn = jsonrpc.NewConn(r, w)
	defer s.stop()
	ctx, cancel := context.WithCancel(ctx)
	defer cancel() // before stop, so that checks in flight end early
	for {
		if err := ctx.Err(); err != nil {
			return err
		}
		msg, err := s.conn.Read()
		switch {
		case errors.Is(err, jsonrpc.ErrMalformed):
			s.log.Warn("skip message", "err", err)
			continue
		case errors.Is(err, io.EOF):
			return s.exitStatus()
		case err != nil:
			return fmt.Errorf("serve: %w", err)
		}
		if exit := s.handle(ctx, msg); exit {
			return s.exitStatus()
		}
	}
}

func (s *Server) exitStatus() error {
	if s.shutdown {
		return nil
	}
	return ErrNoShutdown
}

// stop cancels the pending timers and waits for the publishing in flight.
func (s *Server) stop() {
	s.mu.Lock()
	s.closed = true
	for _, d := range s.docs {
		if d.timer != nil {
			d.timer.Stop()
		}
	}
	s.mu.Unlock()
	s.running.Wait()
}

// handle serves one message and reports whether it was exit.
func (s *Server) handle(ctx context.Context, msg *jsonrpc.Message) (exit bool) {
	if msg.Method == lsp.MethodExit {
		return true
	}
	result, err := s.dispatch(ctx, msg)
	if msg.IsNotification() {
		if err != nil {
			s.log.Warn("notification failed", "method", msg.Method, "err", err)
		}
		return false
	}
	var rpcErr *jsonrpc.Error
	switch {
	case errors.As(err, &rpcErr):
		err = s.conn.ReplyError(msg.ID, rpcErr)
	case err != nil:
		err = s.conn.ReplyError(msg.ID, &jsonrpc.Error{Code: jsonrpc.CodeInvalidRequest, Message: err.Error()})
	default:
		err = s.conn.Reply(msg.ID, result)
	}
	if err != nil {
		s.log.Error("reply", "method", msg.Method, "err", err)
	}
	return false
}

func (s *Server) dispatch(ctx context.Context, msg *jsonrpc.Message) (any, error) {
	switch msg.Method {
	case lsp.MethodInitialize:
		s.initialized = true
		return lsp.InitializeResult{
			Capabilities: lsp.ServerCapabilities{
				TextDocumentSync:   lsp.TextDocumentSyncOptions{OpenClose: true, Change: lsp.SyncFull},
				CompletionProvider: lsp.CompletionOptions{TriggerCharacters: []string{"."}},
				HoverProvider:      true,
			},
			ServerInfo: lsp.ServerInfo{Name: Name, Version: s.version},
		}, nil
	case lsp.MethodInitialized, lsp.MethodCancelRequest:
		// Requests finish before the next message is read, so there is
		// nothing to cancel.
		return nil, nil
	}
	if !s.initialized {
		return nil, &jsonrpc.Error{Code: jsonrpc.CodeServerNotInitialized, Message: "server not initialized"}
	}
	if s.shutdown {
		return nil, &jsonrpc.Error{Code: jsonrpc.CodeInvalidRequest, Message: "server is shut down"}
	}
	switch msg.Method {
	case lsp.MethodShutdown:
		s.shutdown = true
		return nil, nil
	case lsp.MethodCompletion:
		var p lsp.CompletionParams
		if err := decode(msg, &p); err != nil {
			return nil, err
		}
		return s.complete(p), nil
	case lsp.MethodHover:
		var p lsp.HoverParams
		if err := decode(msg, &p); err != nil {
			return nil, err
		}
		return s.hover(p), nil
	case lsp.MethodDidOpen:
		var p lsp.DidOpenParams
		if err := decode(msg, &p); err != nil {
			return nil, err
		}
		s.open(ctx, p.TextDocument)
		return nil, nil
	case lsp.MethodDidChange:
		var p lsp.DidChangeParams
		if err := decode(msg, &p); err != nil {
			return nil, err
		}
		s.change(ctx, p)
		return nil, nil
	case lsp.MethodDidClose:
		var p lsp.DidCloseParams
		if err := decode(msg, &p); err != nil {
			return nil, err
		}
		s.closeDoc(p.TextDocument.URI)
		return nil, nil
	}
	if msg.IsNotification() {
		return nil, nil // unknown notifications are ignored
	}
	return nil, &jsonrpc.Error{Code: jsonrpc.CodeMethodNotFound, Message: "method not found: " + msg.Method}
}

func decode(msg *jsonrpc.Message, v any) error {
	if err := json.Unmarshal(msg.Params, v); err != nil {
		return &jsonrpc.Error{Code: jsonrpc.CodeInvalidParams, Message: fmt.Sprintf("%s: %v", msg.Method, err)}
	}
	return nil
}

func (s *Server) open(ctx context.Context, item lsp.TextDocumentItem) {
	s.mu.Lock()
	defer s.mu.Unlock()
	if old := s.docs[item.URI]; old != nil && old.timer != nil {
		old.timer.Stop()
	}
	d := &document{languageID: item.LanguageID, version: item.Version, text: item.Text}
	s.docs[item.URI] = d
	s.schedule(ctx, item.URI, d)
}

func (s *Server) change(ctx context.Context, p lsp.DidChangeParams) {
	s.mu.Lock()
	defer s.mu.Unlock()
	d := s.docs[p.TextDocument.URI]
	if d == nil {
		s.log.Warn("change of a document that is not open", "uri", p.TextDocument.URI)
		return
	}
	if len(p.ContentChanges) == 0 {
		s.log.Warn("change without content", "uri", p.TextDocument.URI)
		return
	}
	d.version = p.TextDocument.Version
	d.text = p.ContentChanges[len(p.ContentChanges)-1].Text
	s.schedule(ctx, p.TextDocument.URI, d)
}

func (s *Server) closeDoc(uri string) {
	s.mu.Lock()
	defer s.mu.Unlock()
	d := s.docs[uri]
	if d == nil {
		return
	}
	if d.timer != nil {
		d.timer.Stop()
	}
	delete(s.docs, uri)
	if d.languageID == "yaml" {
		s.publishLocked(uri, nil, nil)
	}
}

// yamlText returns the text of an open YAML document, and "" for any other.
func (s *Server) yamlText(uri string) string {
	s.mu.Lock()
	defer s.mu.Unlock()
	if d := s.docs[uri]; d != nil && d.languageID == "yaml" {
		return d.text
	}
	return ""
}

// hover answers a hover request: nil, which is null on the wire, outside CEL
// and in documents that are not open or not YAML, so that other extensions'
// hovers stay as they are.
func (s *Server) hover(p lsp.HoverParams) *lsp.Hover {
	text := s.yamlText(p.TextDocument.URI)
	if text == "" {
		return nil
	}
	pos := position.Position{Line: p.Position.Line, Character: p.Position.Character}
	h := analysis.Explain(p.TextDocument.URI, []byte(text), pos)
	if h == nil {
		return nil
	}
	md := "```cel\n" + h.Signature + "\n```"
	if h.Documentation != "" {
		md += "\n\n" + h.Documentation
	}
	return &lsp.Hover{
		Contents: lsp.MarkupContent{Kind: lsp.MarkupKindMarkdown, Value: md},
		Range: lsp.Range{
			Start: lsp.Position{Line: h.Range.Start.Line, Character: h.Range.Start.Character},
			End:   lsp.Position{Line: h.Range.End.Line, Character: h.Range.End.Character},
		},
	}
}

// complete answers a completion request. Documents that are not open or not
// YAML have no items, so that other extensions' completions stay as they are.
func (s *Server) complete(p lsp.CompletionParams) []lsp.CompletionItem {
	text := s.yamlText(p.TextDocument.URI)
	items := []lsp.CompletionItem{}
	if text == "" {
		return items
	}
	pos := position.Position{Line: p.Position.Line, Character: p.Position.Character}
	for _, it := range analysis.Complete(p.TextDocument.URI, []byte(text), pos) {
		items = append(items, completionItem(it))
	}
	return items
}

func completionItem(it analysis.Item) lsp.CompletionItem {
	out := lsp.CompletionItem{Label: it.Label, Kind: itemKind(it.Kind), Detail: it.Detail, Documentation: it.Documentation}
	if it.Snippet != "" {
		out.InsertText = it.Snippet
		out.InsertTextFormat = lsp.InsertTextFormatSnippet
	}
	return out
}

// itemKind is the LSP completion kind of an analysis item kind.
func itemKind(k analysis.ItemKind) int {
	switch k {
	case analysis.Field:
		return lsp.KindField
	case analysis.Variable:
		return lsp.KindVariable
	case analysis.Function:
		return lsp.KindFunction
	case analysis.Keyword:
		return lsp.KindKeyword
	}
	return 0
}

// schedule arms the debounce timer of a YAML document. s.mu must be held.
func (s *Server) schedule(ctx context.Context, uri string, d *document) {
	if d.timer != nil {
		d.timer.Stop()
	}
	if d.languageID != "yaml" || s.closed {
		return
	}
	d.gen++
	gen := d.gen
	d.timer = time.AfterFunc(s.Debounce, func() { s.publish(ctx, uri, d, gen) })
}

// publish checks d as it was at generation gen and publishes the result,
// unless the document changed or closed meanwhile.
func (s *Server) publish(ctx context.Context, uri string, d *document, gen int) {
	s.mu.Lock()
	if s.closed || s.docs[uri] != d || d.gen != gen {
		s.mu.Unlock()
		return
	}
	s.running.Add(1)
	text, version := d.text, d.version
	s.mu.Unlock()
	defer s.running.Done()

	found, err := s.analyzer.Diagnose(ctx, uri, []byte(text))
	if err != nil {
		return // cancelled: the server is stopping
	}

	s.mu.Lock()
	defer s.mu.Unlock()
	if s.closed || s.docs[uri] != d || d.gen != gen {
		return
	}
	s.publishLocked(uri, &version, found)
}

// publishLocked sends the diagnostics of a document; no found means none. s.mu
// must be held so that a publish never follows the clearing of a closed document.
func (s *Server) publishLocked(uri string, version *int, found []analysis.Diagnostic) {
	out := make([]lsp.Diagnostic, 0, len(found))
	for _, f := range found {
		out = append(out, lsp.Diagnostic{
			Range: lsp.Range{
				Start: lsp.Position{Line: f.Range.Start.Line, Character: f.Range.Start.Character},
				End:   lsp.Position{Line: f.Range.End.Line, Character: f.Range.End.Character},
			},
			Severity: int(f.Severity),
			Source:   f.Source,
			Message:  f.Message,
		})
	}
	err := s.conn.Notify(lsp.MethodPublishDiagnostic, lsp.PublishDiagnosticsParams{URI: uri, Version: version, Diagnostics: out})
	if err != nil {
		s.log.Error("publish diagnostics", "uri", uri, "err", err)
	}
}
