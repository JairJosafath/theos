import { Buffer } from 'node:buffer';
// Packages one .vsix per target into dist/ (linux-x64 only by default), each bundling the server pinned
// in server.json at server/<target>/. Run by `make dist` as `npm run dist`.
//
// Targets: linux-x64, linux-arm64, darwin-x64, darwin-arm64, win32-x64.
// Set TARGETS to a comma-separated list for others, for example
// `TARGETS=linux-x64,darwin-arm64 make dist`.
//
// The server is downloaded from the pinned release, checked against that
// release's SHA256SUMS, and cached in .cache/server/<version>/: a cached file
// is used again only while it still matches the cached SHA256SUMS.
import { execFileSync } from 'node:child_process';
import { chmod, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { env, stdout } from 'node:process';

import {
  assetUrl,
  CHECKSUMS_ASSET,
  parseChecksums,
  parseServerPin,
  selectTargets,
  verifiedAsset,
} from '../src/server_release.ts';

const targets = selectTargets(env.TARGETS);
const pin = parseServerPin(await readFile('server.json', 'utf8'));
const { version } = JSON.parse(await readFile('package.json', 'utf8'));
const cache = join('.cache', 'server', pin.version);
const log = (message) => stdout.write(`${message}\n`);

async function download(asset) {
  const url = assetUrl(pin, asset);
  log(`download ${url}`);
  const response = await globalThis.fetch(url);
  if (!response.ok) {
    throw new Error(
      `${url}: ${response.status} ${response.statusText}. Is ${pin.version} released?`,
    );
  }
  return new Uint8Array(await response.arrayBuffer());
}

async function cached(asset) {
  try {
    return new Uint8Array(await readFile(join(cache, asset)));
  } catch {
    return undefined;
  }
}

const io = {
  cached,
  download,
  store: (asset, content) => writeFile(join(cache, asset), content),
};

await mkdir(cache, { recursive: true });
// A release is pinned by its tag, so cached checksums stay valid and a rebuild
// works offline.
let checksums = await cached(CHECKSUMS_ASSET);
if (checksums === undefined) {
  checksums = await download(CHECKSUMS_ASSET);
  await writeFile(join(cache, CHECKSUMS_ASSET), checksums);
}
const sums = parseChecksums(Buffer.from(checksums).toString('utf8'));

await mkdir('dist', { recursive: true });
try {
  for (const { target, asset, file } of targets) {
    const content = await verifiedAsset(pin, asset, sums, io);
    await rm('server', { recursive: true, force: true });
    await mkdir(join('server', target), { recursive: true });
    const bundled = join('server', target, file);
    await writeFile(bundled, content);
    await chmod(bundled, 0o755);
    const out = join('dist', `vscode-extension-${target}-${version}.vsix`);
    execFileSync(
      join('node_modules', '.bin', 'vsce'),
      [
        'package',
        '--no-dependencies',
        '--skip-license',
        '--allow-missing-repository',
        '--target',
        target,
        '--out',
        out,
      ],
      { stdio: 'inherit' },
    );
  }
} finally {
  await rm('server', { recursive: true, force: true });
}
