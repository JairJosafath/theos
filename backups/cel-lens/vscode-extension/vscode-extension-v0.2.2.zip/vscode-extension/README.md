# CEL Lens for VS Code

CEL language support for Kubernetes YAML in VS Code: errors, completion and
documentation for the CEL in admission policies and CRD validation rules.

## What it does

CEL Lens finds the CEL in Kubernetes YAML and checks it the way the API server
would. It starts the CEL language server for YAML files and shows its errors at
the line and column of the expression, and it highlights the CEL in the file.
It works offline: the server embeds the Kubernetes schemas and needs no cluster
and no network. It only answers inside CEL, so it stays out of the way of other
YAML tooling, such as schema validation.

The server recognises these kinds by `apiVersion` and `kind`, with no markers,
file names or settings:

| Kind                                                                                                 | Keys holding CEL                                                                                                                                                       |
| ---------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `ValidatingAdmissionPolicy` (`admissionregistration.k8s.io/v1`, `v1beta1`)                           | `spec.matchConditions[].expression`, `spec.variables[].expression`, `spec.validations[].expression` and `messageExpression`, `spec.auditAnnotations[].valueExpression` |
| `ValidatingWebhookConfiguration`, `MutatingWebhookConfiguration` (`admissionregistration.k8s.io/v1`) | `matchConditions[].expression` of each webhook                                                                                                                         |
| `CustomResourceDefinition` (`apiextensions.k8s.io/v1`)                                               | `x-kubernetes-validations[].rule` and `messageExpression` in each version's schema                                                                                     |

Other kinds, such as Kyverno policies, are not understood yet; the highlighting
below still colours their `expression` and `rule` keys.

## Install

1. Download `vscode-extension-linux-x64-<version>.vsix` from the extension's
   [releases](http://gitea.gitea.svc.cluster.local:3000/cel-lens/vscode-extension/releases)
   on Gitea. A release has only the `linux-x64` package, and it includes the
   language server. For another platform (`linux-arm64`, `darwin-x64`,
   `darwin-arm64` or `win32-x64`), build its package with
   `TARGETS=<platform> make dist`; `TARGETS` takes a comma-separated list.
2. Install it: `code --install-extension vscode-extension-linux-x64-<version>.vsix`,
   or run **Extensions: Install from VSIX...** in VS Code.

On other platforms (such as `win32-arm64`), install the server yourself.
Download the file for your platform from the server's
[releases](http://gitea.gitea.svc.cluster.local:3000/cel-lens/cel-language-server/releases):
`cel-language-server_<os>_<arch>` (`.exe` on Windows) for `linux`, `darwin` and
`windows` on `amd64` and `arm64`, next to `SHA256SUMS`. Make it executable, then
either rename it to `cel-language-server` (`cel-language-server.exe` on Windows)
and put it on your `PATH`, or set `celLens.server.path` to the downloaded file.
The same applies if you want a different server than the bundled one.

**Compatible server:** `cel-language-server` v0.1.0 or later. The extension
relies on `serve --stdio`, and on the server's completion (triggered by `.`) and
hover documentation. Older builds, and a `dev` build from source, are not
covered by this promise; check with `cel-language-server --version`.

Opening a YAML file starts the server (`cel-language-server serve --stdio`) for
saved and untitled YAML documents. The binary is looked up in this order: the
`celLens.server.path` setting, a binary bundled in the extension at
`server/<platform>-<arch>/`, then `cel-language-server` on `PATH`. The "CEL Lens"
output channel says which one is used. A relative `celLens.server.path` resolves
against the first workspace folder; an absolute one is used as it is. With no
folder open, a relative path is not started: you get the not-found error, and
the output says the path is relative and no folder is open. When the first
workspace folder changes and the path is relative, the server restarts.

### Highlighting

CEL is highlighted in YAML before, and without, the server. The grammar covers
the values of the keys that hold CEL in Kubernetes kinds: `expression`,
`messageExpression`, `valueExpression` and `rule`, as plain, quoted, literal
(`|`) and folded (`>`) scalars, and nowhere else. The keys are matched by name
only: the colour does not tell you the value is CEL. The server decides what
really is CEL, and reports its errors.

### Settings

| Setting                | Default | Meaning                                                                                                                                          |
| ---------------------- | ------- | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| `celLens.enable`       | `true`  | Run the language server. Changing it starts or stops the server, no reload.                                                                      |
| `celLens.server.path`  | `""`    | Path to the `cel-language-server` binary. Relative: from the first workspace folder. Empty: bundled, then PATH. Ignored in untrusted workspaces. |
| `celLens.trace.server` | `"off"` | `off`, `messages` or `verbose`: trace the protocol in the "CEL Lens" channel.                                                                    |

### Commands

- **CEL Lens: Restart Server** restarts the language server, looking up the binary again.
- **CEL Lens: Show Output** opens the "CEL Lens" output channel.

### Status

While a YAML editor is active, the status bar shows the server's state: starting,
running, not found, failed (the reason is in the tooltip) or disabled. Click it to open the
"CEL Lens" output channel; the tooltip links to **Show Output** and **Restart Server**. Changing `celLens.enable` or `celLens.server.path`
restarts or stops the server without reloading the window.

## Troubleshooting

- **See what happened.** Run **CEL Lens: Show Output**, or click the status item.
  The "CEL Lens" channel logs which server binary was used and why a start failed.
- **The status item shows an error.** Hover it for the reason. If the binary was
  not found, install the server (see Install) or set `celLens.server.path`, then
  run **CEL Lens: Restart Server**.
- **The binary is not found though `celLens.server.path` is set.** In an
  untrusted workspace VS Code ignores that setting, so the extension falls back
  to the bundled binary and `PATH`. Trust the workspace (**Workspaces: Manage
  Workspace Trust**), then run **CEL Lens: Restart Server**.
- **Nothing is reported.** Check the status item says running, and that the
  document is a YAML file of a kind in the table above.
- **Trace the protocol.** Set `celLens.trace.server` to `messages`, or `verbose`
  for the message bodies, and read the "CEL Lens" channel.
- **Report a problem** in the extension's
  [issues](http://gitea.gitea.svc.cluster.local:3000/cel-lens/vscode-extension/issues)
  with the extension and server versions (`cel-language-server --version`), the
  YAML that shows it (trimmed), the output channel's log, and a trace if the
  problem is in the conversation with the server.

## Develop

Open the repository in its devcontainer, which has Node 24 and the Go toolchain.

```sh
npm ci               # install the exact tools in package-lock.json
npm run build        # bundle src/ into out/extension.js
npm test             # unit tests with vitest; no VS Code needed
make check           # what CI runs: format, lint, type check, test, package
make dist            # dist/vscode-extension-linux-x64-<version>.vsix, with the server; TARGETS=a,b for others
make help            # every target
```

## Layout

- `src/extension.ts` activates the extension: it starts the language client, registers
  the restart command and puts every registration in `context.subscriptions`.
- `src/server_path.ts` is the pure lookup of the server binary.
- `src/server_state.ts` is the pure state of the server and its status bar text.
- `src/*.ts` are the extension's modules. Keep logic in modules that don't import
  `vscode`, so plain unit tests cover it; tests sit next to them as `*.test.ts`.
- `test/vscode.ts` stands in for the `vscode` module in unit tests
  (`vitest.config.mts` points `vscode` at it).
- `syntaxes/` holds the CEL grammar and its injection into YAML; `test/grammar/`
  has their tests, which `npm test` runs with `vscode-tmgrammar-test`.
- `server.json` pins the server release that `make dist` bundles; to upgrade, change
  its `version`. `scripts/dist.mjs` downloads it, verifies it against `SHA256SUMS`,
  caches it in `.cache/` and packages each platform; `src/server_release.ts` is its
  pure part.
- `esbuild.mjs` bundles into `out/`; `.vscodeignore` keeps everything else out of
  the `.vsix`.

Read `AGENTS.md` before changing anything: it is the rulebook, for people and agents.
