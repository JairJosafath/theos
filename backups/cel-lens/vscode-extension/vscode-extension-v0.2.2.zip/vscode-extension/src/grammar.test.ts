import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { afterEach, describe, expect, it } from 'vitest';

const ROOT = fileURLToPath(new URL('..', import.meta.url));

const scratchDirs: string[] = [];

afterEach(() => {
  for (const dir of scratchDirs.splice(0)) {
    rmSync(dir, { recursive: true, force: true });
  }
});

function runTool(...extraFixtures: string[]): { status: number | null; output: string } {
  const result = spawnSync('npm', ['run', '--silent', 'test:grammar', '--', ...extraFixtures], {
    cwd: ROOT,
    encoding: 'utf8',
  });
  return { status: result.status, output: result.stdout + result.stderr };
}

describe('grammar tests', () => {
  it('exit with status 0 for the CEL grammar and its injection into YAML', () => {
    const { status, output } = runTool();

    expect(status, output).toBe(0);
  });

  it('exit with a non-zero status for a fixture that asserts the wrong scope', () => {
    const dir = mkdtempSync(join(tmpdir(), 'cel-lens-grammar-'));
    scratchDirs.push(dir);
    const fixture = join(dir, 'failing.yaml.test');
    writeFileSync(
      fixture,
      [
        '# SYNTAX TEST "source.yaml" "deliberately failing"',
        'expression: object.spec.replicas > 0',
        '# <---------- keyword.control.not.a.real.scope',
        '',
      ].join('\n'),
    );

    const { status } = runTool(fixture);

    expect(status).not.toBe(0);
  });
});
