import { describe, expect, it } from 'vitest';

import {
  findServer,
  isRelativeServerPath,
  type ServerLocation,
  type ServerNotFound,
  type ServerLookup,
} from './server_path';

interface Case {
  name: string;
  platform: string;
  arch: string;
  extensionPath: string;
  pathEnv: string | undefined;
  setting: string;
  workspaceFolder?: string;
  files: string[];
  want: ServerLocation | ServerNotFound;
}

const LINUX = {
  platform: 'linux',
  arch: 'x64',
  extensionPath: '/ext',
  pathEnv: '/usr/bin:/opt/bin',
};
const MAC = { platform: 'darwin', arch: 'arm64', extensionPath: '/ext', pathEnv: '/usr/local/bin' };
const WINDOWS = {
  platform: 'win32',
  arch: 'x64',
  extensionPath: 'C:\\ext',
  pathEnv: 'C:\\Windows;C:\\tools',
};

const cases: Case[] = [
  {
    name: 'linux: the setting wins over everything',
    ...LINUX,
    setting: '/custom/cel',
    files: ['/ext/server/linux-x64/cel-language-server', '/usr/bin/cel-language-server'],
    want: { path: '/custom/cel', source: 'setting' },
  },
  {
    name: 'linux: a blank setting counts as unset',
    ...LINUX,
    setting: '  ',
    files: ['/ext/server/linux-x64/cel-language-server'],
    want: { path: '/ext/server/linux-x64/cel-language-server', source: 'bundled' },
  },
  {
    name: 'linux: the bundled binary wins over PATH',
    ...LINUX,
    setting: '',
    files: ['/ext/server/linux-x64/cel-language-server', '/usr/bin/cel-language-server'],
    want: { path: '/ext/server/linux-x64/cel-language-server', source: 'bundled' },
  },
  {
    name: 'linux: PATH is searched in order',
    ...LINUX,
    setting: '',
    files: ['/opt/bin/cel-language-server', '/usr/bin/cel-language-server'],
    want: { path: '/usr/bin/cel-language-server', source: 'path' },
  },
  {
    name: 'linux: nothing found',
    ...LINUX,
    setting: '',
    files: [],
    want: {
      reason: 'cel-language-server not found: not in the setting, bundled, or on PATH.',
      relativeWithoutFolder: false,
    },
  },
  {
    name: 'linux: no PATH at all',
    ...LINUX,
    pathEnv: undefined,
    setting: '',
    files: [],
    want: {
      reason: 'cel-language-server not found: not in the setting, bundled, or on PATH.',
      relativeWithoutFolder: false,
    },
  },
  {
    name: 'macOS: the bundled binary is per architecture',
    ...MAC,
    setting: '',
    files: ['/ext/server/darwin-arm64/cel-language-server'],
    want: { path: '/ext/server/darwin-arm64/cel-language-server', source: 'bundled' },
  },
  {
    name: 'macOS: another architecture is not used',
    ...MAC,
    setting: '',
    files: ['/ext/server/darwin-x64/cel-language-server', '/usr/local/bin/cel-language-server'],
    want: { path: '/usr/local/bin/cel-language-server', source: 'path' },
  },
  {
    name: 'windows: the setting wins',
    ...WINDOWS,
    setting: 'D:\\cel\\cel-language-server.exe',
    files: [],
    want: { path: 'D:\\cel\\cel-language-server.exe', source: 'setting' },
  },
  {
    name: 'windows: the bundled binary is an .exe',
    ...WINDOWS,
    setting: '',
    files: ['C:\\ext\\server\\win32-x64\\cel-language-server.exe'],
    want: { path: 'C:\\ext\\server\\win32-x64\\cel-language-server.exe', source: 'bundled' },
  },
  {
    name: 'windows: PATH is split on semicolons',
    ...WINDOWS,
    setting: '',
    files: ['C:\\tools\\cel-language-server.exe'],
    want: { path: 'C:\\tools\\cel-language-server.exe', source: 'path' },
  },
  {
    name: 'linux: an absolute setting is used as it is, with a folder open',
    ...LINUX,
    setting: '/custom/cel',
    workspaceFolder: '/work',
    files: [],
    want: { path: '/custom/cel', source: 'setting' },
  },
  {
    name: 'linux: a relative setting resolves against the workspace folder',
    ...LINUX,
    setting: 'bin/cel',
    workspaceFolder: '/work',
    files: ['/usr/bin/cel-language-server'],
    want: { path: '/work/bin/cel', source: 'setting' },
  },
  {
    name: 'linux: a relative setting with no folder finds nothing, not even PATH',
    ...LINUX,
    setting: 'bin/cel',
    files: ['/usr/bin/cel-language-server'],
    want: {
      reason:
        '"celLens.server.path" is a relative path and no workspace folder is open to resolve it against. Open a folder or set an absolute path.',
      relativeWithoutFolder: true,
    },
  },
  {
    name: 'linux: an empty setting with no folder falls back to PATH',
    ...LINUX,
    setting: '',
    files: ['/usr/bin/cel-language-server'],
    want: { path: '/usr/bin/cel-language-server', source: 'path' },
  },
  {
    name: 'windows: a relative setting resolves against the workspace folder',
    ...WINDOWS,
    setting: 'bin\\cel.exe',
    workspaceFolder: 'D:\\work',
    files: [],
    want: { path: 'D:\\work\\bin\\cel.exe', source: 'setting' },
  },
  {
    name: 'windows: a drive-relative setting is rejected, not joined to the folder',
    ...WINDOWS,
    setting: 'C:tools\\cel.exe',
    workspaceFolder: 'D:\\work',
    files: [],
    want: {
      reason:
        '"celLens.server.path" is "C:tools\\cel.exe", which is neither absolute nor relative on Windows: it depends on a current drive or directory. Use a full path such as "C:\\tools\\cel.exe", or a path relative to the workspace folder such as "tools\\cel.exe".',
      relativeWithoutFolder: true,
    },
  },
  {
    name: 'windows: a root-relative setting is rejected, not joined to the folder',
    ...WINDOWS,
    setting: '\\tools\\cel.exe',
    workspaceFolder: 'D:\\work',
    files: [],
    want: {
      reason:
        '"celLens.server.path" is "\\tools\\cel.exe", which is neither absolute nor relative on Windows: it depends on a current drive or directory. Use a full path such as "C:\\tools\\cel.exe", or a path relative to the workspace folder such as "tools\\cel.exe".',
      relativeWithoutFolder: true,
    },
  },
  {
    name: 'windows: a forward-slash root-relative setting is rejected, not joined to the folder',
    ...WINDOWS,
    setting: '/tools/cel.exe',
    workspaceFolder: 'D:\\work',
    files: [],
    want: {
      reason:
        '"celLens.server.path" is "/tools/cel.exe", which is neither absolute nor relative on Windows: it depends on a current drive or directory. Use a full path such as "C:\\tools\\cel.exe", or a path relative to the workspace folder such as "tools\\cel.exe".',
      relativeWithoutFolder: true,
    },
  },
  {
    name: 'windows: a UNC setting is absolute and used as it is',
    ...WINDOWS,
    setting: '\\\\host\\share\\cel.exe',
    workspaceFolder: 'D:\\work',
    files: [],
    want: { path: '\\\\host\\share\\cel.exe', source: 'setting' },
  },
];

describe('findServer', () => {
  it.each(cases)('$name', async ({ files, want, ...rest }) => {
    const lookup: ServerLookup = {
      workspaceFolder: undefined,
      ...rest,
      exists: (file) => Promise.resolve(files.includes(file)),
    };

    expect(await findServer(lookup)).toEqual(want);
  });
});

describe('isRelativeServerPath', () => {
  it.each([
    ['bin/cel', 'linux', true],
    ['  bin/cel ', 'linux', true],
    ['/opt/cel', 'linux', false],
    ['', 'linux', false],
    ['   ', 'linux', false],
    ['tools\\cel.exe', 'win32', true],
    ['C:\\tools\\cel.exe', 'win32', false],
  ])('%j on %s is relative: %s', (setting, platform, want) => {
    expect(isRelativeServerPath(setting, platform)).toBe(want);
  });
});
