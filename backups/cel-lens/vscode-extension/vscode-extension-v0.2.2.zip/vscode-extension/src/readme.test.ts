import { readFileSync } from 'node:fs';

import { describe, expect, it } from 'vitest';

interface Manifest {
  contributes: {
    commands: { command: string; title: string; category: string }[];
    configuration: { properties: Record<string, { default: unknown }> };
  };
}

const manifest = JSON.parse(
  readFileSync(new URL('../package.json', import.meta.url), 'utf8'),
) as Manifest;
const readme = readFileSync(new URL('../README.md', import.meta.url), 'utf8');
const changelog = readFileSync(new URL('../CHANGELOG.md', import.meta.url), 'utf8');

/** The rows of the README's settings table: setting name and default, as written. */
function settingsTable(): Map<string, string> {
  const rows = new Map<string, string>();
  for (const line of readme.split('\n')) {
    const cells = line.split('|').map((cell) => cell.trim());
    const name = /^`(celLens\.[\w.]+)`$/.exec(cells[1] ?? '')?.[1];
    if (name !== undefined) {
      rows.set(name, cells[2] ?? '');
    }
  }
  return rows;
}

describe('README', () => {
  it('lists exactly the settings package.json contributes, with their defaults', () => {
    const contributed = new Map(
      Object.entries(manifest.contributes.configuration.properties).map(([name, property]) => [
        name,
        `\`${JSON.stringify(property.default)}\``,
      ]),
    );

    expect(settingsTable()).toEqual(contributed);
  });

  it.each(manifest.contributes.commands)('documents the command $title', (command) => {
    expect(readme).toContain(`**${command.category}: ${command.title}**`);
  });

  it.each([
    '## What it does',
    '## Install',
    '### Settings',
    '### Commands',
    '### Status',
    '## Troubleshooting',
    'code --install-extension',
    'vscode-extension-linux-x64-<version>.vsix',
    'TARGETS=<platform> make dist',
    'win32-arm64',
    'works offline',
    'celLens.trace.server',
    'releases',
    'v0.1.0 or later',
    'serve --stdio',
    'cel-language-server_<os>_<arch>',
    'rename it to `cel-language-server`',
  ])('contains %s', (text) => {
    expect(readme).toContain(text);
  });
});

describe('README untrusted workspaces', () => {
  it('notes in the settings table that celLens.server.path is ignored in untrusted workspaces', () => {
    const row = readme.split('\n').find((line) => line.includes('| `celLens.server.path`'));

    expect(row).toContain('Ignored in untrusted workspaces');
  });

  it('tells the user in Troubleshooting to trust the workspace when the binary is not found', () => {
    const troubleshooting = readme.split('## Troubleshooting')[1]?.split('\n## ')[0];

    expect(troubleshooting).toMatch(/not\s+found[^]*untrusted[^]*trust the workspace/i);
  });
});

describe('CHANGELOG', () => {
  it.each(['Unreleased', 'language server', 'highlighted', 'status bar', 'README'])(
    'mentions %s',
    (text) => {
      expect(changelog).toContain(text);
    },
  );
});
