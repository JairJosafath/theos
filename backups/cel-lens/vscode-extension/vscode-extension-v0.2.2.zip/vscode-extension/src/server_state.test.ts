import { describe, expect, it } from 'vitest';

import {
  INITIAL_SERVER_STATE,
  presentServerState,
  reduceServerState,
  type ServerEvent,
  type ServerState,
} from './server_state';

const DISABLED: ServerState = { kind: 'disabled' };
const STARTING: ServerState = { kind: 'starting' };
const RUNNING: ServerState = { kind: 'running' };
const NOT_FOUND: ServerState = { kind: 'notFound', reason: 'none' };
const FAILED: ServerState = { kind: 'failed', reason: 'boom' };
const DISABLE: ServerEvent = { kind: 'disable' };
const START: ServerEvent = { kind: 'start' };
const STARTED: ServerEvent = { kind: 'started' };
const MISSING: ServerEvent = { kind: 'notFound', reason: 'none' };
const FAIL: ServerEvent = { kind: 'failed', reason: 'no binary' };

describe('reduceServerState', () => {
  it.each<[string, ServerState, ServerEvent, ServerState]>([
    ['disabled, start: starting', DISABLED, START, STARTING],
    ['disabled, disable: disabled', DISABLED, DISABLE, DISABLED],
    ['disabled, started: stays disabled', DISABLED, STARTED, DISABLED],
    ['disabled, failed: stays disabled', DISABLED, FAIL, DISABLED],
    ['starting, started: running', STARTING, STARTED, RUNNING],
    [
      'starting, failed: failed with the reason',
      STARTING,
      FAIL,
      { kind: 'failed', reason: 'no binary' },
    ],
    ['starting, start: starting', STARTING, START, STARTING],
    ['starting, disable: disabled', STARTING, DISABLE, DISABLED],
    ['running, start: starting', RUNNING, START, STARTING],
    ['running, disable: disabled', RUNNING, DISABLE, DISABLED],
    [
      'running, failed: failed with the reason',
      RUNNING,
      FAIL,
      { kind: 'failed', reason: 'no binary' },
    ],
    ['running, started: running', RUNNING, STARTED, RUNNING],
    ['starting, not found: not found with the reason', STARTING, MISSING, NOT_FOUND],
    ['disabled, not found: stays disabled', DISABLED, MISSING, DISABLED],
    ['not found, start: starting', NOT_FOUND, START, STARTING],
    ['not found, started: stays not found', NOT_FOUND, STARTED, NOT_FOUND],
    ['failed, start: starting', FAILED, START, STARTING],
    ['failed, disable: disabled', FAILED, DISABLE, DISABLED],
    ['failed, started: stays failed', FAILED, STARTED, FAILED],
    ['failed, failed: the new reason', FAILED, FAIL, { kind: 'failed', reason: 'no binary' }],
  ])('%s', (_name, state, event, expected) => {
    expect(reduceServerState(state, event)).toEqual(expected);
  });

  it('follows a crash and the client restarting the server', () => {
    const states = [START, STARTED, FAIL, START, STARTED].reduce<ServerState[]>(
      (seen, event) => [...seen, reduceServerState(seen.at(-1) ?? DISABLED, event)],
      [],
    );
    expect(states.map((state) => state.kind)).toEqual([
      'starting',
      'running',
      'failed',
      'starting',
      'running',
    ]);
  });

  it('begins disabled, until the extension decides to start', () => {
    expect(INITIAL_SERVER_STATE).toEqual(DISABLED);
  });
});

describe('presentServerState', () => {
  it.each<[ServerState, string, string]>([
    [DISABLED, '$(circle-slash) CEL Lens: disabled', 'disabled'],
    [STARTING, '$(sync~spin) CEL Lens: starting', 'starting'],
    [RUNNING, '$(check) CEL Lens: running', 'running'],
    [NOT_FOUND, '$(warning) CEL Lens: not found', 'not found: none'],
    [FAILED, '$(error) CEL Lens: failed', 'failed: boom'],
  ])('shows %j as %s with a tooltip that names it', (state, text, words) => {
    const shown = presentServerState(state);
    expect(shown.text).toBe(text);
    expect(shown.tooltip).toContain(words);
  });
});
