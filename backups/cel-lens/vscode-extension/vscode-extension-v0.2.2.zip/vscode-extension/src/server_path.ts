import * as path from 'node:path';

/** Where the server binary was found, in the order the lookup tries them. */
export type ServerSource = 'setting' | 'bundled' | 'path';

export interface ServerLocation {
  path: string;
  source: ServerSource;
}

/** Why no server was found, in words the user can act on. */
export interface ServerNotFound {
  reason: string;
  /** Whether the usual fix, setting the path or using PATH, applies as it is. */
  relativeWithoutFolder: boolean;
}

export interface ServerLookup {
  /** The value of `celLens.server.path`; blank means unset. */
  setting: string;
  /** `process.platform`. */
  platform: string;
  /** `process.arch`. */
  arch: string;
  /** The first workspace folder's path, if a folder is open. */
  workspaceFolder: string | undefined;
  /** The directory the extension is installed in. */
  extensionPath: string;
  /** The `PATH` environment variable, if any. */
  pathEnv: string | undefined;
  /** Whether a file exists at an absolute path. */
  exists: (file: string) => Promise<boolean>;
}

/** `C:tools\\cel.exe`: a drive with no root, relative to that drive's current directory. */
const WINDOWS_DRIVE_RELATIVE = /^[a-zA-Z]:(?![\\/])/;
/** `\\tools\\cel.exe`: a root with no drive, resolved against the host's current drive. */
const WINDOWS_ROOT_RELATIVE = /^[\\/](?![\\/])/;

/** The server's file name for `platform`. */
export function serverFileName(platform: string): string {
  return platform === 'win32' ? 'cel-language-server.exe' : 'cel-language-server';
}

/** Whether `setting` is set and not absolute, so it resolves against the first workspace folder. */
export function isRelativeServerPath(setting: string, platform: string): boolean {
  const flavour = platform === 'win32' ? path.win32 : path.posix;
  const trimmed = setting.trim();
  return trimmed !== '' && !flavour.isAbsolute(trimmed);
}

/**
 * Finds the server binary: the setting, then the binary bundled at
 * `server/<platform>-<arch>/`, then `PATH`. A set path is trusted as it is, so
 * a wrong one fails visibly instead of silently using another binary. A
 * relative setting resolves against the first workspace folder; with no folder
 * open it finds nothing, as the extension host's working directory is no base.
 * On Windows, drive-relative (`C:tools`) and root-relative (`\tools`) settings
 * are rejected, as they depend on a current drive or directory.
 * When nothing is found, the result says why.
 */
export async function findServer(lookup: ServerLookup): Promise<ServerLocation | ServerNotFound> {
  const windows = lookup.platform === 'win32';
  const flavour = windows ? path.win32 : path.posix;
  const file = serverFileName(lookup.platform);

  const setting = lookup.setting.trim();
  if (setting !== '') {
    if (windows && (WINDOWS_DRIVE_RELATIVE.test(setting) || WINDOWS_ROOT_RELATIVE.test(setting))) {
      return {
        reason: `"celLens.server.path" is "${setting}", which is neither absolute nor relative on Windows: it depends on a current drive or directory. Use a full path such as "C:\\tools\\cel.exe", or a path relative to the workspace folder such as "tools\\cel.exe".`,
        relativeWithoutFolder: true,
      };
    }
    if (!flavour.isAbsolute(setting)) {
      return lookup.workspaceFolder === undefined
        ? {
            reason:
              '"celLens.server.path" is a relative path and no workspace folder is open to resolve it against. Open a folder or set an absolute path.',
            relativeWithoutFolder: true,
          }
        : { path: flavour.join(lookup.workspaceFolder, setting), source: 'setting' };
    }
    return { path: setting, source: 'setting' };
  }

  const bundled = flavour.join(
    lookup.extensionPath,
    'server',
    `${lookup.platform}-${lookup.arch}`,
    file,
  );
  if (await lookup.exists(bundled)) {
    return { path: bundled, source: 'bundled' };
  }

  const directories = (lookup.pathEnv ?? '').split(flavour.delimiter).filter((d) => d !== '');
  for (const directory of directories) {
    const candidate = flavour.join(directory, file);
    if (await lookup.exists(candidate)) {
      return { path: candidate, source: 'path' };
    }
  }
  return {
    reason: 'cel-language-server not found: not in the setting, bundled, or on PATH.',
    relativeWithoutFolder: false,
  };
}
