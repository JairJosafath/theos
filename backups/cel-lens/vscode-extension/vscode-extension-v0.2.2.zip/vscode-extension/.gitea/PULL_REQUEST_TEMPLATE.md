Closes #

## Summary

<!-- What changed and why, in two or three sentences. -->

## How each acceptance criterion is met

<!-- One item per criterion: met or not met, where (file and function), and the test that proves it. -->

## How it was checked

<!-- make check; numbers for any budget; manual runs in VS Code, if any. -->

## Notes for the reviewer

<!-- What could not be verified, and why; decisions you made; follow-ups you noticed. -->
