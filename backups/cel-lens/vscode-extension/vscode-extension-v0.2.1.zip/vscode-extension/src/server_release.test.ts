import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { describe, expect, it } from 'vitest';

import {
  assetUrl,
  matchesChecksum,
  PACKAGE_TARGETS,
  parseChecksums,
  parseServerPin,
  selectTargets,
  verifiedAsset,
  type AssetStore,
} from './server_release';
import { serverFileName } from './server_path';

const HELLO_SHA = '2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824';

describe('PACKAGE_TARGETS', () => {
  it('lists the five platforms, each with the server build for it', () => {
    expect(PACKAGE_TARGETS.map((t) => [t.target, t.asset])).toEqual([
      ['linux-x64', 'cel-language-server_linux_amd64'],
      ['linux-arm64', 'cel-language-server_linux_arm64'],
      ['darwin-x64', 'cel-language-server_darwin_amd64'],
      ['darwin-arm64', 'cel-language-server_darwin_arm64'],
      ['win32-x64', 'cel-language-server_windows_amd64.exe'],
    ]);
  });

  it.each(PACKAGE_TARGETS)('names $target’s file as the lookup expects', ({ target, file }) => {
    const platform = target.split('-')[0];
    expect(file).toBe(serverFileName(platform ?? ''));
  });
});

describe('selectTargets', () => {
  it.each([
    [undefined, ['linux-x64']],
    ['', ['linux-x64']],
    ['linux-x64', ['linux-x64']],
    ['linux-x64,darwin-arm64', ['linux-x64', 'darwin-arm64']],
    [' win32-x64 , win32-x64 ', ['win32-x64']],
  ])('picks %j as %j', (list, expected) => {
    expect(selectTargets(list).map((t) => t.target)).toEqual(expected);
  });

  it('fails on an unknown target, naming it', () => {
    expect(() => selectTargets('linux-x64,freebsd-x64')).toThrow(/"freebsd-x64"/);
  });
});

describe('server.json', () => {
  it('pins a release the script accepts', () => {
    const pin = parseServerPin(readFileSync('server.json', 'utf8'));
    expect(pin.version).toMatch(/^v\d+\.\d+\.\d+$/);
  });

  it('pins the bundled server release v0.1.1', () => {
    expect(parseServerPin(readFileSync('server.json', 'utf8')).version).toBe('v0.1.1');
  });

  it.each([
    ['not an object', '[]'],
    ['no version', '{"releaseUrl": "http://h/r"}'],
    ['a branch instead of a tag', '{"version": "main", "releaseUrl": "http://h/r"}'],
    ['no release URL', '{"version": "v1.2.3"}'],
  ])('rejects %s', (_name, text) => {
    expect(() => parseServerPin(text)).toThrow('server.json must be');
  });
});

describe('assetUrl', () => {
  it.each(['http://h/r', 'http://h/r/'])('joins %s, the tag and the asset', (releaseUrl) => {
    expect(assetUrl({ version: 'v1.2.3', releaseUrl }, 'SHA256SUMS')).toBe(
      'http://h/r/v1.2.3/SHA256SUMS',
    );
  });
});

describe('parseChecksums', () => {
  it('reads sha256sum output, text and binary mode, and skips other lines', () => {
    const upper = HELLO_SHA.toUpperCase();
    const sums = parseChecksums(`${upper}  a_linux\r\n${HELLO_SHA} *b.exe\nnot a sum\n\n`);
    expect([...sums]).toEqual([
      ['a_linux', HELLO_SHA],
      ['b.exe', HELLO_SHA],
    ]);
  });

  it('is empty for an empty file', () => {
    expect(parseChecksums('').size).toBe(0);
  });
});

describe('matchesChecksum', () => {
  it.each([
    ['the content hashes to it', 'hello', HELLO_SHA, true],
    ['the case differs', 'hello', HELLO_SHA.toUpperCase(), true],
    ['the content was altered', 'hellp', HELLO_SHA, false],
    ['the content is empty', '', HELLO_SHA, false],
  ])('is as expected when %s', (_name, content, expected, result) => {
    expect(matchesChecksum(new TextEncoder().encode(content), expected)).toBe(result);
  });
});

describe('verifiedAsset', () => {
  const pin = { version: 'v1.2.3', releaseUrl: 'http://example.test/releases/download' };
  const good = new TextEncoder().encode('good');
  const bad = new TextEncoder().encode('bad');
  const sums = new Map([['asset', createHash('sha256').update(good).digest('hex')]]);

  function fakeStore(cached: Uint8Array | undefined, downloaded: Uint8Array) {
    const calls: string[] = [];
    const io: AssetStore = {
      cached: () => Promise.resolve(cached),
      download: () => {
        calls.push('download');
        return Promise.resolve(downloaded);
      },
      store: () => {
        calls.push('store');
        return Promise.resolve();
      },
    };
    return { io, calls };
  }

  it.each([
    ['uses a matching cached file without downloading', good, bad, []],
    ['downloads and caches when nothing is cached', undefined, good, ['download', 'store']],
    ['downloads again when the cached file does not match', bad, good, ['download', 'store']],
  ])('%s', async (_name, cached, downloaded, expected) => {
    const { io, calls } = fakeStore(cached, downloaded);
    expect(await verifiedAsset(pin, 'asset', sums, io)).toEqual(good);
    expect(calls).toEqual(expected);
  });

  it('refuses a download that does not match, and does not cache it', async () => {
    const { io, calls } = fakeStore(undefined, bad);
    await expect(verifiedAsset(pin, 'asset', sums, io)).rejects.toThrow('not packaged');
    expect(calls).toEqual(['download']);
  });

  it('says to delete the cache when SHA256SUMS has no entry', async () => {
    const { io } = fakeStore(undefined, good);
    await expect(verifiedAsset(pin, 'other', sums, io)).rejects.toThrow(
      'delete .cache/server/v1.2.3/',
    );
  });
});
