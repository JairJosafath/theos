# Changelog

Every user-visible change, newest first. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and versions follow
[Semantic Versioning](https://semver.org/): the `version` in `package.json`.

## [Unreleased]

## [0.1.0] - 2026-10-03

### Added

- The language server comes with the extension: pick the `.vsix` for your platform
  (linux-x64, linux-arm64, darwin-x64, darwin-arm64, win32-x64) and there is no
  separate server to install. `celLens.server.path` still takes precedence.

### Fixed

- A relative `celLens.server.path` is resolved again, and the server restarted, when the
  first workspace folder changes.
- On Windows, a `celLens.server.path` such as `C:tools\cel.exe` or `\tools\cel.exe`
  is no longer joined to the workspace folder or resolved against the current
  drive; the extension logs why and shows the fix.

### Changed

- The README states the compatible server version, `cel-language-server` v0.1.0 or later.
- The not-found notification says why when `celLens.server.path` is relative and no
  folder is open, instead of only suggesting to set the path or use PATH.
- The README says `celLens.server.path` is ignored in untrusted workspaces, and
  Troubleshooting says to trust the workspace when the binary is not found.
- When the language client restarts a crashed server, the extension logs at info
  level and the status item stays on starting; it shows failed only when the
  server stays down.
- A relative `celLens.server.path` resolves against the first workspace folder;
  with no folder open it is not started and the output says why.

### Added

- The extension, scaffolded by C4 Factory.
- The extension starts the CEL language server for YAML files, found through
  `celLens.server.path`, the bundled binary or `PATH`; `celLens.trace.server`
  traces it, and **CEL Lens: Restart Server** restarts it.
- CEL is highlighted in the values of `expression`, `messageExpression`,
  `valueExpression` and `rule` in YAML files, before the server starts.
- The `celLens.enable` setting, and a status bar item for YAML editors that shows
  whether the server is starting, running or failed (with the reason); clicking
  it, or **CEL Lens: Show Output**, opens the "CEL Lens" output. Changing
  `celLens.enable` or `celLens.server.path` restarts or stops the server
  without a window reload.
- A README for users: what the extension understands, installing, settings,
  commands, the status item and troubleshooting, with a test that its settings
  table matches `package.json`.
