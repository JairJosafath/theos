import { constants } from 'node:fs';
import { access, stat } from 'node:fs/promises';

import * as vscode from 'vscode';
import {
  CloseAction,
  LanguageClient,
  State,
  TransportKind,
  type ErrorHandler,
  type LanguageClientOptions,
  type ServerOptions,
} from 'vscode-languageclient/node';

import { findServer, isRelativeServerPath, type ServerLookup } from './server_path';
import {
  INITIAL_SERVER_STATE,
  presentServerState,
  reduceServerState,
  type ServerEvent,
  type ServerState,
} from './server_state';

/** The restart command, as contributed in package.json. */
export const RESTART_COMMAND = 'celLens.restartServer';
/** The command that opens the "CEL Lens" output channel, as contributed in package.json. */
export const SHOW_OUTPUT_COMMAND = 'celLens.showOutput';
/** The setting that turns the server on or off, as contributed in package.json. */
export const ENABLE_SETTING = 'celLens.enable';
/** The setting that names the server binary, as contributed in package.json. */
export const SERVER_PATH_SETTING = 'celLens.server.path';

const OPEN_SETTINGS = 'Open Settings';

const DOCUMENT_SELECTOR = [
  { language: 'yaml', scheme: 'file' },
  { language: 'yaml', scheme: 'untitled' },
];

let client: LanguageClient | undefined;
/** The subscription to the current client's state changes. */
let stateWatch: vscode.Disposable | undefined;
/** The start in progress. */
let starting: Promise<void> | undefined;
/** The start queued behind it; further requests share it, so a burst gives one more start. */
let queued: Promise<void> | undefined;
/** Whether an error notification is on screen; it stays until the user answers. */
let errorVisible = false;
let serverState: ServerState = INITIAL_SERVER_STATE;
let statusItem: Pick<vscode.StatusBarItem, 'text' | 'tooltip' | 'show' | 'hide'> | undefined;

function renderStatus(): void {
  if (statusItem === undefined) {
    return;
  }
  const shown = presentServerState(serverState);
  statusItem.text = shown.text;
  statusItem.tooltip = shown.tooltip;
  if (vscode.window.activeTextEditor?.document.languageId === 'yaml') {
    statusItem.show();
  } else {
    statusItem.hide();
  }
}

function transition(event: ServerEvent): void {
  serverState = reduceServerState(serverState, event);
  renderStatus();
}

async function isFile(file: string): Promise<boolean> {
  try {
    if (!(await stat(file)).isFile()) {
      return false;
    }
    if (process.platform !== 'win32') {
      await access(file, constants.X_OK);
    }
    return true;
  } catch {
    return false;
  }
}

/**
 * Shows an error without waiting for the answer, so a start never hangs on the
 * notification. Only one is on screen at a time.
 */
function showError(message: string): void {
  if (errorVisible) {
    return;
  }
  errorVisible = true;
  void vscode.window.showErrorMessage(message, OPEN_SETTINGS).then((choice) => {
    errorVisible = false;
    if (choice === OPEN_SETTINGS) {
      return vscode.commands.executeCommand('workbench.action.openSettings', SERVER_PATH_SETTING);
    }
    return undefined;
  });
}

/** Stops the running client, if any, and starts a new one. Never throws. */
async function restartServer(
  context: Pick<vscode.ExtensionContext, 'extensionPath'>,
  log: vscode.LogOutputChannel,
): Promise<void> {
  const previous = client;
  client = undefined;
  stateWatch?.dispose();
  stateWatch = undefined;
  try {
    await previous?.stop();
  } catch (error) {
    log.warn(`Stopping the previous server failed: ${String(error)}`);
  }

  if (!vscode.workspace.getConfiguration().get<boolean>(ENABLE_SETTING, true)) {
    log.info(`The server is off: "${ENABLE_SETTING}" is false.`);
    transition({ kind: 'disable' });
    return;
  }
  transition({ kind: 'start' });

  const lookup: ServerLookup = {
    setting: vscode.workspace.getConfiguration().get<string>(SERVER_PATH_SETTING, ''),
    workspaceFolder: vscode.workspace.workspaceFolders?.[0]?.uri.fsPath,
    platform: process.platform,
    arch: process.arch,
    extensionPath: context.extensionPath,
    pathEnv: process.env['PATH'],
    exists: isFile,
  };
  const server = await findServer(lookup);
  if ('reason' in server) {
    log.error(server.reason);
    transition({
      kind: 'failed',
      reason: `not found in "${SERVER_PATH_SETTING}", bundled or on PATH.`,
    });
    showError(
      server.relativeWithoutFolder
        ? `CEL language server not found. ${server.reason}`
        : `CEL language server not found. Set "${SERVER_PATH_SETTING}" to the cel-language-server binary, or put it on your PATH.`,
    );
    return;
  }
  log.info(`Using cel-language-server from the ${server.source}: ${server.path}`);

  const serverOptions: ServerOptions = {
    command: server.path,
    args: ['serve', '--stdio'],
    transport: TransportKind.stdio,
  };
  const clientOptions: LanguageClientOptions = {
    documentSelector: DOCUMENT_SELECTOR,
    outputChannel: log,
    errorHandler: {
      error: (error, message, count) => clientDefaults().error(error, message, count),
      closed: async () => {
        const action = await clientDefaults().closed();
        restarting = action.action === CloseAction.Restart;
        if (restarting) {
          log.info('The server stopped; restarting it.');
        }
        return action;
      },
    },
  };
  const next = new LanguageClient('celLens', 'CEL Lens', serverOptions, clientOptions);
  client = next;
  // The client's own policy for crashes: restart a few times, then give up.
  let defaults: ErrorHandler | undefined;
  const clientDefaults = (): ErrorHandler => (defaults ??= next.createDefaultErrorHandler());
  // Whether the client has decided to restart the server after it closed.
  let restarting = false;
  // Disposed with the client's owner: the next restart, or deactivate().
  let startSettled = false;
  stateWatch = next.onDidChangeState((change) => {
    if (client !== next) {
      return;
    }
    switch (change.newState) {
      case State.Starting:
        transition({ kind: 'start' });
        break;
      case State.Running:
        restarting = false;
        transition({ kind: 'started' });
        break;
      case State.StartFailed:
        // Until our own start() settles, its rejection reports the reason. After
        // that, the client's automatic restart failed and nothing else will.
        if (startSettled) {
          log.error('The server could not be restarted.');
          transition({
            kind: 'failed',
            reason: 'the server could not be restarted; see the output.',
          });
        }
        break;
      case State.Stopped:
        if (restarting) {
          transition({ kind: 'start' });
        } else {
          log.error('The server stopped unexpectedly.');
          transition({
            kind: 'failed',
            reason: 'the server stopped unexpectedly; see the output.',
          });
        }
        break;
    }
  });
  try {
    await next.start();
    startSettled = true;
    transition({ kind: 'started' });
  } catch (error) {
    startSettled = true;
    client = undefined;
    stateWatch.dispose();
    stateWatch = undefined;
    log.error(`Starting ${server.path} failed: ${String(error)}`);
    transition({ kind: 'failed', reason: `${server.path} did not start: ${String(error)}.` });
    showError(
      `CEL language server failed to start (${server.path}). Check "${SERVER_PATH_SETTING}", then run "CEL Lens: Restart Server".`,
    );
  }
}

/**
 * Restarts the server. A request made while a start is in progress runs after
 * it, so it reads the setting again and the starts never overlap.
 */
function startServer(
  context: Pick<vscode.ExtensionContext, 'extensionPath'>,
  log: vscode.LogOutputChannel,
): Promise<void> {
  if (starting === undefined) {
    starting = restartServer(context, log).finally(() => {
      starting = undefined;
    });
    return starting;
  }
  queued ??= starting.then(() => {
    queued = undefined;
    return startServer(context, log);
  });
  return queued;
}

/** Resolves when the start in progress, and the one queued behind it, have finished. */
export async function whenStarted(): Promise<void> {
  await (queued ?? starting);
}

/**
 * Activates the extension on the first YAML file. It only registers the
 * restart command and starts the server in the background; everything it
 * creates goes into `context.subscriptions`.
 */
export function activate(
  context: Pick<vscode.ExtensionContext, 'subscriptions' | 'extensionPath'>,
): void {
  const log = vscode.window.createOutputChannel('CEL Lens', { log: true });
  const item = vscode.window.createStatusBarItem('celLens.status', vscode.StatusBarAlignment.Left);
  item.name = 'CEL Lens';
  item.command = SHOW_OUTPUT_COMMAND;
  statusItem = item;
  renderStatus();
  context.subscriptions.push(
    log,
    item,
    vscode.commands.registerCommand(SHOW_OUTPUT_COMMAND, () => {
      log.show(true);
    }),
    vscode.window.onDidChangeActiveTextEditor(renderStatus),
    vscode.workspace.onDidChangeConfiguration((change) => {
      if (
        change.affectsConfiguration(ENABLE_SETTING) ||
        change.affectsConfiguration(SERVER_PATH_SETTING)
      ) {
        void startServer(context, log);
      }
    }),
    vscode.commands.registerCommand(RESTART_COMMAND, () => startServer(context, log)),
  );
  // A relative path resolves against the first folder, so a new first folder
  // can make the resolved binary stale.
  let firstFolder = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
  context.subscriptions.push(
    vscode.workspace.onDidChangeWorkspaceFolders(() => {
      const current = vscode.workspace.workspaceFolders?.[0]?.uri.fsPath;
      if (current === firstFolder) {
        return;
      }
      firstFolder = current;
      const setting = vscode.workspace.getConfiguration().get<string>(SERVER_PATH_SETTING, '');
      if (isRelativeServerPath(setting, process.platform)) {
        log.info('The first workspace folder changed; restarting the server.');
        void startServer(context, log);
      }
    }),
  );
  void startServer(context, log);
}

/** Stops the language server; VS Code waits for the returned promise. */
export async function deactivate(): Promise<void> {
  await whenStarted();
  const running = client;
  client = undefined;
  stateWatch?.dispose();
  stateWatch = undefined;
  errorVisible = false;
  serverState = INITIAL_SERVER_STATE;
  statusItem = undefined;
  await running?.stop();
}
