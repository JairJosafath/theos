import { readFileSync } from 'node:fs';

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type * as vscode from 'vscode';

import {
  changeSetting,
  changeWorkspaceFolders,
  commands,
  errorChoice,
  executedCommands,
  outputChannels,
  reset,
  runCommand,
  settings,
  shownErrors,
  statusItems,
  switchEditor,
  workspaceFolderPaths,
} from '../test/vscode';
import {
  activate,
  deactivate,
  ENABLE_SETTING,
  RESTART_COMMAND,
  SERVER_PATH_SETTING,
  SHOW_OUTPUT_COMMAND,
  whenStarted,
} from './extension';

const fake = vi.hoisted(() => {
  class FakeClient {
    static instances: FakeClient[] = [];
    static failStart = false;
    /** What the client's default error handler answers when the server closes. */
    static closeAction = 2;
    started = 0;
    stopped = 0;
    private readonly listeners = new Set<(change: { newState: number }) => void>();
    constructor(
      readonly id: string,
      readonly name: string,
      readonly serverOptions: unknown,
      readonly clientOptions: unknown,
    ) {
      FakeClient.instances.push(this);
    }
    start(): Promise<void> {
      this.started++;
      return FakeClient.failStart ? Promise.reject(new Error('boom')) : Promise.resolve();
    }
    onDidChangeState(listener: (change: { newState: number }) => void): { dispose(): void } {
      this.listeners.add(listener);
      return { dispose: () => this.listeners.delete(listener) };
    }
    emit(newState: number): void {
      for (const listener of this.listeners) {
        listener({ newState });
      }
    }
    createDefaultErrorHandler(): {
      error(): { action: number };
      closed(): { action: number };
    } {
      return { error: () => ({ action: 1 }), closed: () => ({ action: FakeClient.closeAction }) };
    }
    /** The server process ends: the client asks its error handler, then reports Stopped. */
    async crash(): Promise<void> {
      const options = this.clientOptions as { errorHandler: { closed(): unknown } };
      await options.errorHandler.closed();
      this.emit(1);
    }
    stop(): Promise<void> {
      this.stopped++;
      return Promise.resolve();
    }
  }
  const State = { Stopped: 1, Running: 2, Starting: 3, StartFailed: 4 } as const;
  return { FakeClient, State };
});

vi.mock('vscode-languageclient/node', () => ({
  LanguageClient: fake.FakeClient,
  TransportKind: { stdio: 0 },
  CloseAction: { DoNotRestart: 1, Restart: 2 },
  State: fake.State,
}));

interface Manifest {
  activationEvents: string[];
  contributes: {
    commands: { command: string; title: string; category: string }[];
    configuration: {
      properties: Record<string, { default: unknown; description: string; enum?: string[] }>;
    };
  };
}

const manifest = JSON.parse(
  readFileSync(new URL('../package.json', import.meta.url), 'utf8'),
) as Manifest;

const { FakeClient, State } = fake;
const SERVER = '/custom/cel-language-server';

function context(subscriptions: vscode.Disposable[] = []): {
  subscriptions: vscode.Disposable[];
  extensionPath: string;
} {
  return { subscriptions, extensionPath: '/nonexistent-extension' };
}

/** Lets the background start finish. */
async function settle(): Promise<void> {
  await whenStarted();
}

describe('manifest', () => {
  it('activates on YAML only', () => {
    expect(manifest.activationEvents).toEqual(['onLanguage:yaml']);
  });

  it('contributes the restart command in Title Case under one category', () => {
    expect(manifest.contributes.commands).toEqual([
      { command: RESTART_COMMAND, title: 'Restart Server', category: 'CEL Lens' },
      { command: SHOW_OUTPUT_COMMAND, title: 'Show Output', category: 'CEL Lens' },
    ]);
  });

  it('contributes the enable setting, on by default, with a description', () => {
    const setting = manifest.contributes.configuration.properties[ENABLE_SETTING];
    expect(setting?.default).toBe(true);
    expect(setting?.description).not.toBe('');
  });

  it('contributes the server path setting with a default and a description', () => {
    const setting = manifest.contributes.configuration.properties[SERVER_PATH_SETTING];
    expect(setting?.default).toBe('');
    expect(setting?.description).not.toBe('');
  });

  it('contributes the server trace setting that the language client reads', () => {
    const setting = manifest.contributes.configuration.properties['celLens.trace.server'];
    expect(setting?.default).toBe('off');
    expect(setting?.enum).toEqual(['off', 'messages', 'verbose']);
    expect(setting?.description).not.toBe('');
  });
});

describe('activate', () => {
  beforeEach(() => {
    FakeClient.instances.length = 0;
    FakeClient.failStart = false;
    FakeClient.closeAction = 2;
    vi.stubEnv('PATH', '/nonexistent-bin');
  });

  afterEach(async () => {
    await deactivate();
    reset();
    vi.unstubAllEnvs();
  });

  it('starts "<binary> serve --stdio" for saved and untitled YAML, logging to "CEL Lens"', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    const [client] = FakeClient.instances;
    expect(FakeClient.instances).toHaveLength(1);
    expect(client?.started).toBe(1);
    expect(client?.name).toBe('CEL Lens');
    expect(client?.serverOptions).toEqual({
      command: SERVER,
      args: ['serve', '--stdio'],
      transport: 0,
    });
    expect(client?.clientOptions).toMatchObject({
      documentSelector: [
        { language: 'yaml', scheme: 'file' },
        { language: 'yaml', scheme: 'untitled' },
      ],
      outputChannel: outputChannels.get('CEL Lens'),
    });
  });

  it('shows one error offering Open Settings when no binary exists, and does not retry', async () => {
    errorChoice.next = 'Open Settings';
    activate(context());
    await settle();

    expect(FakeClient.instances).toHaveLength(0);
    expect(shownErrors).toHaveLength(1);
    expect(shownErrors[0]).toContain('not found');
    expect(executedCommands).toEqual([['workbench.action.openSettings', SERVER_PATH_SETTING]]);
  });

  it('starts a relative server path from the workspace folder', async () => {
    settings.set(SERVER_PATH_SETTING, 'bin/cel');
    workspaceFolderPaths.push('/work');
    activate(context());
    await settle();

    expect(FakeClient.instances[0]?.serverOptions).toMatchObject({ command: '/work/bin/cel' });
  });

  it('does not start a relative server path with no folder, and says why', async () => {
    settings.set(SERVER_PATH_SETTING, 'bin/cel');
    activate(context());
    await settle();

    expect(FakeClient.instances).toHaveLength(0);
    expect(shownErrors).toHaveLength(1);
    expect(shownErrors[0]).toContain('relative path and no workspace folder is open');
    expect(outputChannels.get('CEL Lens')?.lines.join('\n')).toContain(
      'relative path and no workspace folder is open',
    );
  });

  it('restarts a relative server path when the first workspace folder changes', async () => {
    settings.set(SERVER_PATH_SETTING, 'bin/cel');
    workspaceFolderPaths.push('/work');
    activate(context());
    await settle();
    changeWorkspaceFolders(['/other', '/work']);
    await settle();

    expect(FakeClient.instances).toHaveLength(2);
    expect(FakeClient.instances[0]?.stopped).toBe(1);
    expect(FakeClient.instances[1]?.serverOptions).toMatchObject({ command: '/other/bin/cel' });
  });

  it.each([
    ['the setting is absolute', '/opt/cel', ['/other', '/work']],
    ['the first folder is unchanged', 'bin/cel', ['/work', '/other']],
  ])('does not restart when %s', async (_name, setting, folders) => {
    settings.set(SERVER_PATH_SETTING, setting);
    workspaceFolderPaths.push('/work');
    activate(context());
    await settle();
    changeWorkspaceFolders(folders);
    await settle();

    expect(FakeClient.instances).toHaveLength(1);
  });

  it('does not open settings when the error is dismissed', async () => {
    activate(context());
    await settle();

    expect(executedCommands).toEqual([]);
  });

  it('shows one error when the server fails to start', async () => {
    FakeClient.failStart = true;
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    expect(shownErrors).toHaveLength(1);
    expect(shownErrors[0]).toContain('failed to start');
    expect(FakeClient.instances).toHaveLength(1);
  });

  it('restarts the client with the restart command', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    await runCommand(RESTART_COMMAND);

    const [first, second] = FakeClient.instances;
    expect(FakeClient.instances).toHaveLength(2);
    expect(first?.stopped).toBe(1);
    expect(second?.started).toBe(1);
  });

  it('runs one client when restarted while starting', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await runCommand(RESTART_COMMAND);
    const [first, second] = FakeClient.instances;
    expect(FakeClient.instances).toHaveLength(2);
    expect(first?.stopped).toBe(1);
    expect(second?.started).toBe(1);
    expect(second?.stopped).toBe(0);
    await deactivate();
    expect(second?.stopped).toBe(1);
  });

  it('finds the server after the user fixes the setting and restarts', async () => {
    activate(context());
    await settle();
    expect(FakeClient.instances).toHaveLength(0);

    settings.set(SERVER_PATH_SETTING, SERVER);
    await runCommand(RESTART_COMMAND);

    expect(FakeClient.instances).toHaveLength(1);
  });

  it('restarts after the setting is fixed while the error is still unanswered', async () => {
    errorChoice.unanswered = true;
    activate(context());
    await settle();
    expect(FakeClient.instances).toHaveLength(0);

    settings.set(SERVER_PATH_SETTING, SERVER);
    await runCommand(RESTART_COMMAND);

    expect(FakeClient.instances).toHaveLength(1);
    expect(FakeClient.instances[0]?.started).toBe(1);
    expect(shownErrors).toHaveLength(1);
  });

  it('shows one error when activated and restarted at once with an unanswered error', async () => {
    errorChoice.unanswered = true;
    activate(context());
    await runCommand(RESTART_COMMAND);

    expect(FakeClient.instances).toHaveLength(0);
    expect(shownErrors).toHaveLength(1);
  });

  it('deactivates while an error is unanswered', async () => {
    errorChoice.unanswered = true;
    activate(context());
    await settle();

    await deactivate();

    expect(shownErrors).toHaveLength(1);
  });

  it('hands every registration to VS Code to dispose', async () => {
    const subscriptions: vscode.Disposable[] = [];
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context(subscriptions));
    await settle();

    for (const subscription of subscriptions) {
      subscription.dispose();
    }

    expect(await commands.getCommands()).toEqual([]);
    expect(outputChannels.get('CEL Lens')?.disposed).toBe(true);
  });

  it('stops the client on deactivate', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    await deactivate();

    expect(FakeClient.instances[0]?.stopped).toBe(1);
  });

  it('stops the server without a reload when "celLens.enable" turns false, and starts it when true', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    changeSetting(ENABLE_SETTING, false);
    await settle();
    expect(FakeClient.instances[0]?.stopped).toBe(1);
    expect(FakeClient.instances).toHaveLength(1);
    expect(statusItems[0]?.tooltip).toContain('disabled');

    changeSetting(ENABLE_SETTING, true);
    await settle();
    expect(FakeClient.instances).toHaveLength(2);
    expect(FakeClient.instances[1]?.started).toBe(1);
  });

  it('does not start the server when it is disabled at activation', async () => {
    settings.set(ENABLE_SETTING, false);
    activate(context());
    await settle();

    expect(statusItems[0]?.tooltip).toContain('disabled');
    expect(FakeClient.instances).toHaveLength(0);
    expect(shownErrors).toHaveLength(0);
  });

  it('restarts the server when "celLens.server.path" changes', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    changeSetting(SERVER_PATH_SETTING, '/other/cel-language-server');
    await settle();

    expect(FakeClient.instances).toHaveLength(2);
    expect(FakeClient.instances[0]?.stopped).toBe(1);
    expect(FakeClient.instances[1]?.serverOptions).toMatchObject({
      command: '/other/cel-language-server',
    });
  });

  it('ignores changes to other settings', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    changeSetting('celLens.trace.server', 'verbose');
    await settle();

    expect(FakeClient.instances).toHaveLength(1);
  });

  it('shows the status item only while a YAML editor is active', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();
    const item = statusItems[0];

    expect(item?.visible).toBe(false);
    switchEditor('yaml');
    expect(item?.visible).toBe(true);
    switchEditor('typescript');
    expect(item?.visible).toBe(false);
    switchEditor('yaml');
    switchEditor(undefined);
    expect(item?.visible).toBe(false);
  });

  it('shows running once the server has started', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    expect(statusItems[0]?.tooltip).toContain('running');
  });

  it('shows failed when the server stops and the client does not restart it', async () => {
    FakeClient.closeAction = 1;
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();
    expect(statusItems[0]?.tooltip).toContain('running');

    await FakeClient.instances[0]?.crash();

    expect(statusItems[0]?.tooltip).toContain('failed');
    expect(statusItems[0]?.tooltip).toContain('stopped unexpectedly');
    expect(outputChannels.get('CEL Lens')?.lines).toContain(
      'error: The server stopped unexpectedly.',
    );
  });

  it('logs at info and stays starting while the client restarts a crashed server', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();
    const client = FakeClient.instances[0];
    const kinds: string[] = [];
    const watch = (): void => {
      const tooltip = statusItems[0]?.tooltip ?? '';
      kinds.push(['starting', 'running', 'failed'].find((kind) => tooltip.includes(kind)) ?? '?');
    };

    await client?.crash();
    watch();
    client?.emit(State.Starting);
    watch();
    client?.emit(State.Running);
    watch();

    expect(kinds).toEqual(['starting', 'starting', 'running']);
    const lines = outputChannels.get('CEL Lens')?.lines ?? [];
    expect(lines).toContain('info: The server stopped; restarting it.');
    expect(lines.filter((line) => line.startsWith('error:'))).toEqual([]);
  });

  it('shows failed when the automatic restart after a crash fails', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();
    expect(statusItems[0]?.tooltip).toContain('running');
    const client = FakeClient.instances[0];

    await client?.crash();
    client?.emit(State.Starting);
    client?.emit(State.StartFailed);

    expect(statusItems[0]?.tooltip).toContain('failed');
    expect(statusItems[0]?.tooltip).toContain('could not be restarted');
  });

  it('ignores the state changes of a client that the extension stopped', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();
    expect(statusItems[0]?.tooltip).toContain('running');
    const client = FakeClient.instances[0];

    changeSetting(ENABLE_SETTING, false);
    await settle();
    expect(statusItems[0]?.tooltip).toContain('disabled');
    client?.emit(State.Stopped);

    expect(statusItems[0]?.tooltip).toContain('disabled');
  });

  it.each([
    ['the binary is missing', false, 'not found'],
    ['the server fails to start', true, 'boom'],
  ])('shows failed with the reason in the tooltip when %s', async (_name, found, reason) => {
    FakeClient.failStart = true;
    if (found) {
      settings.set(SERVER_PATH_SETTING, SERVER);
    }
    activate(context());
    await settle();

    expect(statusItems[0]?.tooltip).toContain('failed');
    expect(statusItems[0]?.tooltip).toContain(reason);
  });

  it('opens the "CEL Lens" output channel when the status item is clicked', async () => {
    settings.set(SERVER_PATH_SETTING, SERVER);
    activate(context());
    await settle();

    expect(statusItems[0]?.id).toBe('celLens.status');
    expect(statusItems[0]?.command).toBe(SHOW_OUTPUT_COMMAND);
    await runCommand(SHOW_OUTPUT_COMMAND);

    expect(outputChannels.get('CEL Lens')?.shown).toBe(1);
  });
});
