import { describe, expect, it } from 'vitest';

import {
  INITIAL_SERVER_STATE,
  presentServerState,
  reduceServerState,
  type ServerEvent,
  type ServerState,
} from './server_state';

const DISABLED: ServerState = { kind: 'disabled' };
const STARTING: ServerState = { kind: 'starting' };
const RUNNING: ServerState = { kind: 'running' };
const FAILED: ServerState = { kind: 'failed', reason: 'boom' };
const DISABLE: ServerEvent = { kind: 'disable' };
const START: ServerEvent = { kind: 'start' };
const STARTED: ServerEvent = { kind: 'started' };
const FAIL: ServerEvent = { kind: 'failed', reason: 'no binary' };

describe('reduceServerState', () => {
  it.each<[string, ServerState, ServerEvent, ServerState]>([
    ['disabled, start: starting', DISABLED, START, STARTING],
    ['disabled, disable: disabled', DISABLED, DISABLE, DISABLED],
    ['disabled, started: stays disabled', DISABLED, STARTED, DISABLED],
    ['disabled, failed: stays disabled', DISABLED, FAIL, DISABLED],
    ['starting, started: running', STARTING, STARTED, RUNNING],
    [
      'starting, failed: failed with the reason',
      STARTING,
      FAIL,
      { kind: 'failed', reason: 'no binary' },
    ],
    ['starting, start: starting', STARTING, START, STARTING],
    ['starting, disable: disabled', STARTING, DISABLE, DISABLED],
    ['running, start: starting', RUNNING, START, STARTING],
    ['running, disable: disabled', RUNNING, DISABLE, DISABLED],
    [
      'running, failed: failed with the reason',
      RUNNING,
      FAIL,
      { kind: 'failed', reason: 'no binary' },
    ],
    ['running, started: running', RUNNING, STARTED, RUNNING],
    ['failed, start: starting', FAILED, START, STARTING],
    ['failed, disable: disabled', FAILED, DISABLE, DISABLED],
    ['failed, started: stays failed', FAILED, STARTED, FAILED],
    ['failed, failed: the new reason', FAILED, FAIL, { kind: 'failed', reason: 'no binary' }],
  ])('%s', (_name, state, event, expected) => {
    expect(reduceServerState(state, event)).toEqual(expected);
  });

  it('follows a crash and the client restarting the server', () => {
    const states = [START, STARTED, FAIL, START, STARTED].reduce<ServerState[]>(
      (seen, event) => [...seen, reduceServerState(seen.at(-1) ?? DISABLED, event)],
      [],
    );
    expect(states.map((state) => state.kind)).toEqual([
      'starting',
      'running',
      'failed',
      'starting',
      'running',
    ]);
  });

  it('begins disabled, until the extension decides to start', () => {
    expect(INITIAL_SERVER_STATE).toEqual(DISABLED);
  });
});

describe('presentServerState', () => {
  it.each<[ServerState, string, string]>([
    [DISABLED, 'circle-slash', 'disabled'],
    [STARTING, 'sync~spin', 'starting'],
    [RUNNING, 'check', 'running'],
    [FAILED, 'error', 'failed: boom'],
  ])('shows %j with an icon and a tooltip that name it', (state, icon, words) => {
    const shown = presentServerState(state);
    expect(shown.text).toContain(`$(${icon})`);
    expect(shown.tooltip).toContain(words);
  });
});
