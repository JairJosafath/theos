import { createHash } from 'node:crypto';

/** A platform the extension is packaged for, and the server build it bundles. */
export interface PackageTarget {
  /** The VS Code target: `vsce package --target`, and the `server/<target>/` directory. */
  target: string;
  /** The server release asset to bundle. */
  asset: string;
  /** The file name inside the package; the lookup in `server_path.ts` expects it. */
  file: string;
}

/** The server release's checksum file, as `make dist` in the server writes it. */
export const CHECKSUMS_ASSET = 'SHA256SUMS';

const PLATFORMS = [
  { target: 'linux-x64', os: 'linux', arch: 'amd64' },
  { target: 'linux-arm64', os: 'linux', arch: 'arm64' },
  { target: 'darwin-x64', os: 'darwin', arch: 'amd64' },
  { target: 'darwin-arm64', os: 'darwin', arch: 'arm64' },
  { target: 'win32-x64', os: 'windows', arch: 'amd64' },
] as const;

/** Every platform-specific package, with the server asset each one bundles. */
export const PACKAGE_TARGETS: readonly PackageTarget[] = PLATFORMS.map(({ target, os, arch }) => {
  const extension = os === 'windows' ? '.exe' : '';
  return {
    target,
    asset: `cel-language-server_${os}_${arch}${extension}`,
    file: `cel-language-server${extension}`,
  };
});

/** The pinned server release, from `server.json`. */
export interface ServerPin {
  version: string;
  releaseUrl: string;
}

/** Narrows the parsed `server.json`, failing with what to fix. */
export function parseServerPin(text: string): ServerPin {
  const parsed: unknown = JSON.parse(text);
  if (typeof parsed === 'object' && parsed !== null) {
    const { version, releaseUrl } = parsed as Record<string, unknown>;
    if (typeof version === 'string' && /^v\d+\.\d+\.\d+$/.test(version)) {
      if (typeof releaseUrl === 'string' && releaseUrl !== '') {
        return { version, releaseUrl };
      }
    }
  }
  throw new Error(
    'server.json must be {"version": "v1.2.3", "releaseUrl": "<URL up to /releases/download>"}.',
  );
}

/** Where `asset` of the pinned release is downloaded from. */
export function assetUrl(pin: ServerPin, asset: string): string {
  return `${pin.releaseUrl.replace(/\/+$/, '')}/${pin.version}/${asset}`;
}

/** Reads `sha256sum` output: one `<hex>  <name>` (or `<hex> *<name>`) per line. */
export function parseChecksums(text: string): Map<string, string> {
  const sums = new Map<string, string>();
  for (const line of text.split(/\r?\n/)) {
    const match = /^([0-9a-fA-F]{64}) [ *](.+)$/.exec(line);
    if (match?.[1] !== undefined && match[2] !== undefined) {
      sums.set(match[2], match[1].toLowerCase());
    }
  }
  return sums;
}

/** Whether `content` hashes to `expected`, a SHA-256 in hex. */
export function matchesChecksum(content: Uint8Array, expected: string): boolean {
  return createHash('sha256').update(content).digest('hex') === expected.toLowerCase();
}

/** The I/O `verifiedAsset` needs, injected so the cache decision is testable. */
export interface AssetStore {
  /** The cached file, or `undefined` when there is none. */
  cached: (asset: string) => Promise<Uint8Array | undefined>;
  download: (asset: string) => Promise<Uint8Array>;
  store: (asset: string, content: Uint8Array) => Promise<void>;
}

/**
 * The server build `asset`, checked against `sums`: the cached file while it
 * still matches, otherwise a fresh download, which is cached once it matches.
 */
export async function verifiedAsset(
  pin: ServerPin,
  asset: string,
  sums: ReadonlyMap<string, string>,
  io: AssetStore,
): Promise<Uint8Array> {
  const expected = sums.get(asset);
  if (expected === undefined) {
    throw new Error(
      `${CHECKSUMS_ASSET} of ${pin.version} has no entry for ${asset}. ` +
        `If the cached copy is damaged, delete .cache/server/${pin.version}/ and run again.`,
    );
  }
  const hit = await io.cached(asset);
  if (hit !== undefined && matchesChecksum(hit, expected)) {
    return hit;
  }
  const content = await io.download(asset);
  if (!matchesChecksum(content, expected)) {
    throw new Error(
      `${asset} does not match its ${CHECKSUMS_ASSET} entry (${expected}); not packaged.`,
    );
  }
  await io.store(asset, content);
  return content;
}
