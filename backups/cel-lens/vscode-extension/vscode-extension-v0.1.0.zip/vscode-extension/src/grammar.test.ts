import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

import { describe, expect, it } from 'vitest';

const ROOT = fileURLToPath(new URL('..', import.meta.url));

describe('grammar tests', () => {
  it('pass for the CEL grammar and its injection into YAML', () => {
    const output = execFileSync('npm', ['run', '--silent', 'test:grammar'], {
      cwd: ROOT,
      encoding: 'utf8',
    });

    expect(output).toContain('tokens.cel.test run successfuly');
    expect(output).toContain('values.yaml.test run successfuly');
  });
});
