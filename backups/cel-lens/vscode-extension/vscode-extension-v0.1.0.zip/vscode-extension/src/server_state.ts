/** What the language server is doing, as the status bar item shows it. */
export type ServerState =
  | { kind: 'disabled' }
  | { kind: 'starting' }
  | { kind: 'running' }
  | { kind: 'failed'; reason: string };

/** What happens to the server; `reduceServerState` turns them into states. */
export type ServerEvent =
  | { kind: 'disable' }
  | { kind: 'start' }
  | { kind: 'started' }
  | { kind: 'failed'; reason: string };

export interface StatusPresentation {
  text: string;
  tooltip: string;
}

export const INITIAL_SERVER_STATE: ServerState = { kind: 'disabled' };

/**
 * The state after `event`. Once disabled, only `start` leaves the state: a
 * late `started` or `failed` from the client being stopped is ignored.
 */
export function reduceServerState(state: ServerState, event: ServerEvent): ServerState {
  switch (event.kind) {
    case 'disable':
      return { kind: 'disabled' };
    case 'start':
      return { kind: 'starting' };
    case 'started':
      return state.kind === 'starting' ? { kind: 'running' } : state;
    case 'failed':
      return state.kind === 'disabled' ? state : { kind: 'failed', reason: event.reason };
  }
}

/** The status bar text and tooltip for `state`. */
export function presentServerState(state: ServerState): StatusPresentation {
  switch (state.kind) {
    case 'disabled':
      return {
        text: '$(circle-slash) CEL Lens',
        tooltip: 'CEL Lens is disabled ("celLens.enable"). Click to open the output.',
      };
    case 'starting':
      return {
        text: '$(sync~spin) CEL Lens',
        tooltip: 'The CEL language server is starting. Click to open the output.',
      };
    case 'running':
      return {
        text: '$(check) CEL Lens',
        tooltip: 'The CEL language server is running. Click to open the output.',
      };
    case 'failed':
      return {
        text: '$(error) CEL Lens',
        tooltip: `The CEL language server failed: ${state.reason} Click to open the output.`,
      };
  }
}
