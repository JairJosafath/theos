/**
 * A stand-in for the `vscode` module, which exists only inside VS Code's
 * extension host. vitest.config.mts points `vscode` here, so unit tests run in
 * plain Node. Each part `satisfies` the real API's types, so a stand-in that
 * drifts from VS Code fails the type check. Add only what tests need, and
 * clear its state in reset().
 */
import type * as vscode from 'vscode';

/** Runs a callback once when disposed, like vscode.Disposable. */
export class Disposable implements vscode.Disposable {
  private disposed = false;

  constructor(private readonly onDispose: () => void) {}

  dispose(): void {
    if (!this.disposed) {
      this.disposed = true;
      this.onDispose();
    }
  }
}

/** The commands run with commands.executeCommand, oldest first. */
export const executedCommands: unknown[][] = [];

const registry = new Map<string, (...args: unknown[]) => unknown>();

const checkedCommands = {
  registerCommand(command: string, callback: (...args: unknown[]) => unknown): Disposable {
    // VS Code refuses a second registration, which is how leaks show.
    if (registry.has(command)) {
      throw new Error(`command '${command}' already exists`);
    }
    registry.set(command, callback);
    return new Disposable(() => registry.delete(command));
  },
  getCommands(): Promise<string[]> {
    return Promise.resolve([...registry.keys()]);
  },
} satisfies Partial<typeof vscode.commands>;

export const commands = {
  ...checkedCommands,
  // Generic in the real API, so it can't be checked with `satisfies`.
  executeCommand(command: string, ...args: unknown[]): Promise<undefined> {
    executedCommands.push([command, ...args]);
    return Promise.resolve(undefined);
  },
};

/** Runs a registered command, as vscode.commands.executeCommand does. */
export async function runCommand(command: string, ...args: unknown[]): Promise<unknown> {
  const callback = registry.get(command);
  if (callback === undefined) {
    throw new Error(`command '${command}' not found`);
  }
  return await callback(...args);
}

/** The messages shown with window.showInformationMessage, oldest first. */
export const shownMessages: string[] = [];

/** The messages shown with window.showErrorMessage, oldest first. */
export const shownErrors: string[] = [];

/** What the user picks on the next error message; undefined dismisses it. */
export const errorChoice: { next: string | undefined; unanswered: boolean } = {
  next: undefined,
  unanswered: false,
};

/** The status bar items created, oldest first. */
export class StatusItem implements Pick<
  vscode.StatusBarItem,
  'name' | 'text' | 'tooltip' | 'command' | 'show' | 'hide' | 'dispose'
> {
  name: string | undefined;
  text = '';
  tooltip: string | undefined;
  command: string | undefined;
  visible = false;
  disposed = false;

  constructor(
    readonly id: string,
    readonly alignment: number,
  ) {}

  show(): void {
    this.visible = true;
  }

  hide(): void {
    this.visible = false;
  }

  dispose(): void {
    this.disposed = true;
  }
}

export const statusItems: StatusItem[] = [];

/** The language of the active editor; undefined means no editor. */
export const activeEditor: { languageId: string | undefined } = { languageId: undefined };

const editorListeners = new Set<(editor: vscode.TextEditor | undefined) => unknown>();

/** Makes `languageId` the active editor's language and tells the listeners. */
export function switchEditor(languageId: string | undefined): void {
  activeEditor.languageId = languageId;
  for (const listener of editorListeners) {
    listener(undefined);
  }
}

/** A log channel that remembers whether it was disposed and what it logged. */
export class LogChannel implements Pick<
  vscode.LogOutputChannel,
  'name' | 'info' | 'warn' | 'error' | 'dispose' | 'show'
> {
  disposed = false;
  shown = 0;
  readonly lines: string[] = [];

  constructor(readonly name: string) {}

  info(message: string): void {
    this.lines.push(`info: ${message}`);
  }

  warn(message: string): void {
    this.lines.push(`warn: ${message}`);
  }

  error(message: string): void {
    this.lines.push(`error: ${message}`);
  }

  show(): void {
    this.shown++;
  }

  dispose(): void {
    this.disposed = true;
  }
}

/** The output channels created, by name. */
export const outputChannels = new Map<string, LogChannel>();

const checkedWindow = {
  showInformationMessage(message: string): Promise<undefined> {
    shownMessages.push(message);
    return Promise.resolve(undefined);
  },
  onDidChangeActiveTextEditor(
    listener: (editor: vscode.TextEditor | undefined) => unknown,
  ): Disposable {
    editorListeners.add(listener);
    return new Disposable(() => editorListeners.delete(listener));
  },
  showErrorMessage(message: string): Promise<string | undefined> {
    shownErrors.push(message);
    if (errorChoice.unanswered) {
      return new Promise<never>(() => undefined);
    }
    return Promise.resolve(errorChoice.next);
  },
} satisfies Partial<typeof vscode.window>;

// An enum in the real API, so it can't be checked with `satisfies`.
export const StatusBarAlignment = { Left: 1, Right: 2 };

export const window = {
  ...checkedWindow,
  get activeTextEditor(): { document: { languageId: string } } | undefined {
    return activeEditor.languageId === undefined
      ? undefined
      : { document: { languageId: activeEditor.languageId } };
  },
  // Overloaded, or returning whole editors and items, in the real API, so they
  // can't be checked with `satisfies`.
  createStatusBarItem(id: string, alignment: number): StatusItem {
    const item = new StatusItem(id, alignment);
    statusItems.push(item);
    return item;
  },
  // Overloaded in the real API, so it can't be checked with `satisfies`.
  createOutputChannel(name: string): LogChannel {
    const channel = new LogChannel(name);
    outputChannels.set(name, channel);
    return channel;
  },
};

/** Setting values by full name, as workspace.getConfiguration().get reads them. */
export const settings = new Map<string, unknown>();

const configListeners = new Set<
  (change: { affectsConfiguration: (name: string) => boolean }) => void
>();

/** Sets a setting and tells the listeners that it changed, as editing settings does. */
export function changeSetting(name: string, value: unknown): void {
  settings.set(name, value);
  for (const listener of configListeners) {
    listener({ affectsConfiguration: (changed) => changed === name });
  }
}

/** The paths of the open workspace folders; empty means no folder is open. */
export const workspaceFolderPaths: string[] = [];

const folderListeners = new Set<() => void>();

/** Replaces the open workspace folders and tells the listeners, as adding or removing a folder does. */
export function changeWorkspaceFolders(paths: string[]): void {
  workspaceFolderPaths.splice(0, workspaceFolderPaths.length, ...paths);
  for (const listener of folderListeners) {
    listener();
  }
}

export const workspace = {
  get workspaceFolders(): { uri: { fsPath: string } }[] | undefined {
    return workspaceFolderPaths.length === 0
      ? undefined
      : workspaceFolderPaths.map((fsPath) => ({ uri: { fsPath } }));
  },
  onDidChangeConfiguration(
    listener: (change: { affectsConfiguration: (name: string) => boolean }) => void,
  ): Disposable {
    configListeners.add(listener);
    return new Disposable(() => configListeners.delete(listener));
  },
  onDidChangeWorkspaceFolders(listener: () => void): Disposable {
    folderListeners.add(listener);
    return new Disposable(() => folderListeners.delete(listener));
  },
  getConfiguration(): { get: (name: string, fallback: unknown) => unknown } {
    return {
      get: (name: string, fallback: unknown) => settings.get(name) ?? fallback,
    };
  },
} satisfies {
  getConfiguration: (...args: never[]) => { get: (...args: never[]) => unknown };
  onDidChangeConfiguration: (...args: never[]) => vscode.Disposable;
  onDidChangeWorkspaceFolders: (...args: never[]) => vscode.Disposable;
  workspaceFolders: readonly { uri: { fsPath: string } }[] | undefined;
};

export const env = {
  appName: 'Visual Studio Code',
} satisfies Partial<typeof vscode.env>;

/** Forgets every registration and message, for the next test. */
export function reset(): void {
  registry.clear();
  shownMessages.length = 0;
  shownErrors.length = 0;
  executedCommands.length = 0;
  errorChoice.next = undefined;
  errorChoice.unanswered = false;
  outputChannels.clear();
  settings.clear();
  workspaceFolderPaths.length = 0;
  statusItems.length = 0;
  activeEditor.languageId = undefined;
  editorListeners.clear();
  configListeners.clear();
  folderListeners.clear();
}
